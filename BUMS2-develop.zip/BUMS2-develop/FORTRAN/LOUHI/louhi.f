"RUN,/RS TKKJS,TKKY052970,TKKF02168,15,200/0  .  SANDBERG  TKK/TF               
"PSW JVS.  .                                                                    
"ASG,PU LOUT,F34                                                                
"SAVE LOUT.                                                                     
"BRKPT PRINT$/LOUT                                                              
"ASG,PU LOUHI,F34   .                                                           
"FOR,IS LOUHI.MAIN  .                                                           
C  GENERAL PURPOSE UNFOLDING PROGRAM LOUHI82                                    
C  CODED BY J.T. ROUTTI AND J.V. SANDBERG                                       
C  HELSINKI UNIVERSITY OF TECHNOLOGY                                            
C                                                                               
      COMMON/IOTAPE/ INTAPE ,  IOUTAP                                           
      COMMON/WHATS/ CODE, PAR(6), LMARK, ANAME(30),KNAME(30),CNORM(30)          
      COMMON / /    IALGOR   , IPRINT(15), IYVAL(100) ,  NGAM     ,             
     1  A(30,100),  AF(30)   ,  AFF(30)  ,  AP(30)   ,  AI(30)   ,              
     2  CHI(6)   , CS(30,100),  E(100)   ,  EWGT(30),  FLUX(100),               
     3 FTEST(100),  FWGT(100),  TWGT(100),  DWGT(100),  GAM      ,              
     3  GAMMA(6) ,  P(100)   ,  PF(100)  ,  PWGT(100),  Q(40,100),              
     5  R(30,100),  SF(100)  ,  SH(100)  ,  SWGT(100),  WGT(6)   ,              
     6  YVAL(100),  LGAM                                                        
      COMMON/FEED/ KOUT      , KVAR(15)  , MODE(6)   , NC        ,              
     1 NV        , GUES(100)                                                    
      COMMON/FOLD/ IVAR(9)   , IRECOL    , ITEST     , M         ,              
     1 N         , AIERR(30) , AISAVE(30), CHIIN(6)  , F(100)    ,              
     2 FM(100)   , FP(100)   , PEN(30)   , PRDEV(30) , RXMAX     ,              
     3 RXMIN     , RYMAX     , RYMIN     , RYSCL     , SCALEL    ,              
     4 TITLE(13) , WT(100)                                                      
      COMMON/FREEP/ AFREEP   ,  NFREEP   ,APSAVE(30), PSAVE(100)                
C                                                                               
C  COMMON VARIABLES                                                             
C                                                                               
C  COMMON IOTAPE                                                                
C                                                                               
C  INTAPE        LOGICAL NUMBER OF INPUT DEVICE OR FILE                         
C  IOUTAP         LOGICAL NUMBER OF OUTPUT DEVICE OR FILE                       
C                                                                               
C  BLANK COMMON                                                                 
C                                                                               
C  IALGOR        ALGORITHM FLAG, 1 FOR NONLINEA, 2 FOR MATRIX METHOD            
C  IPRINT(15)    OUTPUT CONTROL PARAMETERS                                      
C  IYVAL(40)     INDICES OF FREE ENERGY POINTS                                  
C  NGAM          NUMBER OF DIFFERENT GAMMA VALUES                               
C  A(40,40)      KERNEL MATRIX                                                  
C  AF(40)        RESPONSES CALCULATED WITH THE SOLUTION                         
C  AFF(40)       NOT USED IN THIS VERSION                                       
C  AP(40)        RESPONSES CALCULATED WITH THE P VECTOR                         
C  CHI(6)        SQUARE SUMS OF FITTING ERRORS AND PRIOR CONDITIONS             
C                Q0 - Q5 IN WRITEUP                                             
C  CS(40,40)     RESPONSE FUNCTIONS (CROSS SECTIONS)                            
C  E(40)         FREE ENERGY POINTS                                             
C  EWGT(40)      WEIGHTS OF RESPONSES IN Q0 = CHI(1)                            
C  FLUX(40)      SOLUTION AT FREE ENERGY POINTS                                 
C  FTEST(40)     TEST SOLUTION                                                  
C  FWGT(40)      WEIGHTS OF SOLUTION VECTOR IN Q2                               
C  TWGT(40)      WEIGHTS OF FIRST DIFFERENCES IN Q3                             
C  DWGT(40)      WEIGHTS OF SECOND DIFFERENCES IN 34                            
C  GAM           CURRENT VALUE OF REG. PARAMETER GAMMA                          
C  GAMMA(6)      6 VALUES FOR GAMMA                                             
C  P(40)         TRIAL SOLUTION P                                               
C  PF(40)        P VALUES AT FREE ENERGY POINTS                                 
C  PWGT(40)      WEIGHTS FOR DEVIATION FROM P IN Q1                             
C  Q(40,40)      AUXILIARY MATRIX WITH STEPS OPTION,                            
C                S IN WRITEUP                                                   
C  R(40,40)      AUXILIARY MATRIX WITH STEPS OPTION,                            
C                R IN WRITEUP                                                   
C  SF(40)        PARAMETERS FOR SHAPE MATCHING, Z IN WRITEUP                    
C  SH(40)        GIVEN UNNORMALIZED SHAPE                                       
C  SWGT(40)      WEIGHTS FOR SHAPE MATCHING IN Q5                               
C  WGT(6)        WEIGHTS OF PRIOR CONDITIONS,                                   
C                W1,- W5 IN WRITEUP                                             
C  YVAL(40)      ENERGY POINTS                                                  
C  LGAM          IDEX OF CURRENT GAMMA VALUE IN GAMMA VECTOR                    
C                                                                               
C  COMMON FEED                                                                  
C                                                                               
C  KOUT          OUTPUT CONTROL PARAMETER                                       
C  KVAR(15)      VARMIT CONTROL PARAMETERS                                      
C  MODE(6)       WEIGHTING MODES FOR PRIOR CONDITIONS                           
C  NC            NOT USED                                                       
C  NV            NUMBER OF FREE ENERGY POINTS                                   
C  GUES          INITIAL GUES FOR NONLINEAR MINIMIZATION                        
C                                                                               
C  COMMON FOLD                                                                  
C                                                                               
C  IVAR(9)       VARIABLE FORMAT                                                
C  IRECOL        FLAG FOR PROTON RECOIL KERNEL                                  
C  ITEST         TEST OPTION FLAG                                               
C  M             NUMBER OF RESPONSES IN THE KERNEL                              
C  N             TOTAL NUMBER OF ENERGY POINTS                                  
C  AIERR(40)     GENERATED PERTURBATIONS OF RESPONSES                           
C  AISAVE(40)    STORED UNPERTURBED RESPONSES                                   
C  CHIIN(6)      INITIAL VALUES OF CHI IN THE NONLINEAR                         
C                MINIMIZATION                                                   
C  F(40)         THE SOLUTION, FREE AND INTERPOLATED POINTS                     
C  FM(40)        LOWER LIMIT OF CONFIDENCE BAND                                 
C  FP(40)        UPPER LIMIT OF CONFIDENCE BAND                                 
C  PEN(40)       USED WITH RECOIL PROTON KERNEL                                 
C  PRDEF(40)     USED WITH RECOIL PROTON KERNEL                                 
C  RXMAX         NOT USED                                                       
C  RXMIN         NOT USED                                                       
C  RYMAXUM       MAXIMUM ORDINATE IN LINEPRINTER GRAPHS                         
C  RYMIN         MINIMUM ORDINATE IN LINEPRINTER GRAPHS                         
C  RYSCL         RATIO OF MINIMUM AND MAXIMUM ORDINATES                         
C  SCALEL        NOT USED                                                       
C  TITLE(13)     TITLE OF THE PROBLEM                                           
C  WT(40)        QUADRATURE WEIGHTS                                             
C                                                                               
C  COMMON FREEP IS ASSOCIATED WITH THE ITERATION WITH                           
C  P VECTOR, NOT USED IN THIS VERSION                                           
C                                                                               
C  THIS VERSION INCLUDES OPTIONAL ANALYTIC SET-UP OF                            
C  PROTON RECOIL KERNEL, WHICH IS NOT EXPLAINED                                 
C  IN THE WRITEUP                                                               
      DIMENSION RN(41),C(50),PROT(40),EBIN(41),PCWGT(40)                        
      DIMENSION LS(10), HEL(100)                                                
C                                                                               
C  INITIALIZATIONS                                                              
C                                                                               
      DATA LS/1H1,1H2,1H3,1H4,1H5,1H6,1H7,1H8,1H9,1H0/                          
      DATA ITELE,ITEST,LPLOT,LPUNCH,HDENS /1,0,0,0,1./                          
      DATA (TITLE(I),I=1,8) /6HNO TIT,6HLE    ,6*6H      /                      
      DATA (IVAR(I),I=1,9)/6H(8E10.,6H0)    ,6*6H      ,1/                      
      DATA INTAPE,IOUTAP,(MODE(I),I=1,5) /4,5,5*3/                              
      DATA KOUT,NV,NFREEP,IFREEP,NSL,NSU /6*0/                                  
      DATA (KVAR(J),J=1,12)/12*0/                                               
      DATA KVAR(8),NV,NSL,NSU/200,3*0/                                          
C                                                                               
C  KEYWORDS                                                                     
C                                                                               
      DATA (C(I),I=1,43)   / 6HALGOR  , 6HCPTIME , 6HDATA   , 6HESCALE ,        
     1 6HFSCALE , 6HTSCALE , 6HDSCALE , 6HPSCALE , 6HSSCALE , 6HFORMAT ,        
     2 6HFREEP  , 6HGRAPH  , 6HGAMMAS , 6HGO     , 6HGUESS  , 6HINIT   ,        
     3 6HIOFILE , 6HKERNEL , 6HMAKEPF , 6HMODE   , 6HTIE    , 6HP      ,        
     4 6HPCORR  , 6HPERTUR , 6HOPTION , 6HPRINT  , 6HPROTON , 6HPUNCH  ,        
     5 6HRECOIL , 6HSHAPE  , 6HSTATUS , 6HSTEPS  , 6HSTOP   , 6HTEST   ,        
     6 6HTITLE  , 6HVARMIT , 6HWEIGHT , 6HKFIX   , 6HKREAD  , 6HINTEG  ,        
     7  3*6HSPARE    /                                                          
C                                                                               
C                                                                               
 9010 FORMAT(A6,4X,6E10.0,A6,4X)                                                
 9020 FORMAT(30H *************** CONTROL CARD ,5X,A6,4X,6E10.3,A6,4X)           
 9030 FORMAT(23H ILLEGAL CONTROL CARD..,A6,4X,6E10.3,A6,4X)                     
 9040 FORMAT(13A6)                                                              
 9050 FORMAT(8E10.0)                                                            
 9060 FORMAT('  PLOT P-VECTOR')                                                 
 9062 FORMAT(//5X,'FTEST')                                                      
 9063 FORMAT(//5X,'RESPONSES CORRESPONDING TO FTEST')                           
 9070 FORMAT(//5X,7H PCORR=,E14.4,25H  AND A(J,I)*P(I)*PCORR=   )               
 9080 FORMAT(8E12.3)                                                            
 9090 FORMAT(///5X,'PERTURBATION OF RESPONSES')                                 
 9100 FORMAT(//7X,'I',5X,'KNAME',10X,'AISAVE',9X,'AI',13X,'RATIO' /)            
 9110 FORMAT(5X,I3,5X,A6,1X,3E15.3,8X,A6,4X )                                   
 9120 FORMAT(10I1,2E10.0)                                                       
 9130 FORMAT(///' RECOIL SPECTRUM AS READ IN AND AS ADJUSTED PER ENERGY         
     1INTERVAL')                                                                
 9140 FORMAT(///' STANDARD DEVIATION OF READ IN RECOIL SPECTRUM')               
 9150 FORMAT(8E10.3)                                                            
 9160 FORMAT(16I5)                                                              
 9170 FORMAT(//' ********  ENTER  VARMIT  ********')                            
 9180 FORMAT(' ********  VARMIT OUTPUT  ********'//)                            
 9190 FORMAT (// ' ********  RETURN FROM VARMIT  ********'//)                   
 9200 FORMAT(/5X,17HTITLE OF PROBLEM: ,5X,13A6/)                                
 9210 FORMAT(//)                                                                
 9220 FORMAT(1H1)                                                               
 9230 FORMAT(/5X,7HLABEL  ,A6,14H  OF RESPONSE ,I5,12HIS DIFFERENT ,            
     1 17H FROM THE LABEL  ,A6,30H  USED IN KERNEL SPECIFICATION  /)            
 9240 FORMAT   (72H     I     LABEL      AP(I)      AI(I)      EPS%             
     1 AP/AI      PCWGT    //)                                                  
 9250 FORMAT(1X,I5,4X,A6,3X,5G12.5)                                             
 9260 FORMAT(/ 5X,16HSUM PCWGT*EPS**2  , 25X, 5HQQ =  ,G13.5)                   
 9270 FORMAT(29H     INTEGRAL OF THE P VECTOR, 17X, 5HPT = , G13.5 )            
 9280 FORMAT(20H     AVERAGE ENERGY , 24X, 7HEAVS = ,G13.5)                     
 9290 FORMAT(51H     WEIGHTED INTEGRAL OF THE P VECTOR        DS = ,            
     *  G13.5 )                                                                 
 9300 FORMAT(47H     AVERAGED FITTING ERRORS OF THE RESPONSES:   ,              
     1       32H     (WEIGHTED RESPONSES ONLY)     /                            
     2       31H     RELATIVE            EA0 = , G13.5 /                        
     *       31H     ABSOLUTE RELATIVE   EA1 = , G13.5 /                        
     *       31H     SQUARED  RELATIVE   EA2 = , G13.5 )                        
 9310 FORMAT(/ '  INTEGRAL OF SOLUTION ABOVE ' ,G13.5,                          
     * '  IS ', G13.5  /)                                                       
 9320 FORMAT(/ '  INTEGRAL OF RESPONSE ', I4,  '  ABOVE ',                      
     *  G13.5, '   IS ', G13.5  /)                                              
      DO 2 I=1,30                                                               
      AFF(I)=1.                                                                 
      AP(I)=1.                                                                  
      AF(I)=1.                                                                  
      APSAVE(I)=1.                                                              
      AI(I)=0.                                                                  
      P(I)=1.                                                                   
      EWGT(I)=1.                                                                
      DO 3 J=1,100                                                              
    3 A(I,J)=0.                                                                 
    2 PEN(I)=I                                                                  
      DO 4 I=1,100                                                              
      PF(I)=1.                                                                  
      F(I)=1.                                                                   
      FLUX(I)=1.                                                                
      FTEST(I)=1.                                                               
      GUES(I)=1.                                                                
      PSAVE(I)=1.                                                               
      PWGT(I)=0.                                                                
      FWGT(I)=0.                                                                
      TWGT(I)=0.                                                                
      DWGT(I)=1.                                                                
      SWGT(I)=0.                                                                
    4 IYVAL(I)=I                                                                
      DO 5 I=1,5                                                                
    5 WGT(I)=0.                                                                 
      WGT(4)=1.                                                                 
      DO 6 I=1,15                                                               
    6 IPRINT(I)=0                                                               
      IPRINT(5)=2                                                               
      IPRINT(8)=1                                                               
      GAMMA(1)=1.                                                               
      NGAM=1                                                                    
      IALGOR=1                                                                  
      IPD=5                                                                     
      IOD=6                                                                     
      IALGOR=1                                                                  
      INTAPE=5                                                                  
      IOUTAP=6                                                                  
C                                                                               
C                                                                               
C  READING CONTROL CARDS                                                        
C                                                                               
      WRITE(IOUTAP,9220)                                                        
   20 READ(IPD,9010) CODE,(PAR(I),I=1,6),LMARK                                  
      WRITE(IOD,9020)CODE,(PAR(I),I=1,6),LMARK                                  
C  COMPARING KEYWORDS                                                           
      DO 60 I=1,41                                                              
      IF(CODE.EQ.C(I)) GO TO 70                                                 
   60 CONTINUE                                                                  
C  ERRONEOUS CONTROL CARD                                                       
      WRITE(IOUTAP,9030) CODE,(PAR(I),I=1,6),LMARK                              
      GO TO 20                                                                  
   70 GO TO (1000,1100,1200,1300,1400,1400,1400,1400,1400,1500,1600,            
     1  1700,1800,1900,2000,2100,2200,2300,2400,2500,2600,2700,2800,            
     2  2900,3000,3100,3200,3300,3400,3500,3600,3700,3800,3900,4000,            
     3  4100,4200,4300,4400,4500,4600),I                                        
C                                                                               
C ALGOR, CHOOSE MINIMIZATION ALGORITHM                                          
C                                                                               
 1000 IALGOR=INT(PAR(1))                                                        
      DO 1020 I=1,5                                                             
 1020 MODE(I)=1                                                                 
      GO TO 20                                                                  
C                                                                               
C  CPUTIME                                                                      
 1100 CALL TIMER                                                                
      GO TO 20                                                                  
C                                                                               
C  DATA, READ IN RESPONSES                                                      
C                                                                               
 1200 I=INT(PAR(1))                                                             
      IF(PAR(2).NE.0.) AI(I)=PAR(2)                                             
      IF(PAR(3).NE.0.) CNORM(I)=PAR(3)                                          
      IF(CNORM(I).EQ.0.) CNORM(I)=1.                                            
      IF(PAR(3).EQ.0.) CNORM(I)=1.                                              
      AI(I)=AI(I)/CNORM(I)                                                      
      EWGT(I)=PAR(4)/AI(I)**2                                                   
      IF(LMARK.EQ.6H       ) GO TO 1250                                         
      IF(LMARK.NE.KNAME(I)) WRITE(IOUTAP,9230)                                  
     1 LMARK,I,KNAME(I)                                                         
 1250 CONTINUE                                                                  
      IPERT=0                                                                   
      ITEST=0                                                                   
      GO TO 20                                                                  
C                                                                               
C  ESCALE, SET WEIGHTS FOR EPSILON-VECTOR                                       
C                                                                               
 1300 KSCL=INT(PAR(1))                                                          
      IF(PAR(3).GT.0.) KSCL=KSCL+6                                              
      KEXP=INT(PAR(2))                                                          
      CALL SCALE(KSCL,KEXP,M,AI,EWGT,IVAR)                                      
      GO TO 20                                                                  
C                                                                               
C  PSCALE,ESCALE,TSCALE,DSCALE,SSCALE                                           
C  SET WEIGHTS FOR ENERGY POINTS                                                
C  SET P AT YVAL(I)                                                             
C                                                                               
 1400 DO 1410 I1=1,NV                                                           
      I2=IYVAL(I1)                                                              
 1410 PF(I1)=P(I2)                                                              
      KSCL=INT(PAR(1))                                                          
      IF(PAR(3).GT.0.) KSCL=KSCL+6                                              
      KEXP=INT(PAR(2))                                                          
      I=I-4                                                                     
      GO TO (1420,1430,1440,1450,1460),I                                        
C                                                                               
C  SET WEIGHTS FOR F-VECTOR                                                     
 1420 CALL SCALE(KSCL,KEXP,NV,PF,FWGT,IVAR)                                     
      GO TO 20                                                                  
C  SET WEIGHTS FOR FIRST DIFFERENCE VECTOR                                      
 1430 CALL SCALE (KSCL,KEXP,NV,PF,TWGT,IVAR)                                    
      GO TO 20                                                                  
C  SET WEIGHTS FOR SECOND DIFFERENCE VECTOR                                     
 1440 CALL SCALE(KSCL,KEXP,NV,PF,DWGT,IVAR)                                     
      GO TO 20                                                                  
C  SET WEIGHTS FOR P-VECTOR                                                     
 1450 CALL SCALE(KSCL,KEXP,NV,PF,PWGT,IVAR)                                     
      GO TO 20                                                                  
C SET WEIGHTS FOR SHAPE VECTOR                                                  
 1460 CALL SCALE(KSCL,KEXP,NV,PF,SWGT,IVAR)                                     
      DO 1470 I=1,N                                                             
 1470 IF(IYVAL(I).LT.NSL.OR.IYVAL(I).GT.NSU) SWGT(I)=0.                         
      GO TO 20                                                                  
C                                                                               
C  FORMAT, READ VARIABLE FORMAT                                                 
C                                                                               
 1500 READ(INTAPE,9040) (IVAR(I),I=1,8)                                         
      GO TO 20                                                                  
C                                                                               
C  FREEP, ENABLE FREEP OPTION, NOT USED                                         
C                                                                               
 1600 AFREEP=PAR(1)                                                             
      NFREEP=INT(PAR(2))                                                        
      GO TO 20                                                                  
C                                                                               
C  GRAPHS, LINEPRINTER GRAPH OPTIONS                                            
C                                                                               
 1700 IPRINT(5)=IFIX(PAR(1))                                                    
      IPRINT(6)=IFIX(PAR(2))                                                    
      RYMIN=PAR(3)                                                              
      RYMAX=PAR(4)                                                              
      GO TO 20                                                                  
C                                                                               
C  GAMMAS, READ GAMMA VALUES                                                    
C                                                                               
 1800 DO 1810 I=1,6                                                             
      IF(PAR(I).EQ.0.) GO TO 20                                                 
      NGAM=I                                                                    
 1810 GAMMA(I)=PAR(I)                                                           
      GO TO 20                                                                  
C                                                                               
C  GO, START UNFOLDING                                                          
C                                                                               
 1900 IF(PAR(1).NE.1.) GO TO 1910                                               
C  IF PAR(1)=1. NO PRINTOUT OF RESULTS                                          
      KOUT1=KOUT                                                                
      KOUT=0                                                                    
      IPRINT(15)=0                                                              
      GO TO 1920                                                                
 1910 IPRINT(15)=1                                                              
 1920 CONTINUE                                                                  
      IF(IPRINT(12).EQ.1) GO TO 1940                                            
C  SET STEPS IF NO STEPS CARD WAS GIVEN, IPRINT(12)=1 INDICATES THAT            
C  A STEPS CARD WAS GIVEN AFTER LAST KFIX CARD                                  
      I1=1                                                                      
      GO TO 3705                                                                
 1930 IPRINT(12)=1                                                              
 1940 GO TO 6000                                                                
C                                                                               
C  GUESS, CONSTRUCT GUESS FOR X-VECTOR                                          
C                                                                               
 2000 L=INT(PAR(1))                                                             
      IF(IALGOR.NE.1) GO TO 2050                                                
      IF(L.GT.1) GO TO 2030                                                     
 2010 READ(INTAPE,IVAR) (GUES(I),I=1,NV)                                        
      DO 2020 I=1,NV                                                            
 2020 GUES(I)=SQRT(GUES(I))                                                     
      GO TO 20                                                                  
 2030 DO 2040 I=1,NV                                                            
      K=IYVAL(I)                                                                
      IF(L.EQ.2) GUES(I)=SQRT(P    (K))                                         
      IF(L.EQ.3) GUES(I)=SQRT(F    (K))                                         
      IF(L.EQ.4) GUES(I)=SQRT(FTEST(K))                                         
 2040 CONTINUE                                                                  
      GO TO 20                                                                  
 2050 IF(L.GT.1) GO TO 2060                                                     
      READ(INTAPE,IVAR) (GUES(I),I=1,NV)                                        
      GO TO 20                                                                  
 2060 DO 2070 J=1,NV                                                            
      K = IYVAL(J)                                                              
      IF(L.EQ.2) GUES(J)=P(K)                                                   
      IF(L.EQ.3) GUES(J)=F(K)                                                   
      IF(L.EQ.4) GUES(J)=FTEST(K)                                               
 2070 CONTINUE                                                                  
      GO TO 20                                                                  
C                                                                               
C  INIT, SET WEIGHTS TO INITIAL VALUES                                          
C                                                                               
 2100 DO 2110 I=1,40                                                            
      EWGT(I)=1.                                                                
      PWGT(I)=1.                                                                
      FWGT(I)=1.                                                                
      TWGT(I)=1.                                                                
      DWGT(I)=1.                                                                
 2110 SWGT(I)=1.                                                                
      DO 2120 I=1,5                                                             
 2120 MODE(I)=3                                                                 
      GO TO 20                                                                  
C                                                                               
C  IOFILE, SPECIFY INPUT AND OUTPUT FILES                                       
C                                                                               
 2200 IF(PAR(1).NE.0.) INTAPE=INT(PAR(1))                                       
      IF(PAR(2).NE.0.) IOUTAP=INT(PAR(2))                                       
      GO TO 20                                                                  
C                                                                               
C KERNEL, NOT USED                                                              
C                                                                               
 2300 GO TO 20                                                                  
C                                                                               
C  MAKEPF, MAKE P-VECTOR EQUAL TO F-VECTOR                                      
C                                                                               
 2400 DO 2410 I=1,N                                                             
      PF(I)=FLUX(I)                                                             
 2410 P(I)=F(I)                                                                 
      CALL MTMPY(M,N,1,A,P,AP)                                                  
      GO TO 20                                                                  
C                                                                               
C  MODE, READ MODE OF WEIGHTING                                                 
C                                                                               
 2500 I1=INT(PAR(1))                                                            
      MODE(1)=I1                                                                
      DO 2510 I=2,5                                                             
      MODE(I)=I1                                                                
 2510 IF(PAR(I).NE.0.) MODE(I)=INT(PAR(I))                                      
      GO TO 20                                                                  
C                                                                               
C  TIE, SET OR RELEASE TIES                                                     
C                                                                               
 2600 I1=INT(PAR(1))                                                            
      IF(I1.GT.0) GO TO 2620                                                    
      DO 2610 I=1,40                                                            
 2610 PWGT(I)=0.                                                                
      WGT(1)=0.                                                                 
      GO TO 20                                                                  
 2620 WGT(1)=1.                                                                 
      PWGT(I1)=PAR(3)                                                           
      IF(IALGOR.NE.1) P(I1)=PAR(2)                                              
      IF(IALGOR.NE.1) GO TO 20                                                  
      I2=IYVAL(I1)                                                              
      P(I2)=PAR(2)                                                              
      PF(I1)=PAR(2)                                                             
      GO TO 20                                                                  
C                                                                               
C  P, READ APPROXIMATE SOLUTION P                                               
C                                                                               
 2700 IF(PAR(1).LT.0.) GO TO 2720                                               
      DO 2705 J=1,N                                                             
      IF(YVAL(J).GT.PAR(4)) GO TO 2706                                          
 2705 CONTINUE                                                                  
      NEL = N+1                                                                 
      GO TO 2708                                                                
 2706 NEL = J                                                                   
 2708 NEL1 =  NEL-1                                                             
      IF(NEL1.LE.0) GO TO 2712                                                  
      DO 2710 I=1,NEL1                                                          
 2710 P(I)=PAR(1)*YVAL(I)**PAR(2)                                               
 2712 IF(NEL.GT.N) GO TO 2730                                                   
      DO 2715 J=NEL,N                                                           
      EP = SQRT(2.29*YVAL(J))                                                   
 2715 P(J) = PAR(3)*EXP(-YVAL(J)/0.965)*                                        
     1    0.5*(EXP(EP) - EXP(-EP))                                              
      WRITE(IOUTAP,2740)                                                        
 2740 FORMAT(/ 24H  P IS FISSION SPECTRUM    /)                                 
      GO TO 2730                                                                
 2720 READ(INTAPE,IVAR) (P(I),I=1,N)                                            
 2730 CALL MTMPY(M,N,1,A,P,AP)                                                  
      IF(PAR(5).EQ.0.) GO TO 20                                                 
C  PLOT P-VECTOR                                                                
      WRITE(IOUTAP,9060)                                                        
      LL=INT(PAR(4))                                                            
      CALL GRAPHS (LL,YVAL,1,N,1,1,40,P,1,N,1,0.,0.,1.E+8,IOUTAP,LS)            
      GO TO 20                                                                  
C                                                                               
C  PCORR, CORRECT P-VECTOR                                                      
C                                                                               
 2800 PCORR = PAR(5)                                                            
      KSCL=INT(PAR(1))                                                          
      IF(KSCL.NE.0) GO TO 2804                                                  
      DO 2802 I=1,M                                                             
 2802 PCWGT(I)=EWGT(I)                                                          
      GO TO 2806                                                                
 2804 IF(PAR(3).GT.0.) KSCL=KSCL+6                                              
      KEXP=INT(PAR(2))                                                          
      CALL SCALE (KSCL,KEXP,M,AI,PCWGT,IVAR)                                    
 2806 R1=0.                                                                     
      R2=0.                                                                     
      IF(PAR(5).GT.0.) GO TO 2815                                               
      DO 2810 I=1,M                                                             
      R1=R1+PCWGT(I)*AI(I)*AP(I)                                                
 2810 R2=R2+PCWGT(I)*AP(I)*AP(I)                                                
      PCORR=R1/R2                                                               
 2815 DO 2820 I=1,N                                                             
      PF(I)=PCORR*PF(I)                                                         
 2820 P(I)=PCORR*P(I)                                                           
      DO 2830 I=1,M                                                             
 2830 AP(I)=PCORR*AP(I)                                                         
      WRITE(IOUTAP,9070) PCORR                                                  
      WRITE(IOUTAP,9080) (AP(I),I=1,M)                                          
      WRITE(IOUTAP,9210)                                                        
      IF(PAR(4).LE.0.) GO TO 20                                                 
      QQ = 0.                                                                   
      EA0 = 0.                                                                  
      EA1 = 0.                                                                  
      EA2 = 0.                                                                  
      MW = 0                                                                    
      WRITE(IOUTAP,9240)                                                        
C                                                                               
      DO 2850 I=1,M                                                             
      EPS = AP(I) - AI(I)                                                       
      EP1 = EPS/AI(I)                                                           
      QQ = QQ+PCWGT(I)*EPS**2                                                   
      IF(PCWGT(I).LE.0.) GO TO 2840                                             
      MW = MW+1                                                                 
      EA0 =EA0+EP1                                                              
      EA1 = EA1 + ABS(EP1)                                                      
      EA2 = EA2 +EP1**2                                                         
 2840 EPS =100.*EPS/AI(I)                                                       
      RAT = AP(I)/AI(I)                                                         
      WRITE(IOUTAP,9250) I,KNAME(I),AP(I),AI(I),EPS,RAT,PCWGT(I)                
 2850 CONTINUE                                                                  
      EA0 = EA0/MW                                                              
      EA1 = EA1/MW                                                              
      EA2 = EA2/MW                                                              
C                                                                               
      PT = 0.                                                                   
      EAVS = 0.                                                                 
      DS = 0.                                                                   
      DO 2860 J=1,N                                                             
      PT = PT+WT(J)*P(J)                                                        
      EAVS = EAVS +WT(J)*P(J)*YVAL(J)                                           
 2860 DS = DS+WT(J)*FDOSE(YVAL(J))*P(J)                                         
      EAVS = EAVS/PT                                                            
      WRITE(IOUTAP,9260) QQ                                                     
      WRITE(IOUTAP,9270) PT                                                     
      WRITE(IOUTAP,9280) EAVS                                                   
      WRITE(IOUTAP,9290) DS                                                     
      WRITE(IOUTAP,9300) EA0, EA1, EA2                                          
      GO TO 20                                                                  
C                                                                               
C  PERTUR, PERTURB RESPONSES WITH NORMALLY DISTRIBUTED RANDOM ERRORS            
C                                                                               
 2900 WRITE(IOUTAP,9090)                                                        
      WRITE(IOUTAP,9100)                                                        
      IF(IPERT.EQ.1) GO TO 2920                                                 
C  FIRST PERTURBATION, STORE ORIGINAL RESPONSES                                 
      IPERT=1                                                                   
      DO 2910 I=1,M                                                             
 2910 AISAVE(I)=AI(I)                                                           
 2920 IP=IFIX(PAR(1))                                                           
      RN(1)=PAR(4)                                                              
      IF(IP.GT.0) GO TO 2940                                                    
C                                                                               
C  PERTURB ALL RESPONSES WITH RANDOM ERRORS                                     
C                                                                               
C  SUBROUTINE RANDN GENERATES M NORMALLY DISTRIBUTED RANDOM                     
C  NUMBERS IN ELEMENTS 1 - M OF VECTOR RN, RN(1) IS A SEED                      
C  NUMBER WHICH IS REPLACED BY THE FIRST RANDOM NUMBER,                         
C  A NONZERO SEED NUMBER STARTS A NEW RANDOM NUMBER SEQUENCE.                   
C  THE STANDARD DEVIATION IS SPECIFIED WITH THE                                 
C  FOURTH ARGUMENT, PAR(2), AND THE MEAN VALUE BY THE                           
C  THIRD ARGUMENT, 0.                                                           
C                                                                               
      CALL RANDN(RN,M+1,0.,PAR(2))                                              
      DO 2930 I=1,M                                                             
      RAT=AMAX1(-90.,RN(I+1))                                                   
      RAT=(100.+RAT)/100.                                                       
      AI(I)=RAT*AI(I)                                                           
 2930 WRITE(IOUTAP,9110) I,KNAME(I),AISAVE(I),AI(I),RAT                         
      WRITE(IOUTAP,9210)                                                        
      GO TO 20                                                                  
 2940 IF(PAR(3).NE.0.) GO TO 2950                                               
C  PERTURB ONE RESPONSE WITH RANDOM ERROR                                       
      CALL RANDN(RN,2,0.,PAR(2))                                                
      RAT=AMAX1(-90.,RN(2))                                                     
      RAT=(100.+RAT)/100.                                                       
      AI(IP)=AI(IP)*RAT                                                         
      GO TO 2960                                                                
 2950 RAT=PAR(3)                                                                
C  PERTURB ONE RESPONSE DETERMINISTICALLY                                       
      AI(IP)=RAT*AI(IP)                                                         
 2960 WRITE(IOUTAP,9110) I,KNAME(I),AISAVE(I),AI(I),RAT                         
      WRITE(IOUTAP,9210)                                                        
      GO TO 20                                                                  
C                                                                               
C  OPTION, OUTPUT OPTIONS                                                       
C                                                                               
 3000 IPRINT(8)=IFIX(PAR(1))                                                    
      IPRINT(7)=IFIX(PAR(2))                                                    
      IPRINT(4)=IFIX(PAR(2))                                                    
      DO 3010 I=1,3                                                             
 3010 IPRINT(I)=IFIX(PAR(I+2))                                                  
      KOUT=IPRINT(4)                                                            
      KOUT1=KOUT                                                                
      IPRINT(10) =IFIX(PAR(6))                                                  
      GO TO 20                                                                  
C                                                                               
C  PRINT, NOT USED                                                              
C                                                                               
 3100 GO TO 20                                                                  
C                                                                               
C  PROTON, RECOIL SPECTRUM IS READ IN AND                                       
C  ADJUSTED PER ENERGY INTERVAL                                                 
C                                                                               
 3200 READ(INTAPE,IVAR) (PROT(I),I=1,M)                                         
      IF(PAR(1).EQ.0.) GO TO 3210                                               
      READ(INTAPE,IVAR) (PRDEV(I),I=1,M)                                        
      GO TO 3230                                                                
 3210 DO 3220 I=1,M                                                             
 3220 PRDEV(I)=SQRT(AMAX1(PROT(I),1.))                                          
 3230 I1=M+1                                                                    
      IF(PAR(2).EQ.0.) GO TO 3240                                               
      READ(INTAPE,IVAR) (EBIN(I),I=1,I1)                                        
      GO TO 3260                                                                
 3240 EBIN(1)=YVAL(1)-0.5*(YVAL(2)-YVAL(1))                                     
      EBIN(I1)=YVAL(M)+0.5*(YVAL(M)-YVAL(M-1))                                  
      DO 3250 I=2,M                                                             
 3250 EBIN(I)=0.5*(YVAL(I)+YVAL(I-1))                                           
 3260 DO 3270 I=1,M                                                             
      EWGT(I)=EBIN(I+1)-EBIN(I)                                                 
      AI(I)=PROT(I)/EWGT(I)                                                     
      CNORM(I)=1.                                                               
 3270 EWGT(I)=1./PRDEV(I)**2                                                    
      WRITE(IOUTAP,9130)                                                        
      WRITE(IOUTAP,9080) (PROT(I),I=1,M)                                        
      WRITE(IOUTAP,9080) (AI(I),I=1,M)                                          
      WRITE(IOUTAP,9140)                                                        
      WRITE(IOUTAP,9080) (PRDEV(I),I=1,M)                                       
      ITEST=0                                                                   
      GO TO 20                                                                  
C                                                                               
C  PUNCH SOLUTION VECTOR F                                                      
C                                                                               
 3300 IPUNCH=INT(PAR(1))                                                        
      WRITE(IPUNCH,9040) (TITLE(I),I=1,13)                                      
      WRITE(IPUNCH,9150) (F(I),I=1,N)                                           
      LPUNCH=1                                                                  
      IF(PAR(2).LE.0.) GO TO 3350                                               
      WRITE(IPUNCH,3310)                                                        
      WRITE(IPUNCH,9150) (FM(J),J=1,N)                                          
      WRITE(IPUNCH,3320)                                                        
      WRITE(IPUNCH,9150) (FP(J),J=1,N)                                          
 3310 FORMAT('  LOWER CONFIDENCE LIMIT ')                                       
 3320 FORMAT('  UPPER CONFIDENCE LIMIT ')                                       
 3350 CONTINUE                                                                  
      IF(PAR(3).LE.0.) GO TO 3370                                               
      WRITE(IPUNCH,3360)                                                        
 3360 FORMAT('  P VECTOR ')                                                     
      WRITE(IPUNCH,9150) (P(J),J=1,N)                                           
 3370 IF(PAR(4).LE.0.) GO TO 20                                                 
      WRITE(IPUNCH,3380)                                                        
 3380 FORMAT('  ENERGY POINTS ')                                                
      WRITE(IPUNCH,9150) (E(J),J=1,N)                                           
      GO TO 20                                                                  
C                                                                               
C  RECOIL, SET UP RECOIL PROTON KERNEL                                          
C                                                                               
 3400 M=INT(PAR(1))                                                             
      N=INT(PAR(2))                                                             
      IF(PAR(3).NE.0.) HDENS=PAR(3)                                             
      IRECOL=1                                                                  
      CALL KERNEL(3,HDENS)                                                      
      IPRINT(12)=0                                                              
      NV=N                                                                      
      IPERT=0                                                                   
      GO TO 20                                                                  
C                                                                               
C  SHAPE, READS IN UNNORMALIZED SHAPE SH                                        
C                                                                               
 3500 NSL=INT(PAR(1))                                                           
      NSU=INT(PAR(2))                                                           
      IF(PAR(3).EQ.1.) GO TO 3520                                               
      READ(INTAPE,IVAR) (SH(J),J=NSL,NSU)                                       
C  SF (Z IN WRITE-UP) NOW CALCULATED AT STEPS                                   
      GO TO 20                                                                  
 3520 DO 3530 J=1,N                                                             
 3530 SH(J) = P(J)                                                              
      GO TO 20                                                                  
C                                                                               
C  STATUS, NOT USED                                                             
C                                                                               
 3600 GO TO 20                                                                  
C                                                                               
C  STEPS,  READS THE ENERGY POINTS WHERE THE FUNCTION IS TO BE CALCULATED       
C                                                                               
 3700 IPRINT(12)=1                                                              
      IF(PAR(2).NE.0.) GO TO 3720                                               
      I1=MAX0(INT(PAR(1)),1)                                                    
 3705 NV=0                                                                      
C  EVERY ITH POINT FREE                                                         
      DO 3710 I=1,N,I1                                                          
      NV=NV+1                                                                   
 3710 IYVAL(NV)=I                                                               
      IF(IYVAL(NV).EQ.N) GO TO 3730                                             
      NV=NV+1                                                                   
      IYVAL(NV)=N                                                               
      GO TO 3730                                                                
 3720 NV=INT(PAR(2))                                                            
C  READS INDICES OF FREE POINTS                                                 
      READ(INTAPE,9160) (IYVAL(I),I=1,NV)                                       
 3730 NM1=NV-1                                                                  
      DO 3740 I=1,M                                                             
      DO 3740 J=1,NM1                                                           
      I1=IYVAL(J)                                                               
      I2=IYVAL(J+1)                                                             
      CALL RQ(I,I1,I2,RIJ,QIJ)                                                  
      R(I,J)=RIJ                                                                
 3740 Q(I,J)=QIJ                                                                
      DO 3750 I=1,NV                                                            
      I1=IYVAL(I)                                                               
      PF(I)=P(I1)                                                               
 3750 E(I)=YVAL(I1)                                                             
      IF(WGT(5).EQ.0.) GO TO 3780                                               
      SF(NV)=0.                                                                 
      DO 3770 J=1,NM1                                                           
      SF(J)=0.                                                                  
      I1=IYVAL(J)                                                               
      I2=IYVAL(J+1)                                                             
      IF(I1.LT.NSL.OR.I2.GT.NSU) GO TO 3770                                     
      SF(J)=SH(I1)/SH(I2)                                                       
 3770 CONTINUE                                                                  
 3780 IF(IPRINT(12).EQ.0) GO TO 1930                                            
      GO TO 20                                                                  
C                                                                               
C  PROGRAM STOP                                                                 
C                                                                               
 3800 STOP                                                                      
C                                                                               
C  TEST, SPECIFIES TEST SOLUTION AND CALCULATES RESPONSES                       
C                                                                               
 3900 IF(PAR(1).EQ.0.) GO TO 3910                                               
      IF(PAR(1).EQ.-1.) GO TO 3920                                              
      GO TO 3940                                                                
C  TEST SOLUTION READ IN BY POINTS                                              
 3910 READ(INTAPE,IVAR) (FTEST(I),I=1,N)                                        
      GO TO 3960                                                                
C  SHAPE OF TEST SOLUTION A*E**B                                                
 3920 DO 3930 I=1,N                                                             
 3930 FTEST(I)=PAR(2)*YVAL(I)**PAR(3)                                           
      GO TO 3960                                                                
C  DOUBLE GAUSSIAN TEST SOLUTION                                                
 3940 DO 3950 I=1,N                                                             
 3950 FTEST(I)=                                                                 
     1PAR(1)*EXP(-((ALOG(YVAL(I))-ALOG(PAR(2)))**2)/(2.*PAR(3)**2))+            
     2PAR(4)*EXP(-((ALOG(YVAL(I))-ALOG(PAR(5)))**2)/(2.*PAR(6)**2))             
 3960 CALL MTMPY(M,N,1,A,FTEST,AI)                                              
      ITEST=1                                                                   
      IF(IRECOL.EQ.1) GO TO 3980                                                
      DO 3970 I=1,M                                                             
      EWGT(I)=1./AI(I)**2                                                       
      CNORM(I)=1.                                                               
 3970 ANAME(I)=KNAME(I)                                                         
      GO TO 3995                                                                
C  NEXT 4 CARDS ARE ASSOCIATED WITH PROTON RECOIL SPECTRUM UNFOLDING            
 3980 DO 3990 I=1,M                                                             
      EWGT(I)=1./AI(I)                                                          
      CNORM(I)=1.                                                               
 3990 PRDEV(I)=SQRT(AMAX1(AI(I),1.))                                            
 3995 WRITE(IOUTAP,9062)                                                        
      CALL MPRINT(FTEST,N,1)                                                    
      WRITE(IOUTAP,9063)                                                        
      CALL MPRINT(AI,M,1)                                                       
      IPERT=0                                                                   
      WRITE(IOUTAP,9210)                                                        
      GO TO 20                                                                  
C                                                                               
C  TITLE, READ TITLE                                                            
C                                                                               
 4000 READ(INTAPE,9040) (TITLE(I),I=1,12)                                       
      WRITE(IOUTAP,9200) (TITLE(I),I=1,12)                                      
      GO TO 20                                                                  
C                                                                               
C  VARMIT, READ VARMIT CONTROL CARD                                             
C                                                                               
 4100 READ(INTAPE,9160) (KVAR(I),I=1,12)                                        
      IF(KVAR(2).GT.6) KVAR(2)=0                                                
      GO TO 20                                                                  
C                                                                               
C  WEIGHT, READ RELATIVE WEIGHTS OF THE CRITERIA                                
C                                                                               
 4200 DO 4210 J=1,6                                                             
 4210 WGT(J)=PAR(J)                                                             
      GO TO 20                                                                  
C                                                                               
C  KFIX, SET UP KERNEL MATRIX                                                   
C                                                                               
 4300 CALL KERNEL(2,1.)                                                         
      IPRINT(12)=0                                                              
      NV=N                                                                      
      GO TO 20                                                                  
C                                                                               
C  KREAD, READ IN RESPONSE FUNCTIONS                                            
C                                                                               
 4400 CALL KERNEL(1,1.)                                                         
      GO TO 20                                                                  
C                                                                               
C  INTEG,  INTEGRAL ABOVE GIVEN THRESHOLD ENERGY                                
C                                                                               
 4500 ET = PAR(1)                                                               
      IR = INT(PAR(2))                                                          
      KH = INT(PAR(3))+1                                                        
      GO TO (4502,4506,4510),KH                                                 
 4502 DO 4504 J=1,N                                                             
 4504 HEL(J) =F(J)                                                              
      GO TO 4515                                                                
 4506 DO 4508 J=1,N                                                             
 4508 HEL(J) = P(J)                                                             
      GO TO 4515                                                                
 4510 DO 4512 J=1,N                                                             
 4512 HEL(J) = FTEST(J)                                                         
 4515 CONTINUE                                                                  
      DO 4520 J=1,N                                                             
      IF(YVAL(J).GT.ET) GO TO 4530                                              
 4520 CONTINUE                                                                  
      L2 = N                                                                    
      GO TO 4535                                                                
 4530 L2 = J                                                                    
 4535 L1 = MAX0((L2-1),1)                                                       
      L3 = MIN0((L2+1),N)                                                       
      Y1 = YVAL(L1)                                                             
      Y2 = YVAL(L2)                                                             
      Y3 = YVAL(L3)                                                             
      FTH = HEL(L1) + (ET-Y1)*(HEL(L2)-HEL(L1))/(Y2-Y1)                         
      IF(IR.GT.0) GO TO 4560                                                    
      FINT = 0.5*(Y2-ET)*FTH                                                    
      FINT = FINT+0.5*(Y3-ET)*HEL(L2)                                           
      IF(L2.EQ.N) GO TO 4555                                                    
      DO 4550 J=L3,N                                                            
 4550 FINT =FINT+WT(J)*HEL(J)                                                   
 4555 WRITE(IOUTAP,9310) ET,FINT                                                
      GO TO 4590                                                                
 4560 S1 = A(IR,L1)/WT(L1)                                                      
      S2 = A(IR,L2)/WT(L2)                                                      
      STH = S1 + (ET-Y1)*(S2-S1)/(Y2-Y1)                                        
      FINT = 0.5*(Y2-ET)*STH*FTH                                                
      FINT = FINT + 0.5*(Y3-ET)*S2*HEL(L2)                                      
      IF(L2.EQ.N) GO TO 4580                                                    
      DO 4570 J=L2,N                                                            
 4570 FINT =FINT+A(IR,J)*HEL(J)                                                 
 4580 WRITE(IOUTAP,9320) IR,ET,FINT                                             
 4590 GO TO 20                                                                  
 4600 GO TO 20                                                                  
C                                                                               
C UNFOLDING WITH DIFFERENT GAMMA VALUES                                         
C                                                                               
 6000 CONTINUE                                                                  
      DO 6100 LGAM=1,NGAM                                                       
      GAM=GAMMA(LGAM)                                                           
C                                                                               
C  MINIMIZATION BY VARMIT                                                       
C                                                                               
      WRITE(IOUTAP,9170)                                                        
      WRITE(IOUTAP,9180)                                                        
      CALL VARMIT                                                               
      WRITE(IOUTAP,9190)                                                        
C  OUTPUT                                                                       
C                                                                               
      CALL RESULT                                                               
C                                                                               
C   IF DESIRED IMPLEMENT IFREEP OPTION                                          
C     IF(NFREEP.LT.1.OR.WGT(1).EQ.0.) GO TO 6100                                
C     CALL FREEP                                                                
C  SUBROUTINE FREEP CARRIES OUT ITERATION USING THE LAST SOLUTIION              
C  AS P VECTOR UNTIL CONVERGENCE IS ACHIEVED, THE OPTION IS                     
C  NOT INCLUDED IN THIS VERSION                                                 
C                                                                               
 6100 CONTINUE                                                                  
      KOUT=KOUT1                                                                
      GO TO 20                                                                  
      END                                                                       
"FOR,IS LOUHI.RESULT   .                                                        
      SUBROUTINE RESULT                                                         
      COMMON/IOTAPE/ INTAPE ,  IOUTAP                                           
      COMMON/WHATS/ CODE, WHAT(6), LMARK, ANAME(30),KNAME(30),CNORM(30)         
      COMMON / /    IALGOR   , IPRINT(15), IYVAL(100) ,  NGAM     ,             
     1  A(30,100),  AF(30)   ,  AFF(30)  ,  AP(30)   ,  AI(30)   ,              
     2  CHI(6)   , CS(30,100),  E(100)   ,  EWGT(30),  FLUX(100),               
     3 FTEST(100),  FWGT(100),  TWGT(100),  DWGT(100),  GAM      ,              
     3  GAMMA(6) ,  P(100)   ,  PF(100)  ,  PWGT(100),  Q(40,100),              
     5  R(30,100),  SF(100)  ,  SH(100)  ,  SWGT(100),  WGT(6)   ,              
     6  YVAL(100),  LGAM                                                        
      COMMON/FEED/ KOUT      , KVAR(15)  , MODE(6)   , NC        ,              
     1 NV        , GUES(100)                                                    
      COMMON/FOLD/ IVAR(9)   , IRECOL    , ITEST     , M         ,              
     1 N         , AIERR(30) , AISAVE(30), CHIIN(6)  , F(100)     ,             
     2 FM(100)    , FP(100)    , PEN(30)   , PRDEV(30) ,RXMAX     ,             
     3 RXMIN     , RYMAX     , RYMIN     , RYSCL     , SCALEL    ,              
     4 TITLE(13) , WT(100)                                                      
      DIMENSION XBEST(100),XERR(100)                                            
      DIMENSION LS(10),WF(3,100)                                                
      INTEGER ANAME                                                             
      COMMON/BEST/FBEST,FERR,XBEST,XERR,IBEST,ISAME                             
      COMMON/HDIAG/HDIAGO(100)                                                  
      DIMENSION  SDEV(100),FLUXP(100),FLUXM(100)                                
      DATA HDIAGO/100*1./                                                       
      DATA XBEST/100*1./                                                 12/10/7
 3007 FORMAT(5X,42H SUM         EWGT(J)*EPS(J)**2          = ,2G14.4)           
 3008 FORMAT(5X,42H AVERAGE/EPS(J)/                        = ,G14.4)            
 3009 FORMAT (/  )                                                              
 5000 FORMAT   ( 6X,26HGRAPH OF THE SOLUTION F(I) /                             
     *           6X,6HF(I)=F /)                                                 
 5010 FORMAT   ( 6X,50HGRAPH OF THE SOLUTION F(I) AND TRIAL SOLUTION P(I        
     *)       / 6X, 16HF(I)=F ,  P(I)=P /)                                      
 5020 FORMAT   ( 6X,53HGRAPH OF THE SOLUTION F(I) AND TEST SOLUTION FTES        
     *T(I)     / 6X,20HF(I)=F ,  FTEST(I)=T )                                   
 5030 FORMAT   ( 6X,74HGRAPH OF THE SOLUTION F(I), TRIAL SOLUTION P(I) A        
     *ND TEST SOLUTION FTEST(I) /                                               
     *           6X,43HYVAL(I)=X ,  F(I)=F ,  P(I)=P ,  FTEST(I)=F /)           
 5040 FORMAT(1H1 / 5X,28HGRAPH OF THE CONFIDENCE BAND /                         
     *           6X,42HUPPER LIMIT FP(I)=U ,  LOWER LIMIT FM(I)=L /)            
 5050 FORMAT(1H1,5X,48HGRAPH OF MEASURED AND CALCULATED RECOIL SPECTRUM         
     *         / 6X,31HPEN(I)=X ,  AI(I)=M , AF(I)=C /)                         
 6006 FORMAT(5X,42H TOTAL SUM (EXCEPT EPS)                 = ,2G14.4)           
 6007 FORMAT(5X,42H GAMMA * TOTAL SUM                      = ,2G14.4)           
 6950 FORMAT(1H1 / 26H    RESULTS OF PROBLEM :   ,12A6 /)                       
 6960 FORMAT(40H     F     =  THE SOLUTION SOUGHT AFTER      /                  
     *       40H     P     =  TRIAL SOLUTION                 /                  
     *       40H     FTEST =  TEST SOLUTION                  /                  
     *       45H     FM    =  LOWER LIMIT OF CONFIDENCE BAND /                  
     *       45H     FP    =  UPPER LIMIT OF CONFIDENCE BAND  //)               
 7004 FORMAT( 53H     J       E(J)        F(J)       FM(J)       FP(J)/)        
 7005 FORMAT( 77H     J       E(J)        F(J)        P(J)         F/P          
     *     FM(J)       FP(J) /)                                                 
 7006 FORMAT( 77H     J       E(J)        F(J)    FTEST(J)      F/FTEST         
     *     FM(J)       FP(J) /)                                                 
 7007 FORMAT(101H     J       E(J)        F(J)        P(J)         F/P          
     * FTEST(J)      F/FTEST      FM(J)       FP(J) /)                          
 7015 FORMAT( 86H1   WEIGHTING FUNCTIONS FOR THE TRIAL SOLUTION NORM Q1         
     1(PWGT), SOLUTION NORM Q2 (FWGT) /  91H    FIRST DERIVATIVE NORM Q3        
     2 (TWGT), SECOND DERIVATIVE NORM Q4 (DWGT), SHAPE NORM Q5 (SWGT) /         
     3 60H    AND THE GIVEN UNNORMALIZED SHAPE OF THE SPECTRUM (SHAPE) )        
 7016 FORMAT(  //89H     J       E(J)     PWGT(J)     FWGT(J)     TWGT(J        
     *)      DWGT(J)     SWGT(J)   SHAPE(J)  //)                                
 7020 FORMAT(1X,I5,2X,11G12.3)                                                  
 7030 FORMAT( 96H     I     LABEL      AF(I)      AI(I)        EPS              
     *EPS %      AF/AI    EWGT(I)   EWGT*EPS**2   //)                           
 7032 FORMAT(104H     I     LABEL      AF(I)      AI(I)        EPS              
     *EPS %      AF/AI    EWGT(I)   EWGT*EPS**2  AP(I)   //)                    
 7036 FORMAT(1X,I5,4X,A6,3X,10G11.3)                                            
 7050 FORMAT(/10H  GAMMA = ,G14.4/)                                             
 7070 FORMAT(5H  J =,I3,11H   WGT(J) =,G12.4,12H   MODE(J) =,I3)                
 7090 FORMAT(//52X,5HFINAL,7X,7HINITIAL/)                                       
 7100 FORMAT(5X,42H SUM         PWGT(I)*(F(I)-P(I))**2     =  ,2G14.4)          
 7101 FORMAT(5X,42H SUM  WGT(1)*PWGT(I)*(F(I)-P(I))**2     =  ,2G14.4)          
 7102 FORMAT(5X,42H SUM         FWGT(I)*F(I)**2            =  ,2G14.4)          
 7103 FORMAT(5X,42H SUM  WGT(2)*FWGT(I)*F(I)**2            =  ,2G14.4)          
 7104 FORMAT(5X,42H SUM         TWGT(I)*(1ST DIFF)**2      =  ,2G14.4)          
 7105 FORMAT(5X,42H SUM  WGT(3)*TWGT(I)*(1ST DIFF)**2      =  ,2G14.4)          
 7106 FORMAT(5X,42H SUM         DWGT(I)*(2ND DIFF)**2      =  ,2G14.4)          
 7107 FORMAT(5X,42H SUM  WGT(4)*DWGT(I)*(2ND DIFF)**2      =  ,2G14.4)          
 7108 FORMAT(5X,42H SUM         SWGT(I)*(SHAPEFIT)**2      =  ,2G14.4)          
 7109 FORMAT(5X,42H SUM  WGT(5)*SWGT(I)*(SHAPEFIT)**2      =  ,2G14.4)          
 7120 FORMAT(//' FIRST ELEMENTS OF THE WEIGHT VECTORS'/)                        
 7180 FORMAT(//)                                                                
 7190 FORMAT(27H1    INTEGRATED QUANTITIES: /)                                  
 7200 FORMAT(29H     INTEGRAL OF THE SOLUTION, 17X, 5HFS = , G13.3 /            
     *       41H     (TOTAL FLUX IN NEUTRON SPECTROSCOPY) )                     
 7210 FORMAT(51H     INTEGRAL OF THE TEST SOLUTION            FT = ,            
     *G13.3/ 10H     RATIO , 33X, 8HFS/FT = ,G13.3)                             
 7220 FORMAT(20H     AVERAGE ENERGY , 24X, 7HEAVS = ,G13.3)                     
 7230 FORMAT(51H     AVERAGE E FROM THE TEST SOLUTION       EAVT = ,            
     *G13.3/ 10H     RATIO ,29X, 12HEAVS/EAVT = ,G13.3)                         
 7240 FORMAT(51H     WEIGHTED INTEGRAL OF THE SOLUTION        DS = ,            
     *G13.3/ 40H     (DOSE RATE IN NEUTRON SPECTROSCOPY) )                      
 7250 FORMAT(51H     WEIGHTED INTEGRAL OF THE TEST SOLUTION   DT = ,            
     *G13.3/ 10H     RATIO , 33X, 8HDS/DT = ,G13.3 )                            
 7260 FORMAT(47H     AVERAGED FITTING ERRORS OF THE RESPONSES:   ,              
     1       32H     (WEIGHTED RESPONSES ONLY)     /)                           
 7270 FORMAT(31H     RELATIVE            EA0 = , G13.3 /                        
     *       31H     ABSOLUTE RELATIVE   EA1 = , G13.3 /                        
     *       31H     SQUARED  RELATIVE   EA2 = , G13.3 )                        
 7280 FORMAT(64H     AVERAGED DEVIATION OF THE SOLUTION FROM THE TEST SO        
     *LUTION:  /)                                                               
 7290 FORMAT(33H     RELATIVE             EF0  = ,G13.3 /                       
     *       33H     ABSOLUTE RELATIVE    EF1  = ,G13.3 /                       
     *       33H     SQUARED  RELATIVE    EF2  = ,G13.3 /                       
     *       33H     LOGARITHMIC          EFL0 = ,G13.3 /                       
     *       33H     ABSOLUTE LOGARITHMIC EFL1 = ,G13.3 /                       
     *       33H     SQUARED  LOGARITHMIC EFL2 = ,G13.3 //)                     
 7300 FORMAT( 96H    INPUT RESPONSES AI, CALCULATED RESPONSES AF, THEIR         
     1DIFFERENCES EPS, RATIOS AND WEIGHTS EWGT   /)                             
 7310 FORMAT(/ 60H    WEIGHTS AND WEIGHTING MODES FOR PRIOR CONDITIONS Q        
     11 - Q5 , /)                                                               
 7320 FORMAT(/  70H    MODE = 1 FOR LINEAR, 2 FOR RELATIVE, 3 FOR LOGARI        
     1THMIC WEIGHTING    /)                                                     
 7330 FORMAT( 5H  J =, I3, 11H  WGT(J) = , G12.4)                               
 7400 FORMAT(1H1 / 34H   ZO(J) = FLUX(J)/FLUX(J+1)    ZI  ,                     
     * 45H(J) = SHAPE(J)/SHAPE(J+1)   ZRAT(J) = ZO/ZI     /)                    
 7410 FORMAT( 53H     J       E(J)       ZO(J)       ZI(J)     ZRAT(J)/)        
C                                                                               
C                                                                               
C                                                                               
      IFREEP=0                                                                  
      CH1 = 2.                                                                  
      IF(IPRINT(10).EQ.1) CH1 =2.*CHI(1)                                        
      IF(IALGOR.NE.2) GO TO 4010                                                
C  MATRIX METHOD                                                                
      DO 4000 I=1,N                                                             
      FLUX(I)=XBEST(I)                                                          
      DF=SQRT(CH1*ABS(HDIAGO(I)))                                               
      FLUXP(I)=FLUX(I)+DF                                                       
      DF=AMIN1(DF,0.95*FLUX(I))                                                 
 4000 FLUXM(I)=FLUX(I)-DF                                                       
      GO TO 4100                                                                
 4010 CONTINUE                                                                  
C                                                                               
C  NONLINEAR METHOD                                                             
C                                                                               
C  CONSTRUCT CONFIDENCE BAND                                                    
C                                                                               
      DO 1 I=1,NV                                                               
      SDEV(I)=SQRT(CH1*ABS(HDIAGO(I)))                                          
      FLUXP(I)=(ABS(XBEST(I))+SDEV(I))**2                                       
      FLUXM(I)=AMAX1(1.E-8,ABS(XBEST(I))-SDEV(I))                               
      FLUXM(I)=FLUXM(I)**2                                                      
    1 FLUX(I)=XBEST(I)*XBEST(I)                                                 
C                                                                               
C  INTERPOLATE SOLUTION AND CONFIDENCE BAND                                     
C  USING VALUES AT FREE POINTS                                                  
C                                                                               
 4100 IF(IYVAL(1).EQ.1)GO TO 3                                                  
      I1=IYVAL(1)-1                                                             
      DO 2 I=1,I1                                                               
      FP(I)=0.                                                                  
      FM(I)=0.                                                                  
    2 F(I)=0.                                                                   
    3 NM1=NV-1                                                                  
      DO 14 J=1,NM1                                                             
      I1=IYVAL(J)                                                               
      I2=IYVAL(J+1)                                                             
      DO 12 I=I1,I2                                                             
      COEF=(YVAL(I)-E(J))/(E(J+1)-E(J))                                         
C                                                                               
C  LINEAR INTERPOLATION IF LINEAR SCALE                                         
C  SPECIFIED ON GRAPHS CARD                                                     
C                                                                               
      IF(IPRINT(5).NE.1) GO TO 10                                               
      F(I)=FLUX(J)+COEF*(FLUX(J+1)-FLUX(J))                                     
      FP(I)=FLUXP(J)+COEF*(FLUXP(J+1)-FLUXP(J))                                 
      FM(I)=FLUXM(J)+COEF*(FLUXM(J+1)-FLUXM(J))                                 
      GO TO 12                                                                  
C                                                                               
C  LIN-LOG INTERPOLATION                                                        
C                                                                               
   10 F(I)=EXP(ALOG(FLUX(J))+COEF*(ALOG(FLUX(J+1))-ALOG(FLUX(J))))              
      FP(I)=EXP(ALOG(FLUXP(J))+COEF*(ALOG(FLUXP(J+1))-ALOG(FLUXP(J))))          
      FM(I)=EXP(ALOG(FLUXM(J))+COEF*(ALOG(FLUXM(J+1))-ALOG(FLUXM(J))))          
   12 CONTINUE                                                                  
   14 CONTINUE                                                                  
      IF(IYVAL(NV).EQ.N)GO TO 6                                                 
      I1=IYVAL(NV)+1                                                            
      DO 5 I=I1,N                                                               
      FP(I)=0.                                                                  
      FM(I)=0.                                                                  
    5 F(I)=0.                                                                   
    6 CONTINUE                                                                  
C                                                                               
C  NO PRINTOUT                                                                  
      IF(IPRINT(15).LE.0) RETURN                                                
      SUM = 0.                                                                  
      SUMMA = 0.                                                                
                                                                                
C  PRINT SOLUTION, TEST SOLUTION ETC.                                           
C                                                                               
      WRITE(IOUTAP,6950) (TITLE(J),J=1,12)                                      
      WRITE(IOUTAP,7050) GAM                                                    
      KPR=2*ITEST+1                                                             
      IF(WGT(1).GT.0.) KPR=KPR+1                                                
   50 GO TO (51,52,53,54),KPR                                                   
   51 WRITE(IOUTAP,7004)                                                        
      GO TO 55                                                                  
   52 WRITE(IOUTAP,7005)                                                        
      GO TO 55                                                                  
   53 WRITE(IOUTAP,7006)                                                        
      GO TO 55                                                                  
   54 WRITE(IOUTAP,7007)                                                        
   55 CONTINUE                                                                  
      DO 65 J=1,NV                                                              
      J1=IYVAL(J)                                                               
      IF(PF(J).NE.0.) DP=FLUX(J)/PF(J)                                          
      IF(PF(J).EQ.0.) DP=0.                                                     
      IF(FTEST(J1).NE.0.) DT=FLUX(J)/FTEST(J1)                                  
      IF(FTEST(J1).EQ.0.) DT=0.                                                 
      GO TO (60,61,62,63),KPR                                                   
   60 WRITE(IOUTAP,7020) J,E(J),FLUX(J),FLUXM(J),FLUXP(J)                       
      GO TO 65                                                                  
   61 WRITE(IOUTAP,7020) J,E(J),FLUX(J),PF(J),DP,FLUXM(J),FLUXP(J)              
      GO TO 65                                                                  
   62 WRITE(IOUTAP,7020) J,E(J),FLUX(J),FTEST(J1),DT,FLUXM(J),FLUXP(J)          
      GO TO 65                                                                  
   63 WRITE(IOUTAP,7020) J,E(J),FLUX(J),PF(J),DP,                               
     *                   FTEST(J),DT,FLUXM(J),FLUXP(J)                          
   65 CONTINUE                                                                  
      IF(WGT(5).EQ.0.) GO TO 70                                                 
      WRITE(IOUTAP,7400)                                                        
      WRITE(IOUTAP,7410)                                                        
      NM1=NV-1                                                                  
      DO 68 J=1,NM1                                                             
      IF(SWGT(J).LE.0.) GO TO 68                                                
      ZO = FLUX(J)/FLUX(J+1)                                                    
      ZRAT = ZO/SF(J)                                                           
      WRITE(IOUTAP,7020) J,E(J),ZO,SF(J),ZRAT                                   
   68 CONTINUE                                                                  
                                                                                
C  PRINT WEIGHTING FUNCTIONS                                                    
                                                                                
   70 IF(IPRINT(8).EQ.0) GO TO 100                                              
      WRITE(IOUTAP,7015)                                                        
      WRITE(IOUTAP,7016)                                                        
      DO 80 J=1,NV                                                              
      J1=IYVAL(J)                                                               
   80 WRITE(IOUTAP,7020) J,E(J),PWGT(J),FWGT(J),TWGT(J),DWGT(J),                
     *SWGT(J),SH(J1)                                                            
C                                                                               
C  PRINT ACTIVITIES                                                             
C                                                                               
  100 WRITE(IOUTAP,6950) (TITLE(J),J=1,12)                                      
      WRITE(IOUTAP,7300)                                                        
      IF(WGT(1).EQ.0.) WRITE(IOUTAP,7030)                                       
      IF(WGT(1).NE.0.) WRITE(IOUTAP,7032)                                       
      DO 110 I=1,M                                                              
      EPS=AF(I)-AI(I)                                                           
      EPP=100.*EPS/AI(I)                                                        
      EWE=EWGT(I)*EPS*EPS                                                       
      RAT=AF(I)/AI(I)                                                           
      SUMMA=SUMMA+EWGT(I)*EPS**2                                                
      SUM=SUM+ABS(EPS)                                                          
      IF(WGT(1).EQ.0.) WRITE(IOUTAP,7036) I,KNAME(I),AF(I),AI(I),EPS,           
     *EPP,RAT,EWGT(I),EWE                                                       
      IF(WGT(1).NE.0.) WRITE(IOUTAP,7036) I,KNAME(I),AF(I),AI(I),EPS,           
     *EPP,RAT,EWGT(I),EWE,AP(I)                                                 
  110 CONTINUE                                                                  
C                                                                               
C  CALCULATE AND PRINT SQUARE INTEGRALS Q                                       
C                                                                               
  180 WRITE(IOUTAP,3009)                                                        
      SUM = SUM/FLOAT(M)                                                        
      WRITE(IOUTAP,7050) GAM                                                    
      WRITE(IOUTAP,7310)                                                        
      WRITE(IOUTAP,7320)                                                        
      DO 182 J=1,5                                                              
  182 WRITE(IOUTAP,7070) J,WGT(J),MODE(J)                                       
      WRITE(IOUTAP,7090)                                                        
      WRITE(IOUTAP,3007)CHI(1),CHIIN(1)                                         
      WRITE (IOUTAP,3008) SUM                                                   
      CHIS=0.                                                                   
      CHISIN=0.                                                                 
      IF(WGT(1).EQ.0.) GO TO 185                                                
      WRITE(IOUTAP,7100) CHI(2),CHIIN(2)                                        
      CHIX=CHI(2)*WGT(1)                                                        
      CHIINX=CHIIN(2)*WGT(1)                                                    
      CHIS=CHIS+CHIX                                                            
      CHISIN=CHISIN+CHIINX                                                      
      WRITE(IOUTAP,7101) CHIX,CHIINX                                            
  185 IF(WGT(2).EQ.0.) GO TO 190                                                
      WRITE(IOUTAP,7102) CHI(3),CHIIN(3)                                        
      CHIX=CHI(3)*WGT(2)                                                        
      CHIINX=CHIIN(3)*WGT(2)                                                    
      CHIS=CHIS+CHIX                                                            
      CHISIN=CHISIN+CHIINX                                                      
      WRITE(IOUTAP,7103) CHIX,CHIINX                                            
  190 IF(WGT(3).EQ.0.) GO TO 193                                                
      WRITE(IOUTAP,7104) CHI(4),CHIIN(4)                                        
      CHIX=CHI(4)*WGT(3)                                                        
      CHIINX=CHIIN(4)*WGT(3)                                                    
      CHIS=CHIS+CHIX                                                            
      CHISIN=CHISIN+CHIINX                                                      
      WRITE(IOUTAP,7105) CHIX,CHIINX                                            
  193 IF(WGT(4).EQ.0.) GO TO 195                                                
      WRITE(IOUTAP,7106) CHI(5),CHIIN(5)                                        
      CHIX=CHI(5)*WGT(4)                                                        
      CHIINX=CHIIN(5)*WGT(4)                                                    
      CHIS=CHIS+CHIX                                                            
      CHISIN=CHISIN+CHIINX                                                      
      WRITE(IOUTAP,7107) CHIX,CHIINX                                            
  195 IF(WGT(5).EQ.0.) GO TO 200                                                
      WRITE(IOUTAP,7108) CHI(6),CHIIN(6)                                        
      CHIX=CHI(6)*WGT(5)                                                        
      CHIINX=CHIIN(6)*WGT(5)                                                    
      CHIS=CHIS+CHIX                                                            
      CHISIN=CHISIN+CHIINX                                                      
      WRITE(IOUTAP,7109) CHIX,CHIINX                                            
  200 CONTINUE                                                                  
      WRITE(IOUTAP,6006)CHIS,CHISIN                                             
      CHIS=CHIS*GAM                                                             
      CHISIN=CHISIN*GAM                                                         
      WRITE(IOUTAP,6007)CHIS,CHISIN                                             
C                                                                               
C                                                                               
C  PLOTTING OF THE SOLUTION,CONFIDENCE BAND,TEST SOLUTION AND TRIAL SPECTRUM    
C                                                                               
      IF(IPRINT(5).EQ.0) GO TO 400                                              
      LK=IPRINT(5)                                                              
      SCU=0.                                                                    
      SCS=0.                                                                    
      SCR=1.E+10                                                                
      IF(IPRINT(6).EQ.0) GO TO 250                                              
      SCU=RYMAX                                                                 
      SCS=RYMIN                                                                 
      SCR=0.                                                                    
  250 DO 260 I=1,N                                                              
      WF(1,I)=F(I)                                                              
      WF(2,I)=P(I)                                                              
  260 WF(3,I)=FTEST(I)                                                          
      LS(1)=1HF                                                                 
      LS(2)=1HP                                                                 
      LS(3)=1HT                                                                 
      K1=1                                                                      
      K2=1                                                                      
      K3=1                                                                      
      WRITE(IOUTAP,6950) (TITLE(J),J=1,12)                                      
      IF(ITEST.GT.0) GO TO 300                                                  
      IF(WGT(1).GT.0.) GO TO 280                                                
      WRITE(IOUTAP,5000)                                                        
      GO TO 320                                                                 
  280 K2=2                                                                      
      WRITE(IOUTAP,5010)                                                        
      GO TO 320                                                                 
  300 K2=3                                                                      
      IF(WGT(1).GT.0.) GO TO 310                                                
      K3=2                                                                      
      LS(2)=1HT                                                                 
      WRITE(IOUTAP,5020)                                                        
      GO TO 320                                                                 
  310 WRITE(IOUTAP,5030)                                                        
  320 WRITE(IOUTAP,7050) GAM                                                    
      CALL GRAPHS(LK,YVAL,1,N,1,3,100,WF,K1,K2,K3,SCS,SCU,SCR,                  
     *            IOUTAP,LS)                                                    
      K2=2                                                                      
      K3=1                                                                      
      DO 330 I=1,N                                                              
      WF(1,I)=FM(I)                                                             
  330 WF(2,I)=FP(I)                                                             
      LS(1)=1HL                                                                 
      LS(2)=1HU                                                                 
      WRITE(IOUTAP,5040)                                                        
      CALL GRAPHS(LK,YVAL,1,N,1,3,100,WF,K1,K2,K3,SCS,SCU,SCR,                  
     *            IOUTAP,LS)                                                    
  350 IF(IRECOL.EQ.0) GO TO 390                                                 
C                                                                               
C  NEXT 8 CARDS CONNECTED WITH PROTON RECOIL SPECTROSCPY                        
C                                                                               
      DO 360 I=1,N                                                              
      WF(1,I)=AI(I)                                                             
  360 WF(2,I)=AF(I)                                                             
      LS(2)=1HC                                                                 
      LS(1)=1HM                                                                 
      WRITE(IOUTAP,5050)                                                        
      CALL GRAPHS(LK,PEN,1,M,1,3,100,WF,K1,K2,K3,0.,0.,1.E+10,                  
     *            IOUTAP,LS)                                                    
  390 CONTINUE                                                                  
  400 CONTINUE                                                                  
      WRITE(IOUTAP,7180)                                                        
C                                                                               
C  TEST QUANTITIES                                                              
C                                                                               
      FS=0.                                                                     
      EAVS=0.                                                                   
      DS=0.                                                                     
      EA0=0.                                                                    
      EA1=0.                                                                    
      EA2=0.                                                                    
      IWD = 0                                                                   
      DO 500 I=1,M                                                              
      EA = 0.                                                                   
      IF(EWGT(I).LE.0.) GO TO 500                                               
      IWD = IWD + 1                                                             
      EA=(AF(I)-AI(I))/(AMAX1(AI(I),1.E-35))                                    
  490 CONTINUE                                                                  
      EA0=EA0+EA                                                                
      EA1=EA1+ABS(EA)                                                           
  500 EA2=EA2+EA*EA                                                             
      EA0 = EA0/FLOAT(IWD)                                                      
      EA1 = EA1/FLOAT(IWD)                                                      
      EA2 = EA2/FLOAT(IWD)                                                      
      DO 510 J=1,N                                                              
      FS=FS+WT(J)*F(J)                                                          
      EAVS=EAVS+WT(J)*YVAL(J)*F(J)                                              
  510 DS=DS+WT(J)*FDOSE(YVAL(J))*F(J)                                           
      EAVS=EAVS/FS                                                              
      IF(ITEST.EQ.0) GO TO 530                                                  
      FT=0.                                                                     
      EAVT=0.                                                                   
      DT=0.                                                                     
      EF0=0.                                                                    
      EF1=0.                                                                    
      EF2=0.                                                                    
      EFL0=0.                                                                   
      EFL1=0.                                                                   
      EFL2=0.                                                                   
      DO 520 I=1,N                                                              
      EF=(F(I)-FTEST(I))/(FTEST(I)*N)                                           
      EF0=EF0+EF                                                                
      EF1=EF1+ABS(EF)                                                           
      EF2=EF2+EF**2*N                                                           
      EFL=ALOG10(ABS((F(I)+1.E-32)/(FTEST(I)+1.E-32)))/N                        
      EFL0=EFL0+EFL                                                             
      EFL1=EFL1+ABS(EFL)                                                        
      EFL2=EFL2+EFL**2*N                                                        
      FT=FT+WT(I)*FTEST(I)                                                      
      EAVT=EAVT+WT(I)*YVAL(I)*FTEST(I)                                          
  520 DT=DT+WT(I)*FDOSE(YVAL(I))*FTEST(I)                                       
      EAVT=EAVT/FT                                                              
      FRAT=FS/FT                                                                
      ERAT=EAVS/EAVT                                                            
      DRAT=DS/DT                                                                
  530 CONTINUE                                                                  
      WRITE(IOUTAP,7190)                                                        
      WRITE(IOUTAP,7200) FS                                                     
      IF(ITEST.NE.0) WRITE(IOUTAP,7210) FT,FRAT                                 
      WRITE(IOUTAP,7220) EAVS                                                   
      IF(ITEST.NE.0) WRITE(IOUTAP,7230) EAVT,ERAT                               
      WRITE(IOUTAP,7240) DS                                                     
      IF(ITEST.NE.0) WRITE(IOUTAP,7250) DT,DRAT                                 
      WRITE(IOUTAP,7180)                                                        
      WRITE(IOUTAP,7260)                                                        
      WRITE(IOUTAP,7270) EA0,EA1,EA2                                            
      WRITE(IOUTAP,7180)                                                        
      IF(ITEST.EQ.0) GO TO 6200                                                 
      WRITE(IOUTAP,7280)                                                        
      WRITE(IOUTAP,7290) EF0,EF1,EF2,EFL0,EFL1,EFL2                             
 6200 CONTINUE                                                                  
      RETURN                                                                    
      END                                                                       
"FOR,IS LOUHI.KERNEL   .                                                        
      SUBROUTINE KERNEL(KDO,HDENS)                                              
C  THIS SUBROUTINE READS IN RESPONSE FUNCTIONS (CROSS SECTIONS)                 
C  AND ENERGY SCALES WITH VARIABLE FORMAT AND SETS UP KERNEL MATRIX             
      COMMON / /    IALGOR   , IPRINT(15), IYVAL(100) ,  NGAM     ,             
     1  A(30,100),  AF(30)   ,  AFF(30)  ,  AP(30)   ,  AI(30)   ,              
     2  CHI(6)   , CS(30,100),  E(100)   ,  EWGT(30),  FLUX(100),               
     3 FTEST(100),  FWGT(100),  TWGT(100),  DWGT(100),  GAM      ,              
     3  GAMMA(6) ,  P(100)   ,  PF(100)  ,  PWGT(100),  Q(40,100),              
     5  R(30,100),  SF(100)  ,  SH(100)  ,  SWGT(100),  WGT(6)   ,              
     6  YVAL(100),  LGAM                                                        
      COMMON/FEED/ KOUT      , KVAR(15)  , MODE(6)   , NC        ,              
     1 NV        , GUES(100)                                                    
      COMMON/FOLD/ IVAR(9)   , IRECOL    , ITEST     , M         ,              
     1 N         , AIERR(30) , AISAVE(30), CHIIN(6)  , F(100)    ,              
     2 FM(100)   , FP(100)   , PEN(30)   , PRDEV(30) , RXMAX     ,              
     3 RXMIN     , RYMAX     , RYMIN     , RYSCL     , SCALEL    ,              
     4 TITLE(13) , WT(100)                                                      
      COMMON/IOTAPE/ INTAPE ,  IOUTAP                                           
      COMMON/WHATS/ CODE,PAR(6),LMARK,ANAME(30),KNAME(30),CNORM(30)             
      DIMENSION KC(30),NCC(30),IFO(9),EE(100),EC(30,100),CR(30,100),            
     *IC(30),CC(100)                                                            
C                                                                               
C  KC(40)        LABELS OF RESPONSE FUNCTIONS READ BY KREAD CARD                
C  NCC(40)       NUMBER OF ENERGY POINTS FOR EACH                               
C                RESPONSE FUNCTION READ IN                                      
C  IFO(9)        VARIABLE FORMAT USED WITH KREAD                                
C  EC(40,40)     ENERGY POINTS FOR EACH RESPONSE FUNCTION                       
C  EE(40)        AUXILIARY VECTOR FOR INTERPOLATION                             
C  CR(40,40)     RESPONSE FUNCTIONS READ IN                                     
C  CC(40)        AUXILIARY VECTOR                                               
      DATA(IFO(I),I=1,9)/6H(8E10.,6H0)    ,7*6H      /                          
      DIMENSION LS(10),LR(5,2)                                                  
      DATA LR/1H1,1H2,1H3,1H4,1H5,1H6,1H7,1H8,1H9,1H0/                          
      DATA LS/1H1,1H2,1H3,1H4,1H5,1H6,1H7,1H8,1H9,1H0/                          
C                                                                               
C                                                                               
 1000 FORMAT(A6,4X,6E10.0)                                                      
 1001 FORMAT(9A6)                                                               
 1002 FORMAT(8E10.0)                                                            
 1003 FORMAT(16I5)                                                              
 1004 FORMAT(18H ** INPUT ERROR **)                                             
 1005 FORMAT(/1X,2I10,4X,A6)                                                    
 1010 FORMAT(/5X,26HRESPONSE FUNCTIONS READ IN/)                                
 1020 FORMAT(//5X,4HI = ,I4,12H    KC(I) = ,A6)                                 
 1030 FORMAT(/5X,12HENERGY SCALE,I5,9H   POINTS/)                               
 1040 FORMAT(/5X,24HRESPONSE FUCTION VALUES  /)                                 
 1050 FORMAT(5X,10G12.4)                                                        
 1070 FORMAT(/5X,48HNUMBER OF RESPONSE FUNCTIONS READ IN           =,I4         
     *       /5X,48HNUMBER OF RESPONSE FUNCTIONS TAKEN INTO KERNEL =,I4         
     *      /5X,48HNUMBER OF ENERGY POINTS IN KERNEL              =,I4/)        
 1080 FORMAT(/5X,12HENERGY SCALE/)                                              
 1090 FORMAT(/5X, 3HI =,I4,16H    KNAME(I) =  ,A6/)                             
 1100 FORMAT(33H1    GRAPH OF RESPONSE FUNCTIONS   ,I3,                         
     *       7H    TO  , I4/)                                                   
 1110 FORMAT(33H1    DISCRETIZED KERNEL MATRIX A /                              
     *        5X,50HI = NUMBER OF RESPONSE, J = NUMBER OF ENERGY POINT/)        
 1120 FORMAT(//)                                                                
 1130 FORMAT(/5X,32HRESPONSE FUNCTION VALUES BY ROWS/)                          
C                                                                               
C  READ CROSS SECTIONS                                                          
C                                                                               
      GO TO (100,200,500),KDO                                                   
  100 MC=INT(PAR(1))                                                            
      DO 150 J=1,MC                                                             
      READ(INTAPE,1000) KC(J),ANC,AKF,AKR,DE,EMIN                               
      NCC(J)=INT(ANC)                                                           
      KF=INT(AKF)                                                               
      KR=INT(AKR)                                                               
      IF(KF.EQ.1) READ(INTAPE,1001) (IFO(I),I=1,9)                              
      IF(NCC(J).EQ.0) NCC(J)=NCC(J-1)                                           
      NCJ=NCC(J)                                                                
      KRI=KR+1                                                                  
      GO TO (110,112,115,120),KRI                                               
  110 DO 111 I=1,NCJ                                                            
  111 EC(J,I)=EC(J-1,I)                                                         
      GO TO 118                                                                 
  112 DO 113 I=1,NCJ                                                            
  113 EC(J,I)=EMIN+(I-1)*DE                                                     
      GO TO 118                                                                 
  115 READ(INTAPE,IFO) (EC(J,I),I=1,NCJ)                                        
  118 READ(INTAPE,IFO) (CR(J,I),I=1,NCJ)                                        
      GO TO 150                                                                 
  120 READ(INTAPE,IFO) (EC(J,I),CR(J,I),I=1,NCJ)                                
  150 CONTINUE                                                                  
      IF(PAR(2).EQ.0.) RETURN                                                   
      WRITE(IOUTAP,1010)                                                        
      DO 160 J=1,MC                                                             
      NCJ=NCC(J)                                                                
      WRITE(IOUTAP,1020) J,KC(J)                                                
      WRITE(IOUTAP,1030) NCJ                                                    
      WRITE(IOUTAP,1050) (EC(J,I),I=1,NCJ)                                      
      WRITE(IOUTAP,1040)                                                        
      WRITE(IOUTAP,1050) (CR(J,I),I=1,NCJ)                                      
      IF(PAR(3).NE.1.) GO TO 160                                                
      DO 155 I=1,NCJ                                                            
  155 EE(I)=EC(J,I)                                                             
      CALL GRAPHS (2,EE,1,NCJ,1,30,100,CR,J,J,1,                                
     *             0.,0.,1.E+4,IOUTAP,LS)                                       
  160 CONTINUE                                                                  
      WRITE(IOUTAP,1120)                                                        
      RETURN                                                                    
C                                                                               
C  SET UP KERNEL, FIRST ENERGIES THEN RESPONSE FUNCTIONS                        
                                                                                
  200 IF(PAR(1).EQ.0.) GO TO 250                                                
      N=INT(PAR(1))                                                             
      KE=INT(PAR(2))+1                                                          
      GO TO (250,210,220,230,232),KE                                            
  210 DE=-1.                                                                    
      READ(INTAPE,IVAR) (YVAL(I),I=1,N)                                         
      GO TO 240                                                                 
  220 DE=PAR(4)                                                                 
      DO 225 I=1,N                                                              
  225 YVAL(I)=FLOAT(I-1)*DE+PAR(3)                                              
      GO TO 240                                                                 
  230 DE=-1.                                                                    
      YVAL(1)=PAR(3)                                                            
      AMUL=PAR(4)                                                               
      GO TO 234                                                                 
  232 AMUL=PAR(4)/PAR(3)                                                        
      AEX=1./FLOAT(N-1)                                                         
      AMUL=AMUL**AEX                                                            
      YVAL(1)=PAR(3)                                                            
      DE=-1.                                                                    
  234 CONTINUE                                                                  
      DO 235 I=2,N                                                              
  235 YVAL(I)=YVAL(I-1)*AMUL                                                    
  240 CALL WEIGHT(WT,N,DE)                                                      
  250 IF(PAR(5).EQ.0.) GO TO 300                                                
      M=INT(PAR(5))                                                             
      DO 255 I=1,M                                                              
  255 IC(I)=I                                                                   
      IF(M.LT.MC) READ(INTAPE,1003) (IC(I),I=1,M)                               
      DO 270 J=1,M                                                              
      K=IC(J)                                                                   
      IF(K.GT.MC) WRITE(IOUTAP,1004)                                            
      IF(K.GT.MC) STOP                                                          
      NCJ=NCC(K)                                                                
      DO 260 I=1,NCJ                                                            
      CC(I)=CR(K,I)                                                             
  260 EE(I)=EC(K,I)                                                             
      KNAME(J)=KC(K)                                                            
      DO 270 I=1,N                                                              
      CALL INTER(NCJ,YVAL(I),EE,CS(J,I),CC)                                     
      A(J,I)=WT(I)*CS(J,I)                                                      
  270 CONTINUE                                                                  
  280 CONTINUE                                                                  
C                                                                               
C  PRINT OR PLOT KERNEL                                                         
C                                                                               
  300 IPR=INT(PAR(6))                                                           
      IF(IPR.EQ.0) GO TO 400                                                    
      WRITE(IOUTAP,1070) MC,M,N                                                 
      IF(IPR.EQ.2) GO TO 320                                                    
      WRITE(IOUTAP,1080)                                                        
      WRITE(IOUTAP,1050) (YVAL(I),I=1,N)                                        
      WRITE(IOUTAP,1130)                                                        
      DO 310 J=1,M                                                              
      WRITE(IOUTAP,1090) J,KNAME(J)                                             
  310 WRITE(IOUTAP,1050) (CS(J,I),I=1,N)                                        
  320 IF(IPR.EQ.1) GO TO 350                                                    
      M5=5                                                                      
      M10=INT((M-1)/M5)+1                                                       
      M11=M-M5*(M10-1)                                                          
      LL=2                                                                      
      M12=1                                                                     
      K1=1                                                                      
      K2=2                                                                      
      DO 340 I=1,M10                                                            
      M13=M12+M5-1                                                              
      IF(I.EQ.M10) M13=M12+M11-1                                                
      WRITE(IOUTAP,1100) M12,M13                                                
      DO 330 J=1,5                                                              
  330 LS(J)=LR(J,K1)                                                            
      K3=K1                                                                     
      K1=K2                                                                     
      K2=K3                                                                     
      CALL GRAPHS (LL,YVAL,1,N,1,30,100,CS,M12,M13,1,                           
     *             0.,0.,1.E+4,IOUTAP,LS)                                       
  340 M12=M12+M5                                                                
  350 IF(IPR.LT.4) GO TO 400                                                    
      WRITE(IOUTAP,1120)                                                        
      WRITE(IOUTAP,1120)                                                        
      WRITE(IOUTAP,1110)                                                        
      CALL MPRINT(A,M,N)                                                        
  400 WRITE(IOUTAP,1120)                                                        
      RETURN                                                                    
C                                                                               
C  SET UP PROTON RECOIL KERNEL                                                  
C  ON THE FOLLOWING CARDS A RECOIL PROTON KERNEL IS SET UP                      
C  USING AN ANALYTICAL FORMULA, FOR OTHER PURPOSES THE CARDS                    
C  FROM LABEL 500 TO LABEL 640 CAN BE DELETED                                   
C                                                                               
  500 K=INT(PAR(4))+1                                                           
      GO TO (510,520,530),K                                                     
  510 READ(INTAPE,IVAR) (PEN(I),I=1,M)                                          
      GO TO 540                                                                 
  520 READ(INTAPE,1002) DP,PMIN                                                 
      DO 525 I=1,M                                                              
  525 PEN(I)=FLOAT(I-1)*DP+PMIN                                                 
      GO TO 540                                                                 
  530 READ(INTAPE,1002) DP,PMIN                                                 
      PEN(1)=PMIN                                                               
      DO 535 I=2,M                                                              
  535 PEN(I)=PEN(I-1)*DP                                                        
  540 K=INT(PAR(5))+1                                                           
      GO TO (550,560,570,580),K                                                 
  550 READ(INTAPE,IVAR) (YVAL(I),I=1,N)                                         
      DE=-1.                                                                    
      GO TO 590                                                                 
  560 READ(INTAPE,1002) DE,EMIN                                                 
      DO 565 I=1,N                                                              
  565 YVAL(I)=FLOAT(I-1)*DE+EMIN                                                
      GO TO 590                                                                 
  570 READ(INTAPE,1002) DE,EMIN                                                 
      YVAL(1)=EMIN                                                              
      DO 575 I=2,N                                                              
  575 YVAL(I)=YVAL(I-1)*DE                                                      
      GO TO 590                                                                 
  580 DO 585 I=1,N                                                              
  585 YVAL(I)=PEN(I)                                                            
  590 DO 640 J=1,M                                                              
      DO 620 I=1,N                                                              
      IF(PEN(J).GT.YVAL(I)) GO TO 600                                           
      CS(J,I)=3.*3.14159/(1.206*YVAL(I)+(.000136*YVAL(I)*YVAL(I)+.09415*        
     *       YVAL(I)-1.86)**2)+3.14159/(1.206*YVAL(I)+(.13*YVAL(I)+             
     *       .4223)**2)                                                         
      CS(J,I)=CS(J,I)*HDENS                                                     
      IF(PAR(4).EQ.1.) GO TO 610                                                
  600 CS(J,I)=0.                                                                
      GO TO 620                                                                 
  610 CS(J,I)=CS(J,I)/YVAL(I)                                                   
  620 CONTINUE                                                                  
      DO 630 I=1,N                                                              
  630 A(J,I)=CS(J,I)*WT(I)                                                      
  640 CONTINUE                                                                  
      RETURN                                                                    
      END                                                                       
"FOR,IS LOUHI.INTER  .                                                          
      SUBROUTINE INTER(N,XIN,X,YOUT,Y)                                          
C                                                                               
C  THIS SUBROUTINE CARRIES OUT LINEAR INTERPOLATION.                            
C  YOUT IS THE INTERPOLATED VALUE OF Y AT POINT XIN. IF                         
C  XIN LIES OUTSIDE KNOWN POINTS THE Y VALUE AT EITHER                          
C  ENDPOINT IS ASSIGNED TO YVAL. N IS THE NUMBER OF KNOWN                       
C  POINTS                                                                       
C                                                                               
      DIMENSION X(1),Y(1)                                                       
      IF(N.GT.1) GO TO 10                                                       
      I=1                                                                       
      GO TO 30                                                                  
   10 IF(XIN.GT.X(1)) GO TO 20                                                  
      I=1                                                                       
      GO TO 30                                                                  
   20 IF(XIN.LT.X(N)) GO TO 50                                                  
      I=N                                                                       
   30 YOUT=Y(I)                                                                 
      RETURN                                                                    
   50 I=0                                                                       
   80 I=I+1                                                                     
      IF(XIN.GT.X(I)) GO TO 80                                                  
      R=(XIN-X(I-1))/(X(I)-X(I-1))                                              
      YOUT=Y(I-1)+R*(Y(I)-Y(I-1))                                               
      RETURN                                                                    
      END                                                                       
"FOR,IS LOUHI.SCALE  .                                                          
      SUBROUTINE SCALE(K,KEXP,MN,FSCL,FWGT,IVAR)                                
      DIMENSION FSCL(100),FWGT(100),WREAD(100),IVAR(9)                          
C                                                                               
C THIS SUBROUTINE ASSIGNS WEIGHTS USING ARRAY FSCL                              
C AND INPUT WEIGHTS WREAD(I)                                                    
C                                                                               
      COMMON/IOTAPE/INTAPE,IOUTAP                                               
      DATA FSCLMN,SCLMIN/1.0E-18,1.0E+20/                                       
      DO 5 I=1,MN                                                               
      IF(FSCL(I).NE.0.)SCLMIN=AMIN1(SCLMIN,ABS(FSCL(I)))                        
    5 SCLMIN=AMAX1(SCLMIN,FSCLMN)                                               
C                                                                               
C  K IS PAR(1) ON SCALE CARDS                                                   
C                                                                               
      DO 61 I=1,MN                                                              
   61 FWGT(I)=10.**KEXP                                                         
      GO TO (10,10,20,20,30,30,10,10,20,20,30,30),K                             
   10 CONTINUE                                                                  
      GO TO 40                                                                  
   20 DO 21 I=1,MN                                                              
      SCL=AMAX1(SCLMIN,ABS(FSCL(I)))                                            
   21 FWGT(I)=FWGT(I)/SCL                                                       
      GO TO 40                                                                  
   30 DO 31 I=1,MN                                                              
      SCL=AMAX1(SCLMIN,ABS(FSCL(I)))                                            
   31 FWGT(I)= (FWGT(I)/SCL)/SCL                                                
   40 DO 41 I=1,6                                                               
      IF(K.EQ.2*I-1)GO TO 45                                                    
   41 CONTINUE                                                                  
      RMN=FLOAT(MN)                                                             
      DO 42 I=1,MN                                                              
   42 FWGT(I)=FWGT(I)/RMN                                                       
   45 IF(K.LE.6)GO TO 60                                                        
      READ(INTAPE,IVAR)(WREAD(I),I=1,MN)                                        
      DO 50 I=1,MN                                                              
   50 FWGT(I)=FWGT(I)*WREAD(I)                                                  
   60 RETURN                                                                    
      END                                                                       
"FOR,IS LOUHI.WEIGHT  .                                                         
      SUBROUTINE WEIGHT(WT,N,DY)                                                
C                                                                               
C  THIS ROUTINE ASSIGNS QUADRATURE WEIGHTS FOR INTEGRATION SCHEMES              
C                                                                               
      COMMON / /    IALGOR   , IPRINT(15), IYVAL(100) ,  NGAM     ,             
     1  A(30,100),  AF(30)   ,  AFF(30)  ,  AP(30)   ,  AI(30)   ,              
     2  CHI(6)   , CS(30,100),  E(100)   ,  EWGT(30),  FLUX(100),               
     3 FTEST(100),  FWGT(100),  TWGT(100),  DWGT(100),  GAM      ,              
     3  GAMMA(6) ,  P(100)   ,  PF(100)  ,  PWGT(100),  Q(40,100),              
     5  R(30,100),  SF(100)  ,  SH(100)  ,  SWGT(100),  WGT(6)   ,              
     6  YVAL(100),  LGAM                                                        
      DIMENSION WT(100)                                                         
      IF(DY.LT.0.)GO TO 70                                                      
      IF (N.GE.4) GO TO 50                                                      
      GO TO (10,20,30), N                                                       
   10 WT(1) = DY                                                                
      RETURN                                                                    
   20 WT(1) = .5*DY                                                             
      WT(2) = WT(1)                                                             
      RETURN                                                                    
   30 D = DY/3.                                                                 
      WT(1) = D                                                                 
      WT(2) = 4.*D                                                              
      WT(3) = D                                                                 
      RETURN                                                                    
C FOR MORE THAN 3 POINTS USE GREGORY WTS. WITH 2ND DIFFERENCES NEGLECTED        
   50 D = DY/12.                                                                
      WT(1) = 5.*D                                                              
      WT(2) = 13.*D                                                             
      WT(N-1) = WT(2)                                                           
      WT(N) = WT(1)                                                             
      IF (N.EQ.4) RETURN                                                        
      K = N-2                                                                   
      DO 60 I=3,K                                                               
   60 WT(I) = DY                                                                
      RETURN                                                                    
C FOR NONUNIFORMLY SPACED YVAL(I) USE TRAPEZOIDAL WEIGHTING                     
   70 IF(N.GE.2)GO TO 80                                                        
      WT(1)=1.                                                                  
      RETURN                                                                    
   80 WT(1)=0.5*(YVAL(2)-YVAL(1))                                               
      WT(N)=0.5*(YVAL(N)-YVAL(N-1))                                             
      IF(N.EQ.2)RETURN                                                          
      K=N-1                                                                     
      DO 90 I=2,K                                                               
   90 WT(I)=0.5*(YVAL(I+1)-YVAL(I-1))                                           
      RETURN                                                                    
      END                                                                       
"FOR,IS LOUHI.RQ  .                                                             
      SUBROUTINE RQ(K,M,N,RR,QQ)                                                
C                                                                               
C  THIS ROUTINE CALCULATES ELEMENTS OF THE AUXILIARY                            
C  MATRICES R (RR) AND S (QQ) USED WITH THE STEPS OPTION                        
C                                                                               
      COMMON / /    IALGOR   , IPRINT(15), IYVAL(100) ,  NGAM     ,             
     1  A(30,100),  AF(30)   ,  AFF(30)  ,  AP(30)   ,  AI(30)   ,              
     2  CHI(6)   , CS(30,100),  E(100)   ,  EWGT(30),  FLUX(100),               
     3 FTEST(100),  FWGT(100),  TWGT(100),  DWGT(100),  GAM      ,              
     3  GAMMA(6) ,  P(100)   ,  PF(100)  ,  PWGT(100),  Q(40,100),              
     5  R(30,100),  SF(100)  ,  SH(100)  ,  SWGT(100),  WGT(6)   ,              
     6  YVAL(100),  LGAM                                                        
      Z1=0.5*(YVAL(M+1)-YVAL(M))*CS(K,M)                                        
      Z2=0.5*(YVAL(N)-YVAL(N-1))*CS(K,N)                                        
      RR=Z1+Z2                                                                  
      QQ=Z1*YVAL(M)+Z2*YVAL(N)                                                  
      IF(N-M.LE.1) RETURN                                                       
      M1=M+1                                                                    
      N1=N-1                                                                    
      DO 1 I=M1,N1                                                              
      Z=0.5*(YVAL(I+1)-YVAL(I-1))*CS(K,I)                                       
      RR=RR+Z                                                                   
    1 QQ=QQ+Z*YVAL(I)                                                           
      RETURN                                                                    
      END                                                                       
"FOR,IS LOUHI.MTMPY  .                                                          
      SUBROUTINE MTMPY(L,M,N,A,B,C)                                             
C COMPUTES A*B=C, WHERE A IS LXM, B IS MXN, C IS LXN.                           
C                                                                               
      DIMENSION A(30,1),B(100,1),C(30,1)                                        
C                                                                               
      DO 50 J=1,N                                                               
      DO 50 I=1,L                                                               
      SUM = 0.                                                                  
      DO 40 K=1,M                                                               
   40 SUM = SUM+A(I,K)*B(K,J)                                                   
   50 C(I,J) = SUM                                                              
      RETURN                                                                    
      END                                                                       
"FOR,IS LOUHI.MPRINT  .                                                         
      SUBROUTINE MPRINT(X,M,N)                                                  
C  THIS SUBROUTINE PRINTS OUT MATRIX A                                          
      COMMON/IOTAPE/INTAPE,IOUTAP                                               
      DIMENSION X(30,1)                                                         
    3 FORMAT (1H0,2X,3HI/J,6X,I2,7I14)                                          
    5 FORMAT (I4,E15.4,7E14.4)                                                  
C                                                                               
      K1 = 1                                                                    
      K2 = MIN0(8,N)                                                            
    2 WRITE (IOUTAP,3) (I,I=K1,K2)                                              
      DO 4 I=1,M                                                                
    4 WRITE (IOUTAP,5) I,(X(I,J),J=K1,K2)                                       
      IF (K2.GE.N) RETURN                                                       
      K1 = K1+8                                                                 
      K2 = K2+8                                                                 
      K2 = MIN0(K2,N)                                                           
      GO TO 2                                                                   
      END                                                                       
"FOR,IS LOUHI.GRAPHS  .                                                         
      SUBROUTINE GRAPHS (LL,X,M1,M2,M3,N1,N2,Y,L1,L2,L3,                        
     *                   FMIN,FMAX,SCL,IT,LS)                                   
C MAKES A PRINTER GRAPH OF UP TO TEN ARRAYS AS A FUNCTION OF ONE ARRAY,         
C LL=1 FOR LINEAR FUNCTION SCALE, LL=2 FOR LOGARITHMIC SCALE,                   
C X CONTAINS THE ARGUMENT ARRAY OF WHICH EVERY M3 POINTS BETWEEN M1 AND         
C M2 ARE PLOTTED, A MATRIX Y OF DIMENSIONS N1 X N2 CONTAINS N1 FUNCTION         
C ARRAYS WITH N2 POINTS IN EACH, EVERY L3 ARRAY BETWEEN L1 AND L2 ARE           
C PLOTTED. FMIN AND FMAX SPECIFY THE MINIMUM AND THE MAXIMUM OF THE             
C FUNCTION SCALE, AND SCL THE RATIO FMAX/FMIN, ZERO ENTRIES CAUSE THESE         
C PARAMETERS TO BE COMPUTED INTERNALLY. IT SPECIFIES THE NUMBER OF THE          
C OUTPUT FILE. CODED BY JORMA ROUTTI, CERN, GENEVA, DECEMBER 1970.              
      DIMENSION X(1),Y(N1,N2),L(100),LS(10),LJ(10)                              
      DATA L,LB,LI/101*1H ,1HI/                                                 
      IF((FMIN.NE.0.).AND.(FMAX.NE.0.))GO TO 10                                 
      SMIN=Y(L1,M1)                                                             
      SMAX=Y(L1,M1)                                                             
      DO 5 I=M1,M2,M3                                                           
      DO 5 J=L1,L2,L3                                                           
      SMIN=AMIN1(SMIN,Y(J,I))                                                   
    5 SMAX=AMAX1(SMAX,Y(J,I))                                                   
   10 IF(FMIN.NE.0.)SMIN=FMIN                                                   
      IF(FMAX.NE.0.)SMAX=FMAX                                                   
      IF(SCL.NE.0.)SMIN=SMAX/SCL                                                
      IF(SMAX.EQ.SMIN)SMAX=SMIN+1.                                              
      IF(LL.EQ.1)GO TO 15                                                       
      IF(SMAX.LE.0.)SMAX=1.                                                     
      IF(SMIN.GT.0.)GO TO 15                                                    
      SMIN=SMAX/1.0E+20                                                         
   15 FDIF=SMAX-SMIN                                                            
      IF(LL.EQ.2)FLOG=ALOG10(SMAX/SMIN)                                         
      ISCL=6HLINEAR                                                             
      IF(LL.EQ.2)ISCL=6HLOGAR.                                                  
      WRITE(IT,1000)SMIN,LB,(LI,I=1,22),ISCL,(LI,I=1,32),SMAX                   
 1000 FORMAT(//13H     E       ,E13.5,23A1,1X,A10,7H SCALE ,32A1,E13.5)         
      DO 60 I=M1,M2,M3                                                          
      IP=0                                                                      
      DO 50 J=L1,L2,L3                                                          
      IP=IP+1                                                                   
      YY=AMAX1(SMIN,AMIN1(SMAX,Y(J,I)))                                         
      GO TO(30,35),LL                                                           
   30 IO=3.+97.*(YY-SMIN)/FDIF                                                  
      GO TO 40                                                                  
   35 YY=YY/SMIN                                                                
      YY=AMAX1(YY,1.E-36)                                                       
      IO=3.+97.*ALOG10(YY)/FLOG                                                 
   40 L(IO)=LS(IP)                                                              
   50 LJ(IP)=IO                                                                 
      WRITE(IT,1001)X(I),(L(J),J=1,100)                                         
 1001 FORMAT(E13.5,100A1)                                                       
      DO 55 J=1,IP                                                              
      IO=LJ(J)                                                                  
   55 L(IO)=LB                                                                  
   60 CONTINUE                                                                  
      WRITE(IT,1002)(LI,I=1,100)                                                
 1002 FORMAT(13X,100A1)                                                         
      RETURN                                                                    
      END                                                                       
"FOR,IS LOUHI.FDOSE  .                                                          
      REAL FUNCTION FDOSE(E)                                                    
C                                                                               
C  THIS ROUTINE COMPUTES NEUTRON FLUX TO DOSE RATE CONVERSION                   
C  FACTORS ACCORDING TO A FORMULA GIVEN BY R.H. THOMAS,                         
C  THE RADIATION FIELDS OBSERVED AROUND HIGH-ENERGY NUCLEAR                     
C  ACCELERATORS, IN THE PROCEEDINGS OF XI INTERNATIONAL                         
C  CONGRESS OF RADIOLOGY, ROME, ITALY, 1965)                                    
C  THE ENERGY IS IN MEV.  IF THE FLUX IS OBTAINED IN                            
C  1/CM**2/SEC/MEV THE DOSE RATE IS IN MILLIREMS PER HOUR.                      
C  NOTE THAT THE UNIT OF FLUX IS DETERMINED BY THE UNITS                        
C  OF CROSS SECTIONS AND INPUT ACTIVITIES.                                      
C                                                                               
      IF(E.LE.0.01)FDOSE=0.00431                                                
      IF(E.GT.0.01.AND.E.LE.1.)FDOSE=0.139*E**0.75                              
      IF(E.GT.1..AND.E.LE.10.)FDOSE=0.139                                       
      IF(E.GT.10.)FDOSE=0.0781*E**0.25                                          
      RETURN                                                                    
      END                                                                       
"FOR,IS LOUHI.FCN  .                                                            
      SUBROUTINE FCN(NVAR,G,FF,X,M1)                                            
C                                                                               
C  THIS ROUTINE CALCULATES THE OBJECTIVE FUNCTION AND ITS                       
C  GRADIENT FOR THE NONLINEAR MINIMIZATION ALGORITHM VARMIT                     
C                                                                               
C  NVAR     NUMBER OF VARIABLES = NUMBER OF FREE ENERGY POINTS                  
C  G        GRADIENT VECTOR                                                     
C  FF       OBJECTIVE FUNCTION, Q IN WRITEUP                                    
C  X        VECTOR OF UNKNOWNS, THE SPECTRUM VALUES                             
C           ARE F(J) = X(J)**2                                                  
C  M1       FLAG FOR FIRST CALL                                                 
C                                                                               
      COMMON / /    IALGOR   , IPRINT(15), IYVAL(100) ,  NGAM     ,             
     1  A(30,100),  AF(30)   ,  AFF(30)  ,  AP(30)   ,  AI(30)   ,              
     2  CHI(6)   , CS(30,100),  E(100)   ,  EWGT(30),  FLUX(100),               
     3 FTEST(100),  FWGT(100),  TWGT(100),  DWGT(100),  GAM      ,              
     3  GAMMA(6) ,  P(100)   ,  PF(100)  ,  PWGT(100),  Q(40,100),              
     5  R(30,100),  SF(100)  ,  SH(100)  ,  SWGT(100),  WGT(6)   ,              
     6  YVAL(100),  LGAM                                                        
      COMMON/IOTAPE/ INTAPE ,  IOUTAP                                           
      COMMON/FEED/ KOUT      , KVAR(15)  , MODE(6)   , NC        ,              
     1 NV        , GUES(100)                                                    
      COMMON/FOLD/ IVAR(9)   , IRECOL    , ITEST     , M         ,              
     1 N         , AIERR(30) , AISAVE(30), CHIIN(6)  , F(100)    ,              
     2 FM(100)   , FP(100)   , PEN(30)   , PRDEV(30) , RXMAX     ,              
     3 RXMIN     , RYMAX     , RYMIN     , RYSCL     , SCALEL    ,              
     4 TITLE(13) , WT(100)                                                      
      DIMENSION W(100),FTERM(100),X(100),G(100)                                 
      DIMENSION DSUM(30,100)                                                    
      NVAR=NV                                                                   
C                                                                               
C  FIRST CALL RETURNS NUMBER OF VARIABLES                                       
C                                                                               
      IF(M1.EQ.1) M2=0                                                          
      IF(M1.EQ.1) RETURN                                                        
      M2=M2+1                                                                   
  100 NM1=NV-1                                                                  
      NM2=NV-2                                                                  
C                                                                               
C  NONLINEAR OBJECTIVE FUNCTION                                                 
C                                                                               
      IF(IALGOR.NE.1) GO TO 3000                                                
C                                                                               
C  EPSILONS OR DIFFERENCES FROM MEASURED ACTIVITIES, Q0                         
C                                                                               
      FF=0.                                                                     
      DO 220 I=1,M                                                              
      SUM=0.                                                                    
      DO 200 J=1,NM1                                                            
  200 SUM=SUM+X(J)*X(J)*R(I,J)+(X(J+1)*X(J+1)-X(J)*X(J))                        
     B*(Q(I,J)-E(J)*R(I,J))/(E(J+1)-E(J))                                       
      AF(I)=SUM                                                                 
      FTERM(I)=SUM-AI(I)                                                        
      FF=FF+EWGT(I)*FTERM(I)*FTERM(I)                                           
      DSUM(I,1)=2.*X(1)*(R(I,1)*E(2)-Q(I,1))/(E(2)-E(1))                        
      DO 210 K=2,NM1                                                            
  210 DSUM(I,K)=2.*X(K)*((R(I,K)*E(K)-Q(I,K))/(E(K+1)-E(K))+                    
     B(Q(I,K-1)-E(K-1)*R(I,K-1))/(E(K)-E(K-1))+R(I,K))                          
      DSUM(I,NV)=2.*X(NV)*(Q(I,NM1)-E(NM1)*R(I,NM1))                            
     B           /(E(NV)-E(NM1))                                                
  220 CONTINUE                                                                  
      CHI(1)=FF                                                                 
      DO 240 K=1,NV                                                             
      G(K)=0.                                                                   
      DO 230 I=1,M                                                              
  230 G(K)=G(K)+2.*FTERM(I)*DSUM(I,K)*EWGT(I)                                   
  240 CONTINUE                                                                  
C                                                                               
C   DIVERGENCE FROM P-VECTOR, Q1                                                
      IF(WGT(1).EQ.0.) GO TO 400                                                
      CHI(2)=0.                                                                 
      D1=GAM*WGT(1)                                                             
      MOD=MODE(1)                                                               
      IF(MOD.EQ.3) GO TO 350                                                    
      DO 300 I=1,NV                                                             
  300 W(I)=X(I)*X(I)-PF(I)                                                      
      GO TO (310,330),MOD                                                       
  310 DO 320 I=1,NV                                                             
      G(I)=G(I)+4.*D1*PWGT(I)*W(I)*X(I)                                         
  320 CHI(2)=CHI(2)+W(I)*W(I)*PWGT(I)                                           
      GO TO 370                                                                 
  330 DO 340 I=1,NV                                                             
      G(I)=G(I)+4.*D1*PWGT(I)*W(I)*(1.-W(I)/(X(I)*X(I)))/X(I)**3                
  340 CHI(2)=CHI(2)+W(I)*W(I)*PWGT(I)/X(I)**4                                   
      GO TO 370                                                                 
  350 DO 360 I=1,NV                                                             
      W(I)=ALOG(X(I)*X(I))-ALOG(PF(I))                                          
      G(I)=G(I)+4.*D1*PWGT(I)*W(I)/X(I)                                         
  360 CHI(2)=CHI(2)+W(I)*W(I)*PWGT(I)                                           
  370 FF=FF+D1*CHI(2)                                                           
  400 IF(WGT(2).EQ.0.) GO TO 500                                                
C                                                                               
C   FUNCTION F, Q2                                                              
C                                                                               
      CHI(3)=0.                                                                 
      MOD=MODE(2)                                                               
      IF(MOD.EQ.2) GO TO 500                                                    
      D1=GAM*WGT(2)                                                             
      IF(MOD.EQ.3) GO TO 420                                                    
      DO 410 I=1,NV                                                             
      G(I)=G(I)+4.*D1*FWGT(I)*X(I)**3                                           
  410 CHI(3)=CHI(3)+FWGT(I)*X(I)**4                                             
      GO TO 450                                                                 
  420 DO 430 I=1,NV                                                             
      W(I)=ALOG(X(I)*X(I))                                                      
      G(I)=G(I)+4.*D1*FWGT(I)*W(I)/X(I)                                         
  430 CHI(3)=CHI(3)+FWGT(I)*W(I)*W(I)                                           
  450 FF=FF+D1*CHI(3)                                                           
C                                                                               
C   FIRST DIFFERENCES, Q3                                                       
C                                                                               
  500 IF(WGT(3).EQ.0.) GO TO 700                                                
      CHI(4)=0.                                                                 
      D1=GAM*WGT(3)                                                             
      MOD=MODE(3)                                                               
      IF(MOD.EQ.3) GO TO 580                                                    
      DO 510 I=1,NM1                                                            
  510 W(I)=X(I)*X(I)-X(I+1)*X(I+1)                                              
      GO TO (520,550),MOD                                                       
  520 DO 530 I=1,NM1                                                            
      G(I)=G(I)+D1*4.*W(I)*X(I)*TWGT(I)                                         
  530 CHI(4)=CHI(4)+TWGT(I)*W(I)*W(I)                                           
      DO 540 I=1,NM1                                                            
  540 G(I)=G(I)-D1*4.*W(I-1)*X(I)*TWGT(I-1)                                     
      GO TO 620                                                                 
  550 DO 560 I=1,NM1                                                            
      G(I)=G(I)+D1*4.*W(I)*X(I+1)*X(I+1)/X(I)**5*TWGT(I)                        
  560 CHI(4)=CHI(4)+W(I)*W(I)/X(I)**4*TWGT(I)                                   
      DO 570 I=2,NV                                                             
  570 G(I)=G(I)-D1*4.*W(I-1)*X(I)*TWGT(I-1)/X(I-1)**4                           
      GO TO 620                                                                 
  580 DO 590 I=1,NM1                                                            
  590 W(I)=ALOG(X(I)*X(I))-ALOG(X(I+1)*X(I+1))                                  
      DO 600 I=1,NM1                                                            
      G(I)=G(I)+D1*4.*W(I)*TWGT(I)/X(I)                                         
  600 CHI(4)=CHI(4)+W(I)*W(I)*TWGT(I)                                           
      DO 610 I=2,NV                                                             
  610 G(I)=G(I)-D1*4.*W(I-1)*TWGT(I)/X(I)                                       
  620 FF=FF+D1*CHI(4)                                                           
C                                                                               
C   2ND DIFFERENCES, Q4                                                         
C                                                                               
  700 IF(WGT(4).EQ.0.) GO TO 900                                                
      CHI(5)=0.                                                                 
      D1=GAM*WGT(4)                                                             
      MOD=MODE(4)                                                               
      IF(MOD.EQ.3) GO TO 800                                                    
      DO 710 I=2,NM1                                                            
  710 W(I)=X(I-1)*X(I-1)-2.*X(I)*X(I)+X(I+1)*X(I+1)                             
      GO TO (720,760),MOD                                                       
  720 DO 730 I=1,NM2                                                            
  730 G(I)=G(I)+D1*4.*W(I+1)*X(I)*DWGT(I+1)                                     
      DO 740 I=2,NM1                                                            
      G(I)=G(I)-D1*8.*W(I)*X(I)*DWGT(I+1)                                       
  740 CHI(5)=CHI(5)+W(I)*W(I)*DWGT(I)                                           
      DO 750 I=3,NV                                                             
  750 G(I)=G(I)+D1*4.*W(I-1)*X(I)*DWGT(I-1)                                     
      GO TO 870                                                                 
  760 DO 770 I=1,NM2                                                            
  770 G(I)=G(I)+D1*4.*W(I+1)*X(I)*DWGT(I+1)/X(I+1)**4                           
      DO 780 I=2,NM1                                                            
      G(I)=G(I)-D1*4.*W(I)*DWGT(I)*(2.+W(I)/(X(I)*X(I)))/X(I)**3                
  780 CHI(5)=CHI(5)+W(I)*W(I)*DWGT(I)/X(I)**4                                   
      DO 790 I=3,NV                                                             
  790 G(I)=G(I)+D1*4.*W(I-1)*X(I)*DWGT(I-1)/X(I-1)**4                           
      GO TO 870                                                                 
  800 DO 810 I=2,NM1                                                            
  810 W(I)=ALOG(X(I-1)*X(I-1))-2.*ALOG(X(I)*X(I))+ALOG(X(I+1)*X(I+1))           
      DO 820 I=1,NM2                                                            
  820 G(I)=G(I)+D1*4.*W(I+1)*DWGT(I+1)/X(I)                                     
      DO 830 I=2,NM1                                                            
      G(I)=G(I)-D1*8.*W(I)*DWGT(I)/X(I)                                         
  830 CHI(5)=CHI(5)+W(I)*W(I)*DWGT(I)                                           
      DO 840 I=3,NV                                                             
  840 G(I)=G(I)+D1*4.*W(I-1)*DWGT(I-1)/X(I)                                     
  870 FF=FF+D1*CHI(5)                                                           
C                                                                               
C   SHAPE, Q5                                                                   
C                                                                               
  900 IF(WGT(5).EQ.0.) GO TO 1030                                               
      CHI(6)=0.                                                                 
      D1=GAM*WGT(5)                                                             
      MOD=MODE(5)                                                               
      IF(MOD.EQ.3) GO TO 980                                                    
      DO 910 I=1,NM1                                                            
  910 W(I)=X(I)*X(I)-SF(I)*X(I+1)*X(I+1)                                        
      GO TO (920,950),MOD                                                       
  920 DO 930 I=1,NM1                                                            
      G(I)=G(I)+D1*4.*W(I)*X(I)*SWGT(I)                                         
  930 CHI(6)=CHI(6)+SWGT(I)*W(I)*W(I)                                           
      DO 940 I=2,NV                                                             
  940 G(I)=G(I)+D1*4.*W(I-1)*X(I)*SF(I-1)*SWGT(I-1)                             
      GO TO 1020                                                                
  950 DO 960 I=1,NM1                                                            
      G(I)=G(I)+D1*4.*W(I)*SF(I)*X(I+1)*X(I+1)/X(I)**5                          
  960 CHI(6)=CHI(6)+W(I)*W(I)*SF(I)/X(I)**4                                     
      DO 970 I=2,NV                                                             
  970 G(I)=G(I)-D1*4.*W(I)*X(I)*SF(I-1)/X(I-1)**4                               
      GO TO 1020                                                                
  980 DO 990 I=1,NM1                                                            
      IF(SF(I).LE.0.) GO TO 985                                                 
      XX1=X(I)*X(I+1)                                                           
      IF(XX1.EQ.0.) GO TO 985                                                   
      W(I)=ALOG(X(I)*X(I))-ALOG(SF(I))-ALOG(X(I+1)*X(I+1))                      
      GO TO 990                                                                 
  985 W(I)=0.                                                                   
  990 CONTINUE                                                                  
      DO 1000 I=1,NM1                                                           
      G(I)=G(I)+D1*4.*W(I)*SWGT(I)/X(I)                                         
 1000 CHI(6)=CHI(6)+W(I)*W(I)*SWGT(I)                                           
      DO 1010 I=2,NV                                                            
 1010 G(I)=G(I)-D1*4.*W(I-1)*SWGT(I-1)/X(I)                                     
 1020 FF=FF+D1*CHI(6)                                                           
C                                                                               
 3000 IF(IALGOR.NE.2) GO TO 1030                                                
C                                                                               
C  LINEAR OBJECTIVE FUNCTION                                                    
C                                                                               
C  EPSILONS                                                                     
C                                                                               
      FF = 0.                                                                   
C     DO 3100 J=1,NV                                                            
C3100 G(J)=0.                                                                   
C     DO 3220 I=1,M                                                             
C     AF(I)=0.                                                                  
C     DO 3200 J=1,NV                                                            
C3200 AF(I)=A(I,J)*X(J)+AF(I)                                                   
C     FTERM(I)=AF(I)-AI(I)                                                      
C     FF = FF+EWGT(I)*FTERM(I)**2                                               
C     DO 3210 J=1,NV                                                            
C3210 G(J) = G(J) +2.*A(I,J)*EWGT(I)*FTERM(I)                                   
C3220 CONTINUE                                                                  
C     CHI(1) = FF                                                               
      DO 3220 I=1,M                                                             
      SUM=0.                                                                    
      DO 3200 J=1,NM1                                                           
 3200 SUM=SUM+X(J)*R(I,J)+(X(J+1)-X(J))                                         
     B*(Q(I,J)-E(J)*R(I,J))/(E(J+1)-E(J))                                       
      AF(I)=SUM                                                                 
      FTERM(I)=SUM-AI(I)                                                        
      FF=FF+EWGT(I)*FTERM(I)*FTERM(I)                                           
      DSUM(I,1)=(R(I,1)*E(2)-Q(I,1))/(E(2)-E(1))                                
      DO 3210 K=2,NM1                                                           
 3210 DSUM(I,K)=((R(I,K)*E(K)-Q(I,K))/(E(K+1)-E(K))+                            
     B(Q(I,K-1)-E(K-1)*R(I,K-1))/(E(K)-E(K-1))+R(I,K))                          
      DSUM(I,NV)=(Q(I,NM1)-E(NM1)*R(I,NM1))                                     
     B           /(E(NV)-E(NM1))                                                
 3220 CONTINUE                                                                  
      CHI(1)=FF                                                                 
      DO 3240 K=1,NV                                                            
      G(K)=0.                                                                   
      DO 3230 I=1,M                                                             
 3230 G(K)=G(K)+2.*FTERM(I)*DSUM(I,K)*EWGT(I)                                   
 3240 CONTINUE                                                                  
C                                                                               
C  DIVERGENCE FROM P,                        Q1                                 
C                                                                               
      IF(WGT(1).EQ.0.) GO TO 3400                                               
      CHI(2)=0.                                                                 
      D1=GAM*WGT(1)                                                             
      DO 3300 J=1,NV                                                            
      CHI(2)=CHI(2) + PWGT(J)*(X(J)-PF(J))**2                                   
 3300 G(J)=G(J)+2.*D1*PWGT(J)*(X(J)-PF(J))                                      
      FF =  FF + D1*CHI(2)                                                      
C                                                                               
C  SQUARE INTEGRAL,                           Q2                                
C                                                                               
 3400 IF(WGT(2).EQ.0.) GO TO 3500                                               
      CHI(3)=0.                                                                 
      D1=GAM*WGT(3)                                                             
      DO 3410 J=1,NV                                                            
      CHI(3)=CHI(3)+FWGT(J)*X(J)**2                                             
 3410 G(I)=G(I)+2.*D1*FWGT(J)*X(J)                                              
      FF = FF +D1*CHI(3)                                                        
C                                                                               
C  FIRST DIFFERENCES,                         Q3                                
C                                                                               
 3500 IF(WGT(3).EQ.0.) GO TO 3600                                               
      CHI(4)=0.                                                                 
      D1=GAM*WGT(3)                                                             
      DO 3510 J=1,NM1                                                           
      CHI(4)=CHI(4)+TWGT(J)*(X(J+1)-X(J))**2                                    
      G(J)=G(J)+2.*D1*TWGT(J)*(X(J)-X(J+1))                                     
 3510 G(J+1)=G(J+1)+2.*D1*TWGT(J)*(X(J+1)-X(J))                                 
      FF=FF+D1*CHI(4)                                                           
C                                                                               
C  SECOND DIFFERENCES,                         Q4                               
C                                                                               
 3600 IF(WGT(4).EQ.0.) GO TO 3700                                               
      CHI(5)=0.                                                                 
      D1=GAM*WGT(4)                                                             
      DO 3620 J=2,NM1                                                           
      CHI(5)=CHI(5)+DWGT(J)*(X(J-1)-2.*X(J)+X(J+1))**2                          
      G(J)=G(J)+4.*D1*DWGT(J)*(2.*X(J)-X(J-1)-X(J+1))                           
      G(J-1)=G(J-1)+2.*D1*DWGT(J)*(X(J-1)-2.*X(J)+X(J+1))                       
 3620 G(J+1)=G(J+1)+2.*D1*DWGT(J)*(X(J-1)-2.*X(J)+X(J+1))                       
      FF = FF + D1*CHI(5)                                                       
C                                                                               
C  SHAPE,                                       Q5                              
 3700 IF(WGT(5).EQ.0.) GO TO 1030                                               
      CHI(6)=0.                                                                 
      D1=GAM*WGT(5)                                                             
      DO 3710 J=1,NM1                                                           
      CHI(5)=CHI(5)+SWGT(J)*(X(J)-SF(J)*X(J+1))**2                              
      G(J)=G(J)+2.*D1*SWGT(J)*(X(J)-SF(J)*X(J+1))                               
 3710 G(J+1)=G(J+1)+2.*D1*SWGT(J)*(SF(J)**2*X(J+1)-SF(J)*X(J))                  
      FF = FF + D1*CHI(6)                                                       
 1030 IF(M2.NE.1) RETURN                                                        
C                                                                               
C  STORE INITIAL VALUES OF SQUARE SUMS Q0 - Q5                                  
C                                                                               
      DO 1040 I=1,6                                                             
 1040 CHIIN(I)=CHI(I)                                                           
      RETURN                                                                    
      END                                                                       
"FOR,IS LOUHI.VARMIT  .                                                         
      SUBROUTINE VARMIT                                                         
      DIMENSION H(100,100),C(1,1),X(100),XP(100),T(100),G(100),GP(100)          
      DIMENSION GB(100),S(100),SCALEX(100),XBEST(100),XERR(100)                 
      COMMON /VARMIT/   F    ,   FP    ,   FB    , SCALEF  ,   FO    ,          
     1       S     ,    X    ,   XP    ,    T    , SCALEX  ,  IFCALL ,          
     2      GS     ,    G    ,   GP    ,   GB    ,   GSP   ,   GSB   ,          
     3       H     ,    C    ,  DELTA  ,   GSS   ,    E    ,  IMOVE  ,          
     4      EL     ,  DOUBLE ,    Z    ,    Q    ,    A    ,  ABAR   ,          
     5       N     ,   IT    ,   ITT   ,   MS    ,    K    , ICNVRG  ,          
     6     IERR    ,  LOOPF  ,   IFIN  ,  ISHOT  ,  IMOVEL ,  IMOVER ,          
     7    IREAD    ,  IWRITE ,  ICLOCK ,  IDENT  ,   ISTEP ,  ISCALE            
      COMMON /IOTAPE/ INTAPE,IOUTAP                                             
      COMMON /BEST/ FBEST,FERR,XBEST,XERR,IBEST,ISAME                           
      COMMON/FEED/ KOUT      , KVAR(15)  , MODE(6)   , NC       ,               
     * NV      , GUES(100)                                                      
      DATA FFIRST,FSECND,FTHIRD/3*1.E37/                                        
C                                                                               
C      OVERFL(IOVER) IS A UNIVAC 1100/ EXEC 8 LIBRARY ROUTINE WHICH CHECKS      
C      FOR FLOATING POINT OVERFLOWS,  IF AN OVERFLOW HAS OCCURED IOVER = 1,     
C      OTHERWISE IOVER = 2                                                      
C    INITIALIZE                                                                 
    1 IT=1                                                                      
      ITT=0                                                                     
      MS=0                                                                      
      DOUBLE=1.0                                                                
      LOOPF=0                                                                   
      IMOVEL=0                                                                  
      IMOVER=0                                                                  
      IOVER = 0                                                                 
      CALL READIN                                                               
C READY                                                                         
      FBEST=SCALEF*F                                                            
 1000 CALL MATMPY(N,N,H,G,S)                                                    
      DO 1010 I=1,N                                                             
      S(I)=-S(I)                                                                
 1010 CONTINUE                                                                  
      L=1                                                                       
      CALL MATMPY (L,N,S,G,GS)                                                  
      IF (GS) 1100,5010,1030                                                    
C    H NOT POSITIVE DEFINITE                                                    
 1030 L=1                                                                       
      CALL ERROR(L)                                                             
      GO TO 1000                                                                
 1100 CONTINUE                                                                  
      EL=AMIN1(2.0,-2.0*F/GS)                                                   
 1020 CONTINUE                                                                  
      DO 1110 I=1,N                                                             
      XP(I)=X(I)+EL*S(I)                                                        
 1110 CONTINUE                                                                  
      M1=2                                                                      
      CALL CALCF (GP,FP,XP,M1)                                                  
C     CALL OVERFL(IOVER)                                                        
      IF (IOVER .NE. 1) GO TO 1200                                              
C    READY OVERFLOW                                                             
      L=2                                                                       
      CALL ERROR(L)                                                             
      GO TO (1100,7000),L                                                       
 1200 IERR=0                                                                    
      L=1                                                                       
      CALL MATMPY (L,N,S,GP,GSP)                                                
      IF ((GSP .GE. 0.0) .OR. (FP .GE. F)) GO TO 2000                           
C    UNDERSHOOT                                                                 
      L=3                                                                       
      CALL ERROR(L)                                                             
      GO TO (1000,1020,4000,5000),L                                             
C AIM                                                                           
 2000 Z=GS+GSP+3.0*(F-FP)/EL                                                    
      ISHOT=0                                                                   
      TO=Z*Z-GS*GSP                                                             
      IF(TO.LT.1.E-37) TO=1.E-37                                                
      IF(TO.GT.1.E+37) TO=1.E+37                                                
 2010 Q=SQRT(TO)                                                                
      A=(GSP+Q-Z)/(GSP-GS+Q+Q)                                                  
      FO=FP-EL*(GSP+Z+Q+Q)*A*A/3.0                                              
C     CALL OVERFL(IOVER)                                                        
      IF (IOVER .NE. 1) GO TO 2100                                              
C    AIM OVERFLOW                                                               
      L=4                                                                       
      CALL ERROR(L)                                                             
 2100 IF ((A .GT. 0.0) .AND. (A .LT. 1.0)) GO TO 2200                           
C    MINIMUM LIES AT AN END POINT                                               
      L=5                                                                       
      CALL ERROR(L)                                                             
      GO TO (1000,5000),L                                                       
 2200 ABAR=1.0-A                                                                
      DO 2210 I=1,N                                                             
      T(I)=A*X(I)+ABAR*XP(I)                                                    
 2210 CONTINUE                                                                  
C FIRE                                                                          
 3000 M1=2                                                                      
      CALL CALCF (GB,FB,T,M1)                                                   
C     CALL OVERFL(IOVER)                                                        
      IF (IOVER .NE. 1) GO TO 3100                                              
C    FIRE OVERFLOW                                                              
      L=6                                                                       
      CALL ERROR(L)                                                             
      GO TO 2200                                                                
 3100 IF (AMIN1(F,FP) .GE. FB) GO TO 3200                                       
C    MOVES                                                                      
      L=7                                                                       
      CALL ERROR(L)                                                             
      GO TO (1200,5000),L                                                       
 3200 LOOPF=0                                                                   
      F=FB                                                                      
      DO 3210 I=1,N                                                             
      X(I)=T(I)                                                                 
      T(I)=G(I)                                                                 
      G(I)=GB(I)                                                                
 3210 CONTINUE                                                                  
      L=1                                                                       
      CALL MATMPY (L,N,S,GB,GSB)                                                
      TP1=A/ABAR                                                                
      TP2=ABAR/A                                                                
      TO=GSB*(TP1-TP2)                                                          
      GSS=TO+Q+Q                                                                
      IF (GSS .GT. 0.0) GO TO 3300                                              
C    2ND DERIVITIVE NEGATIVE                                                    
      L=8                                                                       
      CALL ERROR(L)                                                             
      GO TO 5000                                                                
 3300 DO 3310 I=1,N                                                             
      GB(I)=(GB(I)-T(I))*TP1+(GP(I)-GB(I))*TP2                                  
 3310 CONTINUE                                                                  
C DRESS                                                                         
 4000 CALL MATMPY (N,N,H,GB,T)                                                  
C   CALCULATE LENGTH OF THE 2ND DERIVATIVE IN THE DIRECTION OF THE STEP         
      L=1                                                                       
      CALL MATMPY (L,N,GB,T,TO)                                                 
      DO 4020 I=1,N                                                             
      DO 4010 J=1,N                                                             
      H(I,J)=H(I,J)-T(I)*T(J)/TO+EL*S(I)*S(J)/GSS                               
 4010 CONTINUE                                                                  
 4020 CONTINUE                                                                  
      DELTA=DELTA*(EL*GSS/TO)                                                   
 4200 CONTINUE                                                                  
C     CALL OVERFL(IOVER)                                                        
      IF (IOVER .NE. 1) GO TO 5000                                              
C  DRESS OVERFLOW   START A NEW CASE                                            
      L=9                                                                       
      CALL ERROR(L)                                                             
      L=2                                                                       
      IFIN=1                                                                    
C  CONVERGENCE CRITERION                                                        
 5000 CONTINUE                                                                  
      IF ( F .NE. FTHIRD) GO TO 5050                                            
 5010 L=2                                                                       
      GO TO 5600                                                                
 5050 FTHIRD=FSECND                                                             
      FSECND=FFIRST                                                             
      FFIRST=F                                                                  
      IF (ICNVRG .GE. 4) GO TO 5070                                             
      IF (IFIN .EQ. 1) GO TO 5010                                               
 5070 M=MOD(ICNVRG,4)+1                                                         
      GO TO (5100,5200,5300,5100                           ),M                  
 5100 DO 5110 I=1,N                                                             
      IF (ABS(S(I)) .GE. E) GO TO 5500                                          
 5110 CONTINUE                                                                  
      IF (M .EQ. 1) GO TO 5010                                                  
 5200 IF (ABS(GS) .LT. E) GO TO 5010                                            
      GO TO 5500                                                                
 5300 IF (ABS(FFIRST-FSECND) .LT. E) GO TO 5010                                 
 5500 L=1                                                                       
 5600 IFIN=0                                                                    
      CALL RITEOT(L)                                                            
      IT=IT+1                                                                   
      IF (L .EQ. 1) GO TO 1000                                                  
C MINIMUM SURVAY                                                                
      IF((MS.LE.0).OR.(ABS(SCALEF*F-FBEST)/SCALEF.GT..1))GO TO 6050             
      ISAME=1                                                                   
      DO 6010 I=1,N                                                             
      XERR(I)=AMAX1(XERR(I),ABS(XBEST(I)-X(I)*SCALEX(I)))                       
 6010 CONTINUE                                                                  
      FERR=AMAX1(FERR,ABS(FBEST-SCALEF*F))                                      
      GO TO 6100                                                                
 6050 DO 6060 I=1,N                                                             
      XERR(I)=0.0                                                               
 6060 CONTINUE                                                                  
      FERR=0.0                                                                  
      ISAME=0                                                                   
 6100 IF (SCALEF*F .GE. FBEST) GO TO 7000                                       
      FBEST=SCALEF*F                                                            
      IBEST=MS                                                                  
      DO 6110 I=1,N                                                             
      XBEST(I)=X(I)*SCALEX(I)                                                   
 6110 CONTINUE                                                                  
C STUFF                                                                         
 7000 IF (MS .LT. K) GO TO 7100                                                 
      L=3                                                                       
      GO TO 8000                                                                
 7100 MS=MS+1                                                                   
      IF(KOUT.NE.0) WRITE (IOUTAP,7110) MS                                      
 7110 FORMAT (19H-RANDOM STEP NUMBER,I4)                                        
      MM=(MS+1)/2                                                               
      DO 7120 I=1,N                                                             
      M=MOD(I,MM)+MOD(MS,2)                                                     
      T(I)=2*MOD(M,2)-1                                                         
 7120 CONTINUE                                                                  
      CALL MATMPY (N,N,H,T,S)                                                   
      L=1                                                                       
      CALL MATMPY (L,N,S,T,TO)                                                  
      EL=(10.0**(ISTEP-1))/SQRT(TO)                                             
 7130 DO 7140 I=1,N                                                             
      X(I)=X(I)+EL*S(I)                                                         
 7140 CONTINUE                                                                  
      M1=2                                                                      
      CALL CALCF (G,F,X,M1)                                                     
      IT=0                                                                      
      L=1                                                                       
 8000 CONTINUE                                                                  
      CALL RITEOT(L)                                                            
      IT=1                                                                      
      IF(L.EQ.1)GO TO 1000                                                      
      RETURN                                                                    
      END                                                                       
"FOR,I LOUHI.READIN  .                                                          
      SUBROUTINE READIN                                                         
      DIMENSION H(100,100),C(1,1),X(100),XP(100),T(100),G(100),GP(100)          
      DIMENSION GB(100),S(100),SCALEX(100)                                      
      COMMON /VARMIT/   F    ,   FP    ,   FB    , SCALEF  ,   FO    ,          
     1       S     ,    X    ,   XP    ,    T    , SCALEX  ,  IFCALL ,          
     2      GS     ,    G    ,   GP    ,   GB    ,   GSP   ,   GSB   ,          
     3       H     ,    C    ,  DELTA  ,   GSS   ,    E    ,  IMOVE  ,          
     4      EL     ,  DOUBLE ,    Z    ,    Q    ,    A    ,  ABAR   ,          
     5       N     ,   IT    ,   ITT   ,   MS    ,    K    , ICNVRG  ,          
     6     IERR    ,  LOOPF  ,   IFIN  ,  ISHOT  ,  IMOVEL ,  IMOVER ,          
     7    IREAD    ,  IWRITE ,  ICLOCK ,  IDENT  ,   ISTEP ,  ISCALE            
      COMMON /IOTAPE/ INTAPE,IOUTAP                                             
      COMMON/FEED/ KOUT      , KVAR(15)  , MODE(6)   , NC        ,              
     1 NV        , GUES(100)                                                    
      IF (ICON .EQ. 1) GO TO 2                                                  
      IREAD  =KVAR(1)                                                   3/14/67 
      IWRITE=KVAR(2)                                                            
      K      =KVAR(3)                                                   3/14/67 
      ISIZE  =KVAR(4)                                                   3/14/67 
      ISTEP  =KVAR(5)                                                   3/14/67 
      ICK    =KVAR(6)                                                   3/14/67 
      IMOVE  =KVAR(7)                                                   3/14/67 
      ICLOCK =KVAR(8)                                                   3/14/67 
      ICON   =KVAR(9)                                                   3/14/67 
      ICNVRG =KVAR(10)                                                  3/14/67 
      IDENT  =KVAR(11)                                                  3/14/67 
      ISCALE =KVAR(12 )                                                 3/14/67 
    1 FORMAT (16I5)                                                             
      E=10.**(ISIZE-8)                                                          
      K=K+1                                                                     
    2 M1=1                                                                      
      CALL FCN (N,G,F,X,M1)                                                     
      IFCALL=1                                                                  
      DO 1025 I=1,N                                                     3/14/67 
 1025 X(I)=GUES(I)                                                      3/14/67 
   10 FORMAT (8E10.0)                                                           
      IF(KOUT.NE.0) WRITE (IOUTAP,20)                                           
   20 FORMAT (//,17H INITIAL GUESS IS)                                  3/24/67 
      IF(KOUT.NE.0) WRITE (IOUTAP,37) (X(I),I=1,N)                              
      IF (IREAD .GE. 0) GO TO 50                                                
      DO 30 I=1,N                                                               
      DO 29 J=1,N                                                               
C     C(I,J)=0.0                                                                
      H(I,J)=0.0                                                                
   29 CONTINUE                                                                  
      H(I,I)=1.0                                                                
   30 CONTINUE                                                                  
      DELTA=1.0                                                                 
   32 FORMAT (34H WHICH IS  LINEARLY CONSTRAINED BY)                            
      IF(KOUT.NE.0) WRITE (IOUTAP,32)                                           
      NUMCON=-IREAD                                                             
      DO 40 I=1,NUMCON                                                          
C     READ(INTAPE,10) (C(I,J),J=1,N)                                            
C     IF(KOUT.NE.0) WRITE (IOUTAP,37) (C(I,J),J=1,N)                            
   37 FORMAT (10E13.5)                                                          
   40 CONTINUE                                                                  
      GO TO 150                                                                 
   50 IREADM=IREAD+1                                                            
      GO TO  (100,200,300,200            ),IREADM                               
C   H STARTED AS IDENTITY                                                       
  100 DO 110 I=1,N                                                              
      DO 108 J=1,N                                                              
      H(I,J)=0.0                                                                
  108 CONTINUE                                                                  
      H(I,I)=1.0                                                                
  110 CONTINUE                                                                  
      DELTA=1.0                                                                 
      IF(KOUT.NE.0) WRITE (IOUTAP,120)                                          
  120 FORMAT (39H0H SET INITIALLY TO THE IDENTITY MATRIX)                       
  150 M1=2                                                                      
      CALL FCN (N,G,F,X,M1)                                                     
      IF(KOUT.NE.0) WRITE (IOUTAP,160) F                                        
  160 FORMAT (24H0AT THE INITIAL GUESS F=,E13.5/9H AND G IS)                    
      IF(KOUT.NE.0) WRITE (IOUTAP,37) (G(I),I=1,N)                              
      IF(ICK.EQ.1) CALL DIFCK                                                   
      IF(KOUT.NE.0) WRITE (IOUTAP,170)                                          
  170 FORMAT (1H0)                                                              
      M1=1                                                                      
      CALL CALCF (G,F,X,M1)                                                     
      IF ((IREAD .EQ. 0) .OR. (IREAD .EQ. 1)) GO TO 195                         
      DO 190 I=1,N                                                              
      GSS=SCALEF/SCALEX(I)                                                      
      DO 180 J=1,N                                                              
      H(I,J)=H(I,J)*GSS/SCALEX(J)                                               
  180 CONTINUE                                                                  
  190 CONTINUE                                                                  
      IF (IREAD .LT. 0) CALL CSTRAN(0)                                          
  195 RETURN                                                                    
C   READ IN DIAGONAL ELEMENTS OF H                                              
  200 DO 210 I=1,N                                                              
      DO 209 J=1,N                                                              
      H(I,J)=0.0                                                                
  209 CONTINUE                                                                  
  210 CONTINUE                                                                  
      READ (INTAPE,10) (H(I,I),I=1,N)                                           
      DELTA=1.0                                                                 
      DO 230 I=1,N                                                              
      IF (H(I,I) .NE. 0.0) DELTA=DELTA*H(I,I)                                   
  230 CONTINUE                                                                  
      IF(KOUT.NE.0) WRITE (IOUTAP,240)                                          
  240 FORMAT (31H0THE DIAGONAL ELEMENTS OF H ARE)                               
      IF(KOUT.NE.0) WRITE (IOUTAP,37) (H(I,I),I=1,N)                            
      IF(KOUT.NE.0) WRITE (IOUTAP,250) DELTA                                    
  250 FORMAT (24H0THE DETERMINANT OF H IS,E13.5)                                
      GO TO 150                                                                 
  300 READ (INTAPE,10) ((H(I,J),J=1,N),I=1,N) ,DELTA                            
C   READ IN H AND DELTA                                                         
      IF(KOUT.NE.0) WRITE (IOUTAP,310) ((H(I,J),J=1,N),I=1,N)                   
  310 FORMAT (1H0,20X,1HH/(10E13.5))                                            
      IF(KOUT.NE.0) WRITE (IOUTAP,250) DELTA                                    
      GO TO 150                                                                 
      END                                                                       
"FOR,IS LOUHI.RITEOT  .                                                         
      SUBROUTINE RITEOT(L)                                                      
      COMMON/HDIAG/HDIAGO(100)                                                  
      COMMON/FEED/ KOUT      , KVAR(15)  , MODE(6)   , NC        ,              
     1 NV        , GUES(100)                                                    
      DIMENSION H(100,100),C(1,1),X(100),XP(100),T(100),G(100),GP(100)          
      DIMENSION GB(100),S(100),SCALEX(100),XBEST(100),XERR(100)                 
      COMMON /VARMIT/   F    ,   FP    ,   FB    , SCALEF  ,   FO    ,          
     1       S     ,    X    ,   XP    ,    T    , SCALEX  ,  IFCALL ,          
     2      GS     ,    G    ,   GP    ,   GB    ,   GSP   ,   GSB   ,          
     3       H     ,    C    ,  DELTA  ,   GSS   ,    E    ,  IMOVE  ,          
     4      EL     ,  DOUBLE ,    Z    ,    Q    ,    A    ,  ABAR   ,          
     5       N     ,   IT    ,   ITT   ,   MS    ,    K    , ICNVRG  ,          
     6     IERR    ,  LOOPF  ,   IFIN  ,  ISHOT  ,  IMOVEL ,  IMOVER ,          
     7    IREAD    ,  IWRITE ,  ICLOCK ,  IDENT  ,   ISTEP ,  ISCALE            
      COMMON /IOTAPE/ INTAPE,IOUTAP                                             
      COMMON /BEST/ FBEST,FERR,XBEST,XERR,IBEST,ISAME                           
      IF (L .EQ. 3) GO TO 3000                                                  
      IF (ICLOCK .LE. 1) GO TO 100                                              
      ITT=ITT+1                                                                 
      IF (ITT .LE. ICLOCK) GO TO 1000                                           
      WRITE(IOUTAP,10) ITT                                                      
   10 FORMAT (25H1/-/-/-/-/-/-/-/-/-/-/-/-/39H-COMPLETED MAXIMUM NUMBER         
     *OF ITERATIONS             ,I6)                                            
      K=MS                                                                      
      L=2                                                                       
      RETURN                                                                    
  100 CONTINUE                                                                  
      IF (((IT .NE. 11) .AND. (IT .NE. 1) .AND. (L .NE. 2) .AND. (ISETUP        
     * .NE. 1)) .OR. (ICLOCK .NE. 0)) GO TO 1000                                
      IF (ISETUP .EQ. 1) GO TO 300                                              
      IF (IT .NE. 1) GO TO 200                                                  
      CONTINUE                                                                  
      GO TO 1000                                                                
  200 CONTINUE                                                                  
      ISETUP=1                                                                  
  300 CONTINUE                                                                  
      MS=K                                                                      
      L=2                                                                       
      RETURN                                                                    
 1000 CONTINUE                                                                  
      IF (L .EQ. 2) GO TO 2000                                                  
      IF (IWRITE .EQ. 0) GO TO 1600                                             
      IF(KOUT.EQ.0) GO TO 1005                                                  
      IF (IWRITE .NE. 1) WRITE (IOUTAP,1010)                                    
 1005 CONTINUE                                                                  
 1010 FORMAT (130H - - - - - - - - - - - - - - - - - - - - - - - - - - -        
     * - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -        
     * - - - - -           )                                                    
 1020 GO TO (1600,1500,1400,1300,1200,1100),IWRITE                              
 1100 CONTINUE                                                                  
      FO=FO*SCALEF                                                              
      IF(KOUT.NE.0) WRITE (IOUTAP,1110) EL,A,Q,FO,Z                             
 1110 FORMAT (4H0EL=,E13.5,3H A=,E13.5,3H Q=,E13.5,4H FO=,E13.5,3H Z=,          
     *E13.5)                                                                    
 1200 IF(KOUT.NE.0.AND.IWRITE.GE.2) WRITE (IOUTAP,1205)                         
 1205 FORMAT (1H0,20X,1HH)                                                      
      TO=1.0                                                                    
      DO 1220 I=1,N                                                             
      GSS=SCALEX(I)/SCALEF                                                      
      TO=TO*SCALEX(I)                                                           
      DO 1210 J=1,N                                                             
      T(J)=GSS*SCALEX(J)*H(I,J)                                                 
 1210 CONTINUE                                                                  
      IF(KOUT.NE.0.AND.IWRITE.GE.2)WRITE (IOUTAP,1215) (T(J),J=1,N)             
 1215 FORMAT (10E13.5)                                                          
 1220 CONTINUE                                                                  
      IF(TO.LT.1.E-36) TO=1.E-36                                                
      IF(TO.GT.1.E+36) TO=1.E+36                                                
      IF(DELTA.LT.1.E-36) DELTA=1.E-36                                          
      IF(DELTA.GT.1.E+36) DELTA=1.E+36                                          
  777 FORMAT()                                                                  
      GLOG=ALOG10(ABS(DELTA))+2.*ALOG10(ABS(TO))                                
     1      -FLOAT(N)*ALOG10(ABS(SCALEF))                                       
      IF(GLOG.GT.-36.) GO TO 1222                                               
      GSS = 1.E-36                                                              
      GO TO 1226                                                                
 1222 IF(GLOG.GT.36.) GO  TO 1224                                               
      GSS=10.**GLOG                                                             
      GO TO 1226                                                                
 1224 GSS=1.E+36                                                                
 1226 CONTINUE                                                                  
      IF(KOUT.NE.0) WRITE (IOUTAP,1230) GSS                                     
 1230 FORMAT (7H0DELTA=,E13.5)                                                  
      IF(KOUT.EQ.0) GO TO 1305                                                  
 1300 IF (ISHOT .NE. 0) WRITE (IOUTAP,1310)                                     
 1305 CONTINUE                                                                  
 1310 FORMAT (10H0UNDERSHOT)                                                    
      ISHOT=0                                                                   
      IF(KOUT.NE.0) WRITE (IOUTAP,1320) GS                                      
 1320 FORMAT (59H0THE COMPONENT OF THE GRADIENT IN THE DIRECTION OF THE         
     1STEP,E13.5)                                                               
      IF(KOUT.NE.0) WRITE (IOUTAP,1330) IFCALL                                  
 1330 FORMAT (1H0,I6,15H FUNCTION CALLS)                                        
      IF(KOUT.EQ.0) GO TO 1335                                                  
      IF (IMOVEL .NE. 0) WRITE(IOUTAP,1340) IMOVEL                              
 1335 CONTINUE                                                                  
 1340 FORMAT (11H0MOVED LEFT,I6,6H TIMES)                                       
      IMOVEL=0                                                                  
      IF(KOUT.EQ.0) GO TO 1345                                                  
      IF (IMOVER .NE. 0) WRITE (IOUTAP,1350) IMOVER                             
 1345 CONTINUE                                                                  
 1350 FORMAT (12H0MOVED RIGHT,I6,6H TIMES)                                      
      IMOVER=0                                                                  
 1400 IF(KOUT.NE.0) WRITE (IOUTAP,1410)                                         
 1410 FORMAT (1H0,20X,1HG)                                                      
      DO 1420 I=1,N                                                             
      T(I)=SCALEF*G(I)/SCALEX(I)                                                
 1420 CONTINUE                                                                  
      IF(KOUT.NE.0) WRITE (IOUTAP,1215) (T(I),I=1,N)                            
 1500 FP=SCALEF*F                                                               
      IF(KOUT.NE.0) WRITE (IOUTAP,1510) FP                                      
 1510 FORMAT (3H0F=,E13.5/1H0,20X,1HX)                                          
      DO 1520 I=1,N                                                             
      T(I)=SCALEX(I)*X(I)                                                       
 1520 CONTINUE                                                                  
      IF(KOUT.NE.0) WRITE (IOUTAP,1215) (T(I),I=1,N)                            
      IF(KOUT.NE.0) WRITE (IOUTAP,1530) IT,MS                                   
 1530 FORMAT (17H0ITERATION NUMBER,I4,16H OF STEP NUMBER,I4/130H0- - - -        
     * - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -        
     * - - - - - - - - - - - - - - - - - - - - - - - - - - - -    )             
 1600 IF (-1 .NE. JEND) RETURN                                                  
 2000 M1=3                                                                      
      CALL CALCF (G,F,X,M1)                                                     
      IF(KOUT.NE.0) WRITE (IOUTAP,2010) MS                                      
 2010 FORMAT(/,25H /-/-/-/-/-/-/-/-/-/-/-/-/21H-FINAL VALUES OF STEP,I4)3/24/67 
      GO TO 1200                                                                
 3000 IF(KOUT.NE.0) WRITE (IOUTAP,3010)                                         
 3010 FORMAT(/,25H /-/-/-/-/-/-/-/-/-/-/-/-/24H0SUMMARY OF FINAL VALUES)3/24/67 
      IF(KOUT.NE.0) WRITE (IOUTAP,3020) IBEST                                   
 3020 FORMAT (36H0THE BEST VALUE OF F OCCURED ON STEP,I4)                       
      IF ((ISAME .EQ. 0) .AND. (MS .NE. IBEST)) GO TO 3100                      
      IF(KOUT.NE.0.AND.IWRITE.GE.2) WRITE (IOUTAP,3030)                         
 3030 FORMAT (36H0AN H MATRIX FOR THE BEST MINIMUM IS)                          
      DO 3050 I=1,N                                                             
      GSS=SCALEX(I)/SCALEF                                                      
      DO 3040 J=1,N                                                             
      T(J)=H(I,J)*GSS*SCALEX(J)                                                 
 3040 CONTINUE                                                                  
      IF(KOUT.NE.0.AND.IWRITE.GE.2)WRITE (IOUTAP,1215) (T(J),J=1,N)             
      HDIAGO(I)=T(I)                                                            
 3050 CONTINUE                                                                  
 3100 M1=4                                                                      
      CALL FCN (N,G,FBEST,XBEST,M1)                                             
      IF (ISAME .EQ. 0) GO TO 3200                                              
      IF(KOUT.NE.0) WRITE (IOUTAP,3110) FBEST,FERR                              
 3110 FORMAT (7H0FBEST=,E13.5,4H+OR-,E13.5//)                                   
      DO 3130 I=1,N                                                             
      IF(KOUT.NE.0) WRITE (IOUTAP,3120) I,XBEST(I),XERR(I)                      
 3120 FORMAT (7H XBEST(,I2,2H)=,E13.5,4H+OR-,E13.5)                             
 3130 CONTINUE                                                                  
      GO TO 3300                                                                
 3200 IF(KOUT.NE.0) WRITE (IOUTAP,3210) FBEST,(XBEST(I),I=1,N)                  
 3210 FORMAT (7H0FBEST=,E13.5,13H AND XBEST IS/(10E13.5))                       
 3300 IF(KOUT.NE.0) WRITE (IOUTAP,3310)                                         
 3310 FORMAT (1H0,20X,2HG=)                                                     
      IF(KOUT.NE.0) WRITE (IOUTAP,1215) (G(I),I=1,N)                            
      RETURN                                                                    
      END                                                                       
"FOR,IS LOUHI.ERROR  .                                                          
      SUBROUTINE ERROR(L)                                                       
      DIMENSION H(100,100),C(1,1),X(100),XP(100),T(100),G(100),GP(100)          
      DIMENSION GB(100),S(100),SCALEX(100)                                      
      COMMON /VARMIT/   F    ,   FP    ,   FB    , SCALEF  ,   FO    ,          
     1       S     ,    X    ,   XP    ,    T    , SCALEX  ,  IFCALL ,          
     2      GS     ,    G    ,   GP    ,   GB    ,   GSP   ,   GSB   ,          
     3       H     ,    C    ,  DELTA  ,   GSS   ,    E    ,  IMOVE  ,          
     4      EL     ,  DOUBLE ,    Z    ,    Q    ,    A    ,  ABAR   ,          
     5       N     ,   IT    ,   ITT   ,   MS    ,    K    , ICNVRG  ,          
     6     IERR    ,  LOOPF  ,   IFIN  ,  ISHOT  ,  IMOVEL ,  IMOVER ,          
     7    IREAD    ,  IWRITE ,  ICLOCK ,  IDENT  ,   ISTEP ,  ISCALE            
      COMMON /IOTAPE/ INTAPE,IOUTAP                                             
      COMMON /FEED/KOUT      ,KVAR(15)  , MODE(6)   , NC      ,                 
     * NV        , GUES(100)                                                    
      GO TO (100,200,300,400,500,600,700,800,900,1000      ),L                  
  100 IF (IWRITE .NE. 0.AND.KOUT.NE.0) WRITE (IOUTAP,110) GS                    
  110 FORMAT(41H H IS NO LONGER POSITIVE DEFINITE FOR GS=,E13.5,70H SO D        
     *IAGONAL ELTS. OF H ARE SET POSITIVE AND OFF DIAGONAL ELTS. ZEROED)        
      DELTA=1.0                                                                 
      DO 130 I=1,N                                                              
      H(I,I)=ABS(H(I,I))                                                        
      DO 120 J=1,N                                                              
      IF (I .NE. J) H(I,J)=0.0                                                  
  120 CONTINUE                                                                  
      IF (H(I,I) .NE. 0.0) DELTA=DELTA*H(I,I)                                   
  130 CONTINUE                                                                  
      L=1                                                                       
      IF (IREAD .LT. 0) CALL CSTRAN(L)                                          
      RETURN                                                                    
  200 IF (IWRITE .NE. 0.AND.KOUT.NE.0) WRITE (IOUTAP,201)                       
  201 FORMAT (58H READY OVERFLOW   LENGTH OF STEP IS HALVED FOR ANOTHER         
     *TRY)                                                                      
      IF (((MS .NE. 0) .AND. (IT .EQ. 1)) .OR. (IERR .GE. 5)) GO TO 210         
      IERR=IERR+1                                                               
      L=1                                                                       
      RETURN                                                                    
  210 CONTINUE                                                                  
      IF(KOUT.NE.0) WRITE (IOUTAP,215)                                          
  215 FORMAT (41H0TOO MANY READY OVERFLOWS CASE TERMINATED)                     
      MS=K                                                                      
      L=2                                                                       
      RETURN                                                                    
  300 F=FP                                                                      
      DO 310 I=1,N                                                              
      G(I)=GP(I)                                                                
      X(I)=XP(I)                                                                
  310 CONTINUE                                                                  
      IF (MS .EQ. 0) GO TO 320                                                  
      EL=2.*EL                                                                  
      L=2                                                                       
      RETURN                                                                    
  320 IF (EL .GE. 1.0) GO TO 350                                                
      L=1                                                                       
      RETURN                                                                    
  350 DELTA=(DOUBLE+1.0)*DELTA                                                  
      DO 370 I=1,N                                                              
      DO 360 J=1,N                                                              
      H(I,J)=H(I,J)-DOUBLE*S(I)*S(J)/GS                                         
  360 CONTINUE                                                                  
  370 CONTINUE                                                                  
      DOUBLE=DOUBLE+1.0                                                         
      ISHOT=2                                                                   
      L=4                                                                       
      RETURN                                                                    
  400 IF (IWRITE .NE. 0 .AND. KOUT.NE.0 ) WRITE (IOUTAP,401)                    
  401 FORMAT (13H AIM OVERFLOW)                                                 
      RETURN                                                                    
  500 IF (A .LE. 0.0) GO TO 550                                                 
      IF (IWRITE .NE.0 .AND. KOUT.NE.0) WRITE (IOUTAP,510)                      
  510 FORMAT (64H MINIMUM IN READY INTERVAL APPEARS TO LIE AT THE LEFT          
     *END POINT)                                                                
      IF (IDENT .LE. 0) GO TO 580                                               
      DELTA=1.0                                                                 
      DO 530 I=1,N                                                              
      H(I,I)=ABS(H(I,I))                                                        
      DO 520 J=1,N                                                              
      IF (I .NE. J) H(I,J)=0.0                                                  
  520 CONTINUE                                                                  
      IF (H(I,I) .NE. 0.0) DELTA=DELTA*H(I,I)                                   
  530 CONTINUE                                                                  
      IF (IWRITE.NE.0.AND.KOUT.NE.0) WRITE (IOUTAP,535)                         
  535 FORMAT (67H0DIAGONAL ELTS. OF H ARE SET POSITIVE AND OFF DIAGONAL         
     *ELTS. ZEROED)                                                             
      L=1                                                                       
      IF (IREAD .LT. 0) CALL CSTRAN(L)                                          
      L=1                                                                       
      RETURN                                                                    
  550 IF (IWRITE.NE.0.AND.KOUT.NE.0) WRITE (IOUTAP,560)                         
  560 FORMAT (64H MINIMUM IN READY INTERVAL APPEARS TO LIE AT THE RIGHT         
     *END POINT)                                                                
      F=FP                                                                      
      DO 570 I=1,N                                                              
      G(I)=GP(I)                                                                
      X(I)=XP(I)                                                                
  570 CONTINUE                                                                  
  580 IF (IDENT .LE. 1) IFIN=1                                                  
      L=2                                                                       
      RETURN                                                                    
  600 IF (IWRITE.NE.0.AND.KOUT.NE.0) WRITE (IOUTAP,601)                         
  601 FORMAT (83H0FIRE OVERFLOW   TRY POINT HALFWAY BETWEEN INTERPOLATED        
     * MINIMUM AND LOWER END POINT)                                             
      IF (FP .GT. F) A=A-1.0                                                    
      A=(1.0+A)/2.0                                                             
      RETURN                                                                    
  700 CONTINUE                                                                  
      M=IMOVE+3                                                                 
      IF (LOOPF .LT. M) GO TO 710                                               
      IF(KOUT.NE.0) WRITE (IOUTAP,705) M                                        
  705 FORMAT (24H TRIED TO MOVE MORE THAN,I2,6H TIMES)                          
      IFIN=1                                                                    
      LOOPF=0                                                                   
      L=2                                                                       
      RETURN                                                                    
  710 LOOPF=LOOPF+1                                                             
      IF (F .GE. FP) GO TO 750                                                  
      IMOVEL=IMOVEL+1                                                           
      EL=ABAR*EL                                                                
      FP=FB                                                                     
      DO 720 I=1,N                                                              
      XP(I)=T(I)                                                                
      GP(I)=GB(I)                                                               
  720 CONTINUE                                                                  
C   GOES TO AIM                                                                 
      L=1                                                                       
      RETURN                                                                    
  750 IMOVER=IMOVER+1                                                           
      EL=EL*A                                                                   
      F=FB                                                                      
      LL=1                                                                      
      CALL MATMPY(LL,N,S,GB,GS)                                                 
      DO 760 I=1,N                                                              
      X(I)=T(I)                                                                 
      G(I)=GB(I)                                                                
  760 CONTINUE                                                                  
      L=1                                                                       
      RETURN                                                                    
  800 IF (IWRITE.NE.0.AND.KOUT.NE.0) WRITE (IOUTAP,810)                         
  810 FORMAT (57H APPROXIMATE 2ND DERIVATIVE NEGATIVE DONT MODIFY H MATR        
     *IX)                                                                       
      RETURN                                                                    
  900 IF (IWRITE.NE.0.AND.KOUT.NE.0) WRITE (IOUTAP,901)                         
  901 FORMAT (15H0DRESS OVERFLOW)                                               
 1000 RETURN                                                                    
      END                                                                       
"FOR,IS LOUHI.MATMPY  .                                                         
      SUBROUTINE MATMPY(M,N,H,G,S)                                              
      DIMENSION H(100,100),G(100),S(100)                                        
      COMMON /IOTAPE/ INTAPE,IOUTAP                                             
      IF (M-1) 705,705,702                                                      
 702  DO 703 I=1,M                                                              
      S(I)=0.0                                                                  
      DO 703 J=1,N                                                              
  703 S(I)=H(I,J)*G(J)+S(I)                                                     
      RETURN                                                                    
 705  S(1)=0.0                                                                  
      DO 706 I=1,N                                                              
 706  S(1)=H(I,1)*G(I)+S(1)                                                     
      RETURN                                                                    
      END                                                                       
"FOR,IS LOUHI.CALCF  .                                                          
      SUBROUTINE CALCF (GG,FF,XX,M1)                                            
      DIMENSION H(100,100),C(1,1),X(100),XP(100),T(100),G(100),GP(100)          
      DIMENSION GB(100),S(100),SCALEX(100),YY(100),XX(100),GG(100)              
      COMMON /VARMIT/   F    ,   FP    ,   FB    , SCALEF  ,   FO    ,          
     1       S     ,    X    ,   XP    ,    T    , SCALEX  ,  IFCALL ,          
     2      GS     ,    G    ,   GP    ,   GB    ,   GSP   ,   GSB   ,          
     3       H     ,    C    ,  DELTA  ,   GSS   ,    E    ,  IMOVE  ,          
     4      EL     ,  DOUBLE ,    Z    ,    Q    ,    A    ,  ABAR   ,          
     5       N     ,   IT    ,   ITT   ,   MS    ,    K    , ICNVRG  ,          
     6     IERR    ,  LOOPF  ,   IFIN  ,  ISHOT  ,  IMOVEL ,  IMOVER ,          
     7    IREAD    ,  IWRITE ,  ICLOCK ,  IDENT  ,   ISTEP ,  ISCALE            
      COMMON /IOTAPE/ INTAPE,IOUTAP                                             
      IFCALL=IFCALL+1                                                           
      IF (ISCALE .NE. 0) GO TO 400                                              
      GO TO (100,200,300),M1                                                    
  100 SCALEF=1.0                                                                
      IF (FF .LE. 0.0) GO TO 105                                                
      SCALEF=FF                                                                 
      FF=1.0                                                                    
  105 DO 110 I=1,N                                                              
      SCALEX(I)=1.0                                                             
      IF (XX(I) .EQ. 0.0) GO TO 110                                             
      SCALEX(I)=XX(I)                                                           
      XX(I)=1.0                                                                 
      GG(I)=SCALEX(I)*GG(I)/SCALEF                                              
  110 CONTINUE                                                                  
      RETURN                                                                    
  200 DO 210 I=1,N                                                              
      YY(I)=SCALEX(I)*XX(I)                                                     
  210 CONTINUE                                                                  
      CALL FCN (N,GG,FF,YY,M1)                                                  
      FF=FF/SCALEF                                                              
      DO 220 I=1,N                                                              
      GG(I)=SCALEX(I)*GG(I)/SCALEF                                              
  220 CONTINUE                                                                  
      RETURN                                                                    
  300 TO=1.0                                                                    
      DO 320 I=1,N                                                              
      GSS=SCALEX(I)/SCALEF                                                      
      TO=TO*SCALEX(I)                                                           
      DO 310 J=1,N                                                              
      H(I,J)=H(I,J)*GSS*SCALEX(J)                                               
  310 CONTINUE                                                                  
      XX(I)=SCALEX(I)*XX(I)                                                     
  320 CONTINUE                                                                  
      IF(TO.LT.1.E-37) GO TO 325                                                
      IF(DELTA.LT.1.E-37) GO TO 325                                             
      IF(SCALEF.GT.1.E+37) GO TO 325                                            
      DLOG = ALOG10(ABS(DELTA))+2.*ALOG10(ABS(TO))                              
     1     -FLOAT(N)*ALOG10(ABS(SCALEF))                                        
      IF(DLOG.GT.-36.) GO TO 322                                                
      DELTA = 1.E-36                                                            
      GO TO 326                                                                 
  322 IF(DLOG.GT.36.) GO TO 324                                                 
      DELTA = 10.**DLOG                                                         
      GO TO 326                                                                 
  324 DELTA = 1.E+36                                                            
      GO TO 326                                                                 
  325 DELTA = 0.                                                                
  326 CONTINUE                                                                  
      CALL FCN (N,GG,FF,XX,M1)                                                  
      SCALEF=1.0                                                                
      IF (FF .EQ. 0.0) GO TO 330                                                
      SCALEF=FF                                                                 
      FF=1.0                                                                    
  330 DO 340 I=1,N                                                              
      SCALEX(I)=1.0                                                             
      IF (XX(I) .EQ. 0.0) GO TO 340                                             
      SCALEX(I)=XX(I)                                                           
      XX(I)=1.0                                                                 
      GG(I)=SCALEX(I)*GG(I)/SCALEF                                              
  340 CONTINUE                                                                  
      TO=1.0                                                                    
      DO 360 I=1,N                                                              
      GSS=SCALEF/SCALEX(I)                                                      
      TO=TO/SCALEX(I)                                                           
      DO 350 J=1,N                                                              
      H(I,J)=H(I,J)*GSS/SCALEX(J)                                               
  350 CONTINUE                                                                  
  360 CONTINUE                                                                  
      IF(TO.LT.1.E-37) GO TO 365                                                
      IF(DELTA.LT.1.E-37) GO TO 365                                             
      IF(SCALEF.LT.1.E-37) GO TO 365                                            
      IF(TO.GT.1.E+37) GO TO 367                                                
      IF(DELTA.GT.1.E+37) GO TO 367                                             
      IF(SCALEF.GT.1.E+37) GO TO 367                                            
      DLOG = ALOG10(ABS(DELTA))+2.*ALOG10(ABS(TO))                              
     1     +FLOAT(N)*ALOG10(ABS(SCALEF))                                        
      IF(DLOG.GT.-36.) GO TO 362                                                
      DELTA = 1.E-36                                                            
      GO TO 366                                                                 
  362 IF(DLOG.GT.36.) GO TO 364                                                 
      DELTA = 10.**DLOG                                                         
      GO TO 366                                                                 
  364 DELTA = 1.E+36                                                            
      GO TO 366                                                                 
  367 DELTA=1.E+37                                                              
      GO TO 366                                                                 
  365 DELTA=0.                                                                  
  366 CONTINUE                                                                  
      RETURN                                                                    
  400 IF (M1 .EQ. 1) GO TO 410                                                  
      CALL FCN (N,GG,FF,XX,M1)                                                  
      RETURN                                                                    
  410 SCALEF=1.                                                                 
      DO 420 I=1,N                                                              
      SCALEX(I)=1.                                                              
  420 CONTINUE                                                                  
      RETURN                                                                    
      END                                                                       
"FOR,IS LOUHI.DIFCK  .                                                          
      SUBROUTINE DIFCK                                                          
      DIMENSION H(100,100),C(1,1),X(100),XP(100),T(100),G(100)                  
      DIMENSION S(100),SCALEX(100),GP(100),GB(100)                              
      COMMON /VARMIT/   F    ,   FP    ,   FB    , SCALEF  ,   FO    ,          
     1       S     ,    X    ,   XP    ,    T    , SCALEX  ,  IFCALL ,          
     2      GS     ,    G    ,   GP    ,   GB    ,   GSP   ,   GSB   ,          
     3       H     ,    C    ,  DELTA  ,   GSS   ,    E    ,  IMOVE  ,          
     4      EL     ,  DOUBLE ,    Z    ,    Q    ,    A    ,  ABAR   ,          
     5       N     ,   IT    ,   ITT   ,   MS    ,    K    , ICNVRG  ,          
     6     IERR    ,  LOOPF  ,   IFIN  ,  ISHOT  ,  IMOVEL ,  IMOVER ,          
     7    IREAD    ,  IWRITE ,  ICLOCK ,  IDENT  ,   ISTEP ,  ISCALE            
      COMMON /IOTAPE/ INTAPE,IOUTAP                                             
      IFAIL=0                                                                   
      DO 10 I=1,N                                                               
      T(I)=X(I)                                                                 
   10 CONTINUE                                                                  
      DO 100 I=1,N                                                              
      DO 50 ITRY=1,5                                                            
      TRY=AMAX1(AMIN1(1.0/ABS(G(I)),1.0),ABS(X(I))*1.0E-4)/(10.0**(ITRY-        
     *2))                                                                       
      T(I)=X(I)-TRY                                                             
      M1=2                                                                      
      CALL FCN (N,GB,FB,T,M1)                                                   
      T(I)=X(I)+TRY                                                             
      M1=2                                                                      
      CALL FCN (N,GP,FP,T,M1)                                                   
      T(I)=X(I)                                                                 
      FN=TRY*(GB(I)+4.0*G(I)+GP(I))/3.0                                         
      IF (ABS((FP-FB-FN)/FN) .LE. 1.0E-4) GO TO 98                              
      GN=(FP-FB)/(2.0*TRY)                                                      
      IF (ABS((GN-G(I))/GN) .LE. 1.0E-3) GO TO 98                               
   50 CONTINUE                                                                  
      WRITE (IOUTAP,55) I,FP,F,FB,FN,GP(I),G(I),GB(I),GN,TRY                    
   55 FORMAT (4H-THE,I4,82H-TH COMPONENT OF THE ANALYTICAL DERIVATIVE DO        
     *ESN@T AGREE TO WITHIN .1 / 1 PERCENT/33H0FPL,F,FM,FN,GPL,G,GM,GN,         
     *TRY ARE /10E13.5)                                                         
      IFAIL=1                                                                   
      GO TO 100                                                                 
   98 WRITE (IOUTAP,99) I,ITRY                                                  
   99 FORMAT (16H-SUCCESS FOR THE,I4,20H-TH COMPONENT ON THE,I4,4H TRY)         
  100 CONTINUE                                                                  
      IF(IFAIL.EQ.1) STOP                                                       
      RETURN                                                                    
      END                                                                       
"FOR,IS LOUHI.CSTRAN  .                                                         
      SUBROUTINE CSTRAN(ITES)                                                   
C  VARMIT SUBROUTINE CSTRAN SETS UP LINEAR CONSTRAINT EQUATIONS,                
C  NOT USED BY LOUHI78                                                          
      RETURN                                                                    
      END                                                                       
"FOR,IS LOUHI.RANDN  .                                                          
      SUBROUTINE RANDN(R,K,AV,SD)                                               
C                                                                               
C  #########     THIS ROUTINE SHOULD ALWAYS BE REPLACED WITH A                  
C                CORRESPONDING LIBRARY RANDOM NUMBER GENERATOR,                 
C                E.G. UNIVAC MATH PACK RANDN                                    
C                                                                               
C  THIS SUBROUTINE GENERATES K NORMALLY DISTRIBUTED RANDOM                      
C  NUMBERS WITH MEAN VALUE AV AND STANDARD DEVIATION SD IN THE                  
C  VECTOR R, A SEED NUMBER WHICH DETERMINES THE SEQUENCE OF                     
C  RANDOM NUMBERS IS GIVEN AS R(1) AND IS REPLACED BY THE                       
C  FIRST RANDOM NUMBER, A NONZERO SEED NUMBER STARTS A NEW RANDOM               
C  NUMBER SEQUENCE                                                              
C                                                                               
      DIMENSION R(1)                                                            
      DOUBLE PRECISION A,B,C,RN,RO,DQ                                           
      DATA RO /0.D0/                                                            
      IF(R(1).NE.0.) RO=DBLE(R(1))                                              
      A = 3161.D0                                                               
      B = 1.D7                                                                  
      C = 7370021.D0                                                            
      DO 200 J=1,K                                                              
C  SELECT RANDOM NUMBER RN, UNIFORMLY DISTRIBUTED                               
      RN = A*RO + C                                                             
      RN = DMOD(RN,B)                                                           
C  Q IS A UNIFORMLY DISTRIBUTED RANDOM NUMBER                                   
C  BETWEEN 0. AND 1.                                                            
      DQ = RN/B                                                                 
      Q = SNGL(DQ)                                                              
      RO = RN                                                                   
      Y = 1.                                                                    
      IF(Q.LT.0.5) GO TO 100                                                    
      Q = 1. - Q                                                                
      Y = -1.                                                                   
  100 Q = Q+1.E-20                                                              
      T = SQRT(ALOG(1./Q**2))                                                   
C  X IS (0.,1.)-NORMALLY DISTRIBUTED                                            
      X = T - (2.51557 + 0.802853*T + 0.010328*T**2)/                           
     1  (1. + 1.432788*T + 0.189269*T**2 + 0.001308*T**2)                       
      R(J) = Y*X*SD + AV                                                        
  200 CONTINUE                                                                  
      RETURN                                                                    
      END                                                                       
"FOR,IS LOUHI.TIMER  .                                                          
      SUBROUTINE TIMER                                                          
C                                                                               
C  THIS ROUTINE CALCULATES CPU TIME FROM THE FIRST CALL USING                   
C  UNIVAC 1108 LIBRARY ROUTINE TIME, KYA IS THE CPU TIME IN                     
C  UNITS OF 0.2 MILLISECONDS                                                    
C                                                                               
      DATA MFC0/0/                                                              
      IF(MFC0.NE.0) GO TO 80                                                    
C  FIRST CALL SETS ZERO TIME                                                    
      CALL TIME(KYA)                                                            
      TZER=FLOAT(KYA)/5000.                                                     
      PREVT = 0.                                                                
      MFC0=1                                                                    
      RETURN                                                                    
C  LATER CALLS                                                                  
   80 CALL TIME(KYA)                                                            
      TOTAL=FLOAT(KYA)/5000. - TZER                                             
      TDIF=TOTAL-PREVT                                                          
      PREVT=TOTAL                                                               
      WRITE(6,200) TOTAL,TDIF                                                   
  200 FORMAT(5X,'CPU TIME, TOTAL ',F9.3,'   INCREMENT ',F8.3,'   SEC.')         
      RETURN                                                                    
      END                                                                       
"ELT,IL LOUHI.COLL  .                                                           
IN LOUHI.MAIN,.RESULT,.KERNEL,.INTER,.SCALE                                     
IN LOUHI.WEIGHT,.RQ,.MTMPY,.MPRINT,.GRAPHS                                      
IN LOUHI.FDOSE,.FCN,.VARMIT,.READIN,.RITEOT,.ERROR,.MATMPY                      
IN LOUHI.CALCF,.DIFCK,.CSTRAN,.TIMER                                            
IN MISC*MISC.TIME                                                               
TYPE CLRAFCM                                                                    
"MAP LOUHI.COLL,.ALOUHI  .                                                      
"ELT,IL LOUHI.CS  .                                                             
TITLE                                                                           
ORR/REAL-80, 100 POINTS                                                         
KREAD     21.                                                                   
AU197G    100.      1.        2.                                                
(8E10.0)                                                                        
  .3162-09  .3162-08  .1517-07  .3391-07  .6164-07  .9349-07  .1398-06  .2082-06
  .3113-06  .4572-06  .6797-06  .1035-05  .1556-05  .2307-05  .3450-05  .5174-05
  .7613-05  .1114-04  .1684-04  .2510-04  .3674-04  .5572-04  .8307-04  .1162-03
  .1515-03  .1934-03  .2482-03  .3175-03  .4025-03  .5087-03  .6611-03  .8542-03
  .1106-02  .1428-02  .1789-02  .2324-02  .3030-02  .3912-02  .4975-02  .6293-02
  .8139-02  .1051-01  .1342-01  .1688-01  .2201-01  .2857-01  .3578-01  .4583-01
  .5886-01  .7621-01  .9839-01  .1219+00  .1470+00  .1744+00  .2045+00  .2369+00
  .2719+00  .3046+00  .3394+00  .3795+00  .4243+00  .4743+00  .5244+00  .5745+00
  .6293+00  .6893+00  .7494+00  .8094+00  .8791+00  .9592+00  .1095+01  .1296+01
  .1497+01  .1697+01  .1897+01  .2145+01  .2445+01  .2746+01  .3094+01  .3494+01
  .3895+01  .4295+01  .4743+01  .5244+01  .5745+01  .6340+01  .7041+01  .7790+01
  .8591+01  .9487+01  .1049+02  .1149+02  .1249+02  .1349+02  .1449+02  .1549+02
  .1649+02  .1749+02  .1849+02  .1949+02                                        
  .6973+03  .2304+03  .1227+03  .8323+02  .6332+02  .5212+02  .4344+02  .3658+02
  .3122+02  .2740+02  .2478+02  .2382+02  .2589+02  .3589+02  .1269+03  .1956+04
  .2177+02  .3107+01  .8145+00  .3420+00  .2918+00  .7298+02  .8848+01  .5081+01
  .2767+02  .6095+01  .1248+02  .1500+02  .1834+02  .7873+01  .1503+02  .1141+02
  .6135+01  .5717+01  .2460+01  .4176+01  .2931+01  .3557+01  .1608+01  .1802+01
  .1383+01  .1138+01  .9638+00  .7449+00  .6594+00  .6227+00  .5128+00  .4687+00
  .4113+00  .3526+00  .3061+00  .2801+00  .2619+00  .2372+00  .2480+00  .2359+00
  .2178+00  .2042+00  .1857+00  .1673+00  .1519+00  .1395+00  .1294+00  .1205+00
  .1114+00  .1026+00  .9528-01  .9052-01  .8640-01  .8406-01  .7943-01  .7382-01
  .7107-01  .6519-01  .5783-01  .4821-01  .3874-01  .3081-01  .2497-01  .2072-01
  .1777-01  .1612-01  .1476-01  .1276-01  .9139-02  .5433-02  .2527-02  .8351-03
  .3264-03  .4037-03  .7608-03  .1351-02  .1501-02  .1151-02  .9509-03  .8759-03
  .8408-03  .8258-03  .8108-03  .7923-03                                        
 AU97GC                                                                         
  .3528-13  .7144-03  .5213-01  .1103+00  .5478-01  .4833-02  .5914-05  .6082-04
  .1313+01  .8176+01  .1663+02  .2063+02  .2448+02  .3500+02  .1255+03  .1947+04
  .2173+02  .3102+01  .8054+00  .3110+00  .2914+00  .6299+02  .7481+01  .4469+01
  .2600+02  .5908+01  .1169+02  .1462+02  .1705+02  .7709+01  .1447+02  .1128+02
  .6044+01  .5642+01  .2409+01  .4085+01  .2872+01  .3489+01  .1580+01  .1773+01
  .1363+01  .1124+01  .9531+00  .7380+00  .6545+00  .6189+00  .5101+00  .4666+00
  .4097+00  .3514+00  .3051+00  .2793+00  .2613+00  .2367+00  .2475+00  .2354+00
  .2173+00  .2038+00  .1853+00  .1669+00  .1516+00  .1393+00  .1291+00  .1202+00
  .1112+00  .1024+00  .9513-01  .9038-01  .8628-01  .8395-01  .7934-01  .7375-01
  .7101-01  .6514-01  .5779-01  .4819-01  .3872-01  .3080-01  .2497-01  .2071-01
  .1776-01  .1611-01  .1476-01  .1276-01  .9137-02  .5432-02  .2526-02  .8350-03
  .3263-03  .4036-03  .7607-03  .1351-02  .1501-02  .1151-02  .9509-03  .8758-03
  .8408-03  .8258-03  .8108-03  .7922-03                                        
 AU97N2                                                                         
  .0000     .0000     .0000     .0000     .0000     .0000     .0000     .0000   
  .0000     .0000     .0000     .0000     .0000     .0000     .0000     .0000   
  .0000     .0000     .0000     .0000     .0000     .0000     .0000     .0000   
  .0000     .0000     .0000     .0000     .0000     .0000     .0000     .0000   
  .0000     .0000     .0000     .0000     .0000     .0000     .0000     .0000   
  .0000     .0000     .0000     .0000     .0000     .0000     .0000     .0000   
  .0000     .0000     .0000     .0000     .0000     .0000     .0000     .0000   
  .0000     .0000     .0000     .0000     .0000     .0000     .0000     .0000   
  .0000     .0000     .0000     .0000     .0000     .0000     .0000     .0000   
  .0000     .0000     .0000     .0000     .0000     .0000     .0000     .0000   
  .0000     .0000     .0000     .0000     .0000     .0000     .0000     .8863-03
  .1064+00  .5570+00  .1185+01  .1630+01  .1905+01  .2080+01  .2135+01  .2072+01
  .1975+01  .1800+01  .1525+01  .1200+01                                        
 SC45NG                                                                         
  .1620+03  .6032+02  .3313+02  .2247+02  .1699+02  .1385+02  .1135+02  .9316+01
  .7631+01  .6308+01  .5169+01  .4188+01  .3413+01  .2800+01  .2280+01  .1852+01
  .1515+01  .1238+01  .9864+00  .7881+00  .6263+00  .4786+00  .3616+00  .2787+00
  .2223+00  .1768+00  .1373+00  .1046+00  .8198-01  .2119+00  .4156-01  .2958-01
  .8862-01  .1641-01  .1463-01  .1890-01  .5413+00  .3436+00  .6943-01  .1297+00
  .2735+00  .1879+00  .5771-01  .6310-01  .6334-01  .5267-01  .1127+00  .5778-01
  .3462-01  .5462-01  .2853-01  .2683-01  .2370-01  .2025-01  .1737-01  .1507-01
  .1313-01  .1191-01  .1075-01  .9892-02  .9263-02  .8685-02  .8377-02  .8186-02
  .8068-02  .7998-02  .7836-02  .7684-02  .7494-02  .7240-02  .6425-02  .5031-02
  .3945-02  .2864-02  .2309-02  .1919-02  .1642-02  .1433-02  .1247-02  .1090-02
  .1013-02  .9559-03  .9211-03  .9046-03  .8898-03  .8741-03  .8577-03  .8422-03
  .8274-03  .8127-03  .7982-03  .7852-03  .7734-03  .7627-03  .7531-03  .7458-03
  .7394-03  .7334-03  .7279-03  .7229-03                                        
 SC45GC                                                                         
  .8194-14  .1870-03  .1407-01  .2979-01  .1470-01  .1285-02  .1545-05  .1549-04
  .3211+00  .1883+01  .3468+01  .3627+01  .3228+01  .2730+01  .2256+01  .1844+01
  .1512+01  .1236+01  .9755+00  .7167+00  .6254+00  .4131+00  .3058+00  .2451+00
  .2090+00  .1714+00  .1286+00  .1020+00  .7621-01  .2074+00  .4001-01  .2924-01
  .8730-01  .1619-01  .1433-01  .1849-01  .5303+00  .3371+00  .6819-01  .1275+00
  .2695+00  .1855+00  .5707-01  .6251-01  .6287-01  .5235-01  .1121+00  .5752-01
  .3448-01  .5443-01  .2845-01  .2676-01  .2364-01  .2020-01  .1733-01  .1503-01
  .1310-01  .1188-01  .1073-01  .9871-02  .9244-02  .8668-02  .8361-02  .8171-02
  .8054-02  .7985-02  .7823-02  .7672-02  .7483-02  .7231-02  .6417-02  .5026-02
  .3942-02  .2862-02  .2308-02  .1918-02  .1641-02  .1433-02  .1247-02  .1090-02
  .1013-02  .9556-03  .9208-03  .9044-03  .8897-03  .8739-03  .8576-03  .8421-03
  .8273-03  .8127-03  .7981-03  .7851-03  .7734-03  .7627-03  .7531-03  .7458-03
  .7394-03  .7334-03  .7278-03  .7229-03                                        
 U238NG                                                                         
  .2019+02  .6471+01  .3402+01  .2290+01  .1730+01  .1413+01  .1166+01  .9653+00
  .8036+00  .6806+00  .5813+00  .5066+00  .4672+00  .4748+00  .6356+00  .4147+01
  .6233+02  .5179+00  .3083+02  .5881+01  .2749+02  .2149+02  .2857+01  .1462+02
  .1169+01  .9494+01  .7917+01  .1756+01  .4530+01  .1963+01  .3700+01  .4054+01
  .3988+01  .1246+01  .1501+01  .1348+01  .1796+01  .8941+00  .9109+00  .8357+00
  .7264+00  .6982+00  .6505+00  .5779+00  .4994+00  .4613+00  .4258+00  .3639+00
  .2946+00  .2183+00  .1706+00  .1428+00  .1375+00  .1377+00  .1284+00  .1223+00
  .1176+00  .1149+00  .1122+00  .1097+00  .1079+00  .1079+00  .1103+00  .1141+00
  .1176+00  .1208+00  .1232+00  .1246+00  .1250+00  .1243+00  .1115+00  .8860-01
  .6980-01  .5572-01  .4600-01  .3745-01  .2955-01  .2425-01  .1956-01  .1568-01
  .1297-01  .1113-01  .9374-02  .7775-02  .6525-02  .5340-02  .4302-02  .3593-02
  .2886-02  .2092-02  .1600-02  .1500-02  .1400-02  .1300-02  .1237-02  .1212-02
  .1187-02  .1162-02  .1138-02  .1115-02                                        
 U238GC                                                                         
  .1021-14  .2006-04  .1445-02  .3035-02  .1497-02  .1310-03  .1587-06  .1605-05
  .3381-01  .2031+00  .3900+00  .4387+00  .4418+00  .4631+00  .6290+00  .4129+01
  .6219+02  .5173+00  .3049+02  .5348+01  .2746+02  .1855+02  .2415+01  .1286+02
  .1099+01  .9202+01  .7416+01  .1712+01  .4212+01  .1922+01  .3562+01  .4008+01
  .3928+01  .1229+01  .1470+01  .1318+01  .1760+01  .8771+00  .8947+00  .8221+00
  .7158+00  .6892+00  .6433+00  .5725+00  .4957+00  .4585+00  .4236+00  .3623+00
  .2935+00  .2176+00  .1701+00  .1424+00  .1372+00  .1373+00  .1281+00  .1220+00
  .1173+00  .1146+00  .1120+00  .1095+00  .1077+00  .1077+00  .1101+00  .1139+00
  .1174+00  .1206+00  .1230+00  .1244+00  .1249+00  .1242+00  .1114+00  .8851-01
  .6975-01  .5568-01  .4597-01  .3743-01  .2954-01  .2424-01  .1956-01  .1567-01
  .1297-01  .1112-01  .9372-02  .7773-02  .6524-02  .5339-02  .4301-02  .3593-02
  .2886-02  .2091-02  .1600-02  .1500-02  .1400-02  .1300-02  .1237-02  .1212-02
  .1187-02  .1162-02  .1137-02  .1114-02                                        
 U238NF                                                                         
  .4036-04  .1276-04  .6676-05  .4477-05  .3364-05  .2732-05  .2236-05  .1831-05
  .1498-05  .1237-05  .1013-05  .6842-06  .5286-06  .4880-06  .5285-06  .2111-05
  .1344-03  .4640-06  .4387-03  .1589-04  .4104-04  .1360-03  .1171-04  .8442-05
  .6459-07  .4375-04  .2740-05  .2100-04  .4632-05  .3513-04  .2309-03  .2241-03
  .4472-03  .9753-07  .7189-08  .1926-08  .6699-09  .1307-04  .2938-04  .5957-04
  .8899-04  .1032-03  .9974-04  .9450-04  .8720-04  .7906-04  .7000-04  .6344-04
  .6018-04  .5684-04  .6392-04  .7050-04  .7661-04  .8334-04  .9067-04  .9863-04
  .1075-03  .1228-03  .1722-03  .2308-03  .2734-03  .3250-03  .5057-03  .7072-03
  .1049-02  .1671-02  .2902-02  .4957-02  .1097-01  .1631-01  .2928-01  .9307-01
  .3221+00  .4475+00  .5152+00  .5384+00  .5285+00  .5289+00  .5245+00  .5343+00
  .5451+00  .5482+00  .5413+00  .5404+00  .5800+00  .7468+00  .9267+00  .9887+00
  .9954+00  .9902+00  .9843+00  .9865+00  .1002+01  .1068+01  .1170+01  .1244+01
  .1273+01  .1281+01  .1312+01  .1370+01                                        
 U235NF                                                                         
  .9645+03  .7153+03  .5352+03  .3837+03  .2903+03  .2323+03  .1840+03  .1642+03
  .1571+03  .8968+02  .5882+02  .6750+02  .1598+02  .1191+02  .2327+02  .1476+02
  .6810+02  .4056+02  .4791+02  .3683+02  .4546+02  .3642+02  .2596+02  .2164+02
  .2161+02  .2013+02  .2193+02  .1448+02  .1296+02  .1499+02  .1227+02  .8502+01
  .7897+01  .6924+01  .6878+01  .5609+01  .5015+01  .4871+01  .3989+01  .3490+01
  .3036+01  .2751+01  .2499+01  .2256+01  .2073+01  .2052+01  .1940+01  .1793+01
  .1798+01  .1638+01  .1562+01  .1515+01  .1461+01  .1415+01  .1367+01  .1318+01
  .1278+01  .1259+01  .1240+01  .1218+01  .1195+01  .1174+01  .1160+01  .1149+01
  .1142+01  .1137+01  .1137+01  .1140+01  .1161+01  .1203+01  .1216+01  .1228+01
  .1251+01  .1276+01  .1293+01  .1292+01  .1272+01  .1244+01  .1209+01  .1174+01
  .1140+01  .1121+01  .1087+01  .1051+01  .1066+01  .1283+01  .1573+01  .1755+01
  .1777+01  .1760+01  .1738+01  .1734+01  .1825+01  .1993+01  .2090+01  .2087+01
  .2029+01  .1959+01  .1946+01  .1985+01                                        
 U235FC                                                                         
  .4880-13  .2218-02  .2273+00  .5085+00  .2512+00  .2154-01  .2506-04  .2730-03
  .6610+01  .2676+02  .3947+02  .5845+02  .1511+02  .1162+02  .2303+02  .1469+02
  .6795+02  .4050+02  .4737+02  .3349+02  .4539+02  .3143+02  .2194+02  .1903+02
  .2031+02  .1951+02  .2054+02  .1412+02  .1205+02  .1468+02  .1181+02  .8405+01
  .7779+01  .6832+01  .6734+01  .5487+01  .4914+01  .4778+01  .3918+01  .3433+01
  .2991+01  .2716+01  .2471+01  .2235+01  .2058+01  .2040+01  .1930+01  .1785+01
  .1791+01  .1633+01  .1557+01  .1511+01  .1457+01  .1411+01  .1364+01  .1315+01
  .1276+01  .1257+01  .1237+01  .1216+01  .1193+01  .1171+01  .1158+01  .1147+01
  .1140+01  .1135+01  .1135+01  .1138+01  .1159+01  .1202+01  .1215+01  .1227+01
  .1250+01  .1275+01  .1292+01  .1292+01  .1271+01  .1243+01  .1209+01  .1173+01
  .1139+01  .1121+01  .1086+01  .1051+01  .1065+01  .1283+01  .1573+01  .1755+01
  .1777+01  .1759+01  .1737+01  .1734+01  .1825+01  .1992+01  .2090+01  .2087+01
  .2029+01  .1959+01  .1946+01  .1985+01                                        
 NP237F                                                                         
  .3862-17  .1094-06  .8484-05  .1679-04  .7538-05  .5970-06  .6396-09  .5749-08
  .1376-03  .5182-02  .1519-02  .2138-02  .8556-02  .1324-02  .5859-02  .1098-01
  .4116-02  .1732-02  .8828-03  .1251-01  .2176+00  .1369-01  .1936-02  .2401-01
  .8050-01  .1241+00  .3341-01  .3217-01  .3634-01  .1429-01  .3287-01  .2244-01
  .3108-01  .2075-01  .3035-01  .5991-02  .1589-01  .6875-02  .1015-01  .1073-01
  .1009-01  .9673-02  .9469-02  .9454-02  .9659-02  .1007-01  .1063-01  .1184-01
  .1514-01  .1980-01  .2537-01  .2934-01  .3287-01  .3700-01  .3962-01  .4785-01
  .7100-01  .9465-01  .1272+00  .1780+00  .2623+00  .3895+00  .5489+00  .7193+00
  .8776+00  .1023+01  .1152+01  .1247+01  .1354+01  .1448+01  .1515+01  .1568+01
  .1604+01  .1634+01  .1658+01  .1682+01  .1695+01  .1690+01  .1656+01  .1613+01
  .1567+01  .1541+01  .1517+01  .1494+01  .1537+01  .1787+01  .2136+01  .2232+01
  .2295+01  .2337+01  .2350+01  .2322+01  .2301+01  .2319+01  .2410+01  .2559+01
  .2666+01  .2680+01  .2694+01  .2718+01                                        
 CO59NG                                                                         
  .2842+03  .8992+02  .4704+02  .3155+02  .2372+02  .1927+02  .1578+02  .1293+02
  .1059+02  .8757+01  .7190+01  .5850+01  .4798+01  .3974+01  .3288+01  .2738+01
  .2322+01  .2002+01  .1752+01  .1617+01  .1630+01  .2015+01  .4221+01  .1602+03
  .4544+02  .1741+01  .4201+00  .1594+00  .7602-01  .4172-01  .2390-01  .1538-01
  .1108-01  .1789-01  .8643-02  .1003-01  .8295-01  .2256+00  .2261+00  .1488+00
  .1675+00  .6692-01  .2730-01  .5829-01  .9206-01  .3185-01  .2807-01  .2853-01
  .3131-01  .1211-01  .1714-01  .1412-01  .1314-01  .1264-01  .1180-01  .1077-01
  .9626-02  .9047-02  .8655-02  .8742-02  .9575-02  .9138-02  .7750-02  .7525-02
  .6897-02  .7067-02  .6527-02  .6453-02  .6730-02  .8395-02  .8745-02  .7375-02
  .6224-02  .5250-02  .4600-02  .4246-02  .3909-02  .3629-02  .3366-02  .3200-02
  .3039-02  .2850-02  .2625-02  .2475-02  .2425-02  .2330-02  .2036-02  .9999-03
  .6740-03  .7100-03  .7500-03  .7900-03  .8300-03  .8450-03  .8350-03  .7900-03
  .7075-03  .6000-03  .4900-03  .4102-03                                        
 CO59GC                                                                         
  .1438-13  .2788-03  .1998-01  .4182-01  .2053-01  .1787-02  .2148-05  .2150-04
  .4455+00  .2614+01  .4824+01  .5065+01  .4537+01  .3876+01  .3254+01  .2725+01
  .2317+01  .1999+01  .1733+01  .1471+01  .1627+01  .1739+01  .3569+01  .1409+03
  .4271+02  .1687+01  .3935+00  .1554+00  .7067-01  .4085-01  .2301-01  .1520-01
  .1092-01  .1766-01  .8463-02  .9812-02  .8127-01  .2213+00  .2220+00  .1464+00
  .1651+00  .6606-01  .2700-01  .5775-01  .9138-01  .3166-01  .2793-01  .2841-01
  .3119-01  .1207-01  .1709-01  .1408-01  .1311-01  .1261-01  .1177-01  .1075-01
  .9605-02  .9027-02  .8637-02  .8724-02  .9555-02  .9119-02  .7735-02  .7511-02
  .6885-02  .7055-02  .6516-02  .6443-02  .6720-02  .8384-02  .8735-02  .7368-02
  .6219-02  .5246-02  .4597-02  .4243-02  .3907-02  .3628-02  .3365-02  .3199-02
  .3038-02  .2849-02  .2624-02  .2474-02  .2425-02  .2330-02  .2035-02  .9997-03
  .6739-03  .7099-03  .7499-03  .7899-03  .8299-03  .8449-03  .8349-03  .7899-03
  .7075-03  .6000-03  .4900-03  .4102-03                                        
 FE58NG                                                                         
  .8712+01  .2772+01  .1451+01  .9730+00  .7320+00  .5948+00  .4868+00  .3988+00
  .3262+00  .2692+00  .2202+00  .1782+00  .1449+00  .1184+00  .9598-01  .7745-01
  .6278-01  .5060-01  .3952-01  .3074-01  .2363-01  .1728-01  .1250-01  .9392-02
  .7550-02  .8082-02  .5958+00  .1674+01  .8130-01  .3338-02  .2590-02  .2253-02
  .2039-02  .1897-02  .1814-02  .1761-02  .1758-02  .1843-02  .2126-02  .1147+00
  .7035-02  .1712+00  .3556-02  .1608-02  .2139-02  .1466-01  .9320-02  .8252-02
  .4916-02  .4973-02  .3502-02  .3425-02  .3431-02  .2458-02  .1785-02  .2278-02
  .2513-02  .2200-02  .2109-02  .2503-02  .2506-02  .2509-02  .2526-02  .2555-02
  .2585-02  .2618-02  .2674-02  .2546-02  .1800-02  .1399-02  .1280-02  .1263-02
  .1248-02  .1236-02  .1225-02  .1221-02  .1222-02  .1223-02  .1225-02  .1226-02
  .1227-02  .1228-02  .1229-02  .1188-02  .1111-02  .1035-02  .9658-03  .9378-03
  .9155-03  .8933-03  .1224-02  .2193-02  .3746-02  .6139-02  .9715-02  .1240-01
  .1320-01  .1400-01  .1480-01  .1554-01                                        
 FE58GC                                                                         
  .4407-15  .8596-05  .6161-03  .1290-02  .6334-03  .5516-04  .6627-07  .6630-06
  .1373-01  .8035-01  .1478+00  .1543+00  .1370+00  .1155+00  .9498-01  .7711-01
  .6264-01  .5053-01  .3908-01  .2796-01  .2360-01  .1492-01  .1057-01  .8260-02
  .7097-02  .7834-02  .5581+00  .1632+01  .7558-01  .3268-02  .2493-02  .2227-02
  .2008-02  .1872-02  .1776-02  .1723-02  .1723-02  .1808-02  .2088-02  .1128+00
  .6932-02  .1690+00  .3516-02  .1594-02  .2123-02  .1457-01  .9271-02  .8215-02
  .4897-02  .4957-02  .3491-02  .3415-02  .3422-02  .2452-02  .1781-02  .2273-02
  .2508-02  .2195-02  .2105-02  .2497-02  .2500-02  .2503-02  .2521-02  .2550-02
  .2580-02  .2614-02  .2670-02  .2542-02  .1797-02  .1397-02  .1279-02  .1262-02
  .1247-02  .1235-02  .1225-02  .1220-02  .1222-02  .1223-02  .1224-02  .1226-02
  .1227-02  .1228-02  .1229-02  .1187-02  .1111-02  .1034-02  .9657-03  .9377-03
  .9154-03  .8933-03  .1224-02  .2193-02  .3745-02  .6139-02  .9715-02  .1240-01
  .1320-01  .1400-01  .1480-01  .1554-01                                        
 FE54NP                                                                         
  .0000     .0000     .0000     .0000     .0000     .0000     .0000     .0000   
  .0000     .0000     .0000     .0000     .0000     .0000     .0000     .0000   
  .0000     .0000     .0000     .0000     .0000     .0000     .0000     .0000   
  .0000     .0000     .0000     .0000     .0000     .0000     .0000     .0000   
  .0000     .0000     .0000     .0000     .0000     .0000     .0000     .0000   
  .0000     .0000     .0000     .0000     .0000     .0000     .0000     .0000   
  .0000     .0000     .0000     .0000     .0000     .0000     .0000     .0000   
  .0000     .0000     .0000     .0000     .0000     .1900-09  .4425-07  .9475-07
  .9570-06  .2631-05  .4305-05  .1589-04  .6742-04  .1291-03  .4852-03  .1368-02
  .2940-02  .5660-02  .1729-01  .3563-01  .6282-01  .1121+00  .1832+00  .2102+00
  .2710+00  .3072+00  .3600+00  .4128+00  .4473+00  .4668+00  .4713+00  .4754+00
  .4778+00  .4761+00  .4734+00  .4721+00  .4496+00  .4003+00  .3278+00  .2574+00
  .2148+00  .1797+00  .1534+00  .1361+00                                        
 TI46NP                                                                         
  .0000     .0000     .0000     .0000     .0000     .0000     .0000     .0000   
  .0000     .0000     .0000     .0000     .0000     .0000     .0000     .0000   
  .0000     .0000     .0000     .0000     .0000     .0000     .0000     .0000   
  .0000     .0000     .0000     .0000     .0000     .0000     .0000     .0000   
  .0000     .0000     .0000     .0000     .0000     .0000     .0000     .0000   
  .0000     .0000     .0000     .0000     .0000     .0000     .0000     .0000   
  .0000     .0000     .0000     .0000     .0000     .0000     .0000     .0000   
  .0000     .0000     .0000     .0000     .0000     .0000     .0000     .0000   
  .0000     .0000     .0000     .0000     .0000     .0000     .0000     .0000   
  .0000     .4195-07  .1439-06  .2720-06  .2601-05  .1590-03  .2016-02  .8860-02
  .2250-01  .3920-01  .6050-01  .8600-01  .1115+00  .1420+00  .1740+00  .2007+00
  .2224+00  .2420+00  .2580+00  .2670+00  .2690+00  .2640+00  .2525+00  .2362+00
  .2187+00  .2005+00  .1815+00  .1620+00                                        
 TI48NP                                                                         
  .0000     .0000     .0000     .0000     .0000     .0000     .0000     .0000   
  .0000     .0000     .0000     .0000     .0000     .0000     .0000     .0000   
  .0000     .0000     .0000     .0000     .0000     .0000     .0000     .0000   
  .0000     .0000     .0000     .0000     .0000     .0000     .0000     .0000   
  .0000     .0000     .0000     .0000     .0000     .0000     .0000     .0000   
  .0000     .0000     .0000     .0000     .0000     .0000     .0000     .0000   
  .0000     .0000     .0000     .0000     .0000     .0000     .0000     .0000   
  .0000     .0000     .0000     .0000     .0000     .0000     .0000     .0000   
  .0000     .0000     .0000     .0000     .0000     .0000     .0000     .0000   
  .0000     .0000     .0000     .0000     .0000     .0000     .8621-10  .2483-07
  .9571-07  .8570-05  .4388-04  .2780-03  .9587-03  .3340-02  .6984-02  .1180-01
  .1748-01  .2520-01  .3570-01  .4720-01  .5700-01  .6325-01  .6300-01  .5950-01
  .5425-01  .4875-01  .4350-01  .3950-01                                        
 NI60NP                                                                         
  .0000     .0000     .0000     .0000     .0000     .0000     .0000     .0000   
  .0000     .0000     .0000     .0000     .0000     .0000     .0000     .0000   
  .0000     .0000     .0000     .0000     .0000     .0000     .0000     .0000   
  .0000     .0000     .0000     .0000     .0000     .0000     .0000     .0000   
  .0000     .0000     .0000     .0000     .0000     .0000     .0000     .0000   
  .0000     .0000     .0000     .0000     .0000     .0000     .0000     .0000   
  .0000     .0000     .0000     .0000     .0000     .0000     .0000     .0000   
  .0000     .0000     .0000     .0000     .0000     .0000     .0000     .0000   
  .0000     .0000     .0000     .0000     .0000     .0000     .0000     .0000   
  .0000     .0000     .0000     .0000     .3274-08  .4990-07  .1763-05  .4601-04
  .3779-03  .1990-02  .6425-02  .1340-01  .2350-01  .4126-01  .6424-01  .8825-01
  .1169+00  .1590+00  .1452+00  .1477+00  .1437+00  .1330+00  .1166+00  .9912-01
  .8575-01  .7612-01  .6775-01  .6212-01                                        
 NI58NP                                                                         
  .0000     .0000     .0000     .0000     .0000     .0000     .0000     .0000   
  .0000     .0000     .0000     .0000     .0000     .0000     .0000     .0000   
  .0000     .0000     .0000     .0000     .0000     .0000     .0000     .0000   
  .0000     .0000     .0000     .0000     .0000     .0000     .0000     .0000   
  .0000     .0000     .0000     .0000     .0000     .0000     .0000     .0000   
  .0000     .0000     .0000     .0000     .0000     .0000     .0000     .0000   
  .0000     .0000     .0000     .0000     .0000     .0000     .0000     .0000   
  .0000     .0000     .0000     .0000     .0000     .1400-07  .7633-04  .2262-03
  .3910-03  .5709-03  .7507-03  .9305-03  .1140-02  .1380-02  .3600-02  .7800-02
  .1278-01  .2240-01  .3280-01  .5960-01  .1031+00  .1510+00  .2075+00  .2712+00
  .3412+00  .3960+00  .4450+00  .4950+00  .5420+00  .5774+00  .5936+00  .5986+00
  .5999+00  .5947+00  .5807+00  .5595+00  .5260+00  .4665+00  .3790+00  .2915+00
  .2335+00  .1930+00  .1667+00  .1492+00                                        
 DAMAGE                                                                         
  .8317+02  .2630+02  .1376+02  .9230+01  .6930+01  .5630+01  .4610+01  .3770+01
  .3090+01  .2550+01  .2090+01  .1690+01  .1380+01  .1130+01  .9270+00  .7570+00
  .6250+00  .5160+00  .4190+00  .3440+00  .2840+00  .2310+00  .1890+00  .1600+00
  .1400+00  .1240+00  .1100+00  .9700-01  .8610-01  .8160-01  .3190+00  .7860+00
  .5100+01  .2150+01  .2730+01  .3500+01  .4380+01  .6170+01  .6740+01  .1400+02
  .3183+02  .1582+02  .1075+02  .9090+01  .5380+01  .2708+03  .7990+02  .6440+02
  .6720+02  .1342+03  .1135+03  .9110+02  .2012+03  .1618+03  .2129+03  .1999+03
  .1884+03  .1588+03  .2240+03  .3985+03  .4482+03  .3106+03  .3308+03  .2738+03
  .2094+03  .3996+03  .6078+03  .4806+03  .3630+03  .3547+03  .4710+03  .6743+03
  .8504+03  .7942+03  .9041+03  .1034+04  .1228+04  .1244+04  .1343+04  .1375+04
  .1503+04  .1582+04  .1681+04  .1759+04  .1825+04  .1910+04  .1996+04  .2073+04
  .2156+04  .2261+04  .2375+04  .2749+04  .2553+04  .2725+04  .2893+04  .2941+04
  .2942+04  .3020+04  .3157+04  .3285+04                                        
KFIX      100.      1.        0.        0.        21.                           
  .3162-09  .3162-08  .1517-07  .3391-07  .6164-07  .9349-07  .1398-06  .2082-06
  .3113-06  .4572-06  .6797-06  .1035-05  .1556-05  .2307-05  .3450-05  .5174-05
  .7613-05  .1114-04  .1684-04  .2510-04  .3674-04  .5572-04  .8307-04  .1162-03
  .1515-03  .1934-03  .2482-03  .3175-03  .4025-03  .5087-03  .6611-03  .8542-03
  .1106-02  .1428-02  .1789-02  .2324-02  .3030-02  .3912-02  .4975-02  .6293-02
  .8139-02  .1051-01  .1342-01  .1688-01  .2201-01  .2857-01  .3578-01  .4583-01
  .5886-01  .7621-01  .9839-01  .1219+00  .1470+00  .1744+00  .2045+00  .2369+00
  .2719+00  .3046+00  .3394+00  .3795+00  .4243+00  .4743+00  .5244+00  .5745+00
  .6293+00  .6893+00  .7494+00  .8094+00  .8791+00  .9592+00  .1095+01  .1296+01
  .1497+01  .1697+01  .1897+01  .2145+01  .2445+01  .2746+01  .3094+01  .3494+01
  .3895+01  .4295+01  .4743+01  .5244+01  .5745+01  .6340+01  .7041+01  .7790+01
  .8591+01  .9487+01  .1049+02  .1149+02  .1249+02  .1349+02  .1449+02  .1549+02
  .1649+02  .1749+02  .1849+02  .1949+02                                        
"ELT,IL LOUHI.DATA  .                                                           
TITLE                                                                           
ORR SPECTRUM  100 P                                                             
CPTIME                                                                          
DATA      1.         9.540E+14    1.E+00  1.                                    
DATA      2.         5.110E+14    1.E+00  1.                                    
DATA      3.         1.600E+10    1.E+00  1.                                    
DATA      4.         1.140E+14    1.E+00  1.                                    
DATA      5.         6.290E+12    1.E+00  1.                                    
DATA      6.         5.500E+13    1.E+00  1.                                    
DATA      7.         4.400E+13    1.E+00  1.                                    
DATA      8.         1.700E+12    1.E+00  1.                                    
DATA      9.         1.980E+15    1.E+00  1.                                    
DATA      10.        1.430E+14    1.E+00  1.                                    
DATA      11.        8.540E+12    1.E+00  1.                                    
DATA      12.        1.940E+14    1.E+00  1.                                    
DATA      13.        3.670E+13    1.E+00  1.                                    
DATA      14.        5.950E+12    1.E+00  1.                                    
DATA      15.        6.470E+11    1.E+00  1.                                    
DATA      16.        4.010E+11    1.E+00  1.                                    
DATA      17.        5.020E+10    1.E+00  1.                                    
DATA      18.        1.340E+09    1.E+00  1.                                    
DATA      19.        1.050E+10    1.E+00  1.                                    
DATA      20.        1.000E+13    1.E+00  0.                                    
DATA      21.        1.000E+15    1.E+00  0.                                    
GRAPH     2.        1.            1.E+06    1.E+20                              
WEIGHT    0.        0.        0.        1.                                      
P         1000000.  -1.       0.        20.                                     
PCORR     0.                                                                    
OPTION    0.        0.        0.        0.        0.        1.                  
VARMIT    0.                                                                    
    0    0    0    0    0    0    0  400    0    0    0    0                    
STEPS     3.                                                                    
DSCALE    2.                                                                    
GUESS     2.                                                                    
GAMMAS    10.                                                                   
CPTIME                                                                          
GO                                                                              
CPTIME                                                                          
WEIGHT    0.          0.      0.        0.0       1.                            
SHAPE     1.        100.                                                        
  .3835+19  .2900+20  .6028+20  .6048+20  .3453+20  .1173+20  .4340+19  .2604+19
  .1631+19  .1135+19  .7373+18  .4912+18  .3310+18  .2289+18  .1545+18  .1059+18
  .8985+17  .6916+17  .4645+17  .3052+17  .1717+17  .1126+17  .7030+16  .3863+16
  .2633+16  .1822+16  .1383+16  .9634+15  .7536+15  .5914+15  .4579+15  .3529+15
  .2766+15  .2099+15  .1698+15  .1307+15  .1002+15  .7726+14  .6105+14  .5055+14
  .4054+14  .3071+14  .2623+14  .2432+14  .2337+14  .2089+14  .1927+14  .1774+14
  .1602+14  .1459+14  .1297+14  .1164+14  .1049+14  .9405+13  .8413+13  .7612+13
  .6973+13  .6362+13  .5838+13  .5342+13  .4874+13  .4416+13  .4025+13  .3701+13
  .3405+13  .3129+13  .2871+13  .2642+13  .2442+13  .2299+13  .2156+13  .1946+13
  .1784+13  .1622+13  .1478+13  .1250+13  .9920+12  .8070+12  .6629+12  .5046+12
  .3577+12  .2738+12  .2137+12  .1622+12  .1183+12  .7803+11  .4607+11  .2490+11
  .1259+11  .6038+10  .2900+10  .1545+10  .8995+09  .5656+09  .3730+09  .2451+09
  .1536+09  .9472+08  .6057+08  .3959+08                                        
STEPS     1.                                                                    
DSCALE    2.                                                                    
SSCALE    2.                                                                    
GUESS     3.                                                                    
GAMMAS    30.                                                                   
CPTIME                                                                          
GO                                                                              
CPTIME                                                                          
INTEG     1.         0.        0.                                               
INTEG     0.1        0.        0.                                               
INTEG     1.         20.       0.                                               
INTEG     0.1        20.       0.                                               
INTEG     1.0        21.       0.                                               
INTEG     0.1        21.       0.                                               
CPTIME                                                                          
TITLE                                                                           
ORR TEST, SMOOTHNESS CONDITION                                                  
TEST      0.                                                                    
  .3835+19  .2900+20  .6028+20  .6048+20  .3453+20  .1173+20  .4340+19  .2604+19
  .1631+19  .1135+19  .7373+18  .4912+18  .3310+18  .2289+18  .1545+18  .1059+18
  .8985+17  .6916+17  .4645+17  .3052+17  .1717+17  .1126+17  .7030+16  .3863+16
  .2633+16  .1822+16  .1383+16  .9634+15  .7536+15  .5914+15  .4579+15  .3529+15
  .2766+15  .2099+15  .1698+15  .1307+15  .1002+15  .7726+14  .6105+14  .5055+14
  .4054+14  .3071+14  .2623+14  .2432+14  .2337+14  .2089+14  .1927+14  .1774+14
  .1602+14  .1459+14  .1297+14  .1164+14  .1049+14  .9405+13  .8413+13  .7612+13
  .6973+13  .6362+13  .5838+13  .5342+13  .4874+13  .4416+13  .4025+13  .3701+13
  .3405+13  .3129+13  .2871+13  .2642+13  .2442+13  .2299+13  .2156+13  .1946+13
  .1784+13  .1622+13  .1478+13  .1250+13  .9920+12  .8070+12  .6629+12  .5046+12
  .3577+12  .2738+12  .2137+12  .1622+12  .1183+12  .7803+11  .4607+11  .2490+11
  .1259+11  .6038+10  .2900+10  .1545+10  .8995+09  .5656+09  .3730+09  .2451+09
  .1536+09  .9472+08  .6057+08  .3959+08                                        
P         1000000.  -1.       0.        20.                                     
PCORR     6.                                                                    
WEIGHT    0.        0.        0.        1.                                      
ESCALE    11.                                                                   
        1.        1.        1.        1.        1.        1.        1.        1.
        1.        1.        1.        1.        1.        1.        1.        1.
        1.        1.        1.        1.        0.                              
STEPS     3.                                                                    
DSCALE    2.                                                                    
GUESS     2.                                                                    
GO                                                                              
CPTIME                                                                          
STEPS     1.                                                                    
DSCALE    2.                                                                    
GUESS     3.                                                                    
GO                                                                              
CPTIME                                                                          
PERTUR    0.        10.                                                         
ESCALE    11.                                                                   
        1.        1.        1.        1.        1.        1.        1.        1.
        1.        1.        1.        1.        1.        1.        1.        1.
        1.        1.        1.        1.        0.                              
GUESS     3.                                                                    
GO                                                                              
CPTIME                                                                          
STOP                                                                            
"XQT LOUHI.ALOUHI  .                                                            
"ADD,P LOUHI.CS  .                                                              
"ADD,P LOUHI.DATA  .                                                            
"FIN  .                                                                         
